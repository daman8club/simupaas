
'use client';

import type { ReactNode } from 'react';
import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import bcrypt from 'bcryptjs';
import { 
    getCredential as getCredentialFlow, 
    updateCredential as updateCredentialFlow, 
    type Role,
    type GetCredentialOutput
} from '@/ai/flows/credential-actions';
import {
    listDelegateAdmins as listDelegateAdminsFlow,
    createDelegateAdmin as createDelegateAdminFlow,
    updateDelegateAdmin as updateDelegateAdminFlow,
    deleteDelegateAdmin as deleteDelegateAdminFlow,
    getDelegateAdminCredentials as getDelegateAdminCredentialsFlow,
    type CreateDelegateAdminInput,
    type UpdateDelegateAdminInput,
    type DeleteDelegateAdminInput,
    type ListDelegateAdminsOutput,
    type DelegateAdminPermissions,
    type GetDelegateAdminCredentialsOutput
} from '@/ai/flows/delegate-admin-actions';


interface LoggedInUser {
  username: string;
  role: 'admin' | 'manager' | 'delegateAdmin';
  permissions?: DelegateAdminPermissions | null; 
  passwordHashOnLogin?: string; // Added to store the hash at login time
}

interface AuthContextType {
  loggedInUser: LoggedInUser | null;
  isAdminLoggedIn: boolean; 
  isManagerLoggedIn: boolean; 
  isDelegateAdminLoggedIn: boolean; 
  currentDelegateAdminPermissions: DelegateAdminPermissions | null;
  canAccessManagerPanel: boolean; 

  loginAdminOrDelegate: (usernameAttempt: string, passwordAttempt: string) => Promise<boolean>;
  logoutAdminOrDelegate: (options?: { silent?: boolean }) => void; // Added options
  loginManagerOrDelegate: (usernameAttempt: string, passwordAttempt: string) => Promise<boolean>;
  logoutManager: (options?: { silent?: boolean }) => void; // Added options
  
  updatePasswordAdmin: (currentPasswordAdmin: string, newPasswordAdmin: string) => Promise<{success: boolean, message: string}>;
  checkPasswordAdmin: (passwordAttempt: string) => Promise<boolean>;
  
  getRoleCredential: (role: Role) => Promise<{username?: string, error?: string}>; 
  updateUserCredentialsByManager: (
    role: Role, 
    newUsername?: string,
    newPassword?: string,
    currentPasswordForSelfChange?: string
  ) => Promise<{success: boolean, message: string}>;

  listDelegateAdmins: () => Promise<ListDelegateAdminsOutput>;
  createDelegateAdmin: (input: Omit<CreateDelegateAdminInput, 'managerUsername'>) => Promise<{success: boolean, message: string, username?: string}>;
  updateDelegateAdmin: (input: UpdateDelegateAdminInput) => Promise<{success: boolean, message: string}>;
  deleteDelegateAdmin: (input: DeleteDelegateAdminInput) => Promise<{success: boolean, message: string}>;
  
  managerUsername: string | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const STORAGE_LOGGED_IN_USER_KEY = 'simupass_logged_in_user_v4'; // Incremented version
const CREDENTIAL_VALIDATION_INTERVAL = 2 * 60 * 1000; // 2 minutes
const AUTO_LOGOUT_INTERVAL = 10 * 60 * 1000; // 10 minutes

export function AuthProvider({ children }: { children: ReactNode }) {
  const [loggedInUser, setLoggedInUser] = useState<LoggedInUser | null>(null);
  const router = useRouter();
  const pathname = usePathname();

  const internalLogout = useCallback((roleToLogout: 'admin' | 'manager' | 'delegateAdmin', options?: { silent?: boolean }) => {
    const wasLoggedIn = !!loggedInUser;
    updateLoggedInUser(null);
    if (!options?.silent && wasLoggedIn) { // Only redirect if not silent and user was actually logged out
      if (roleToLogout === 'admin' || roleToLogout === 'delegateAdmin') {
        if (pathname?.startsWith('/admin')) router.push('/admin/login');
      } else if (roleToLogout === 'manager') {
         if (pathname?.startsWith('/manager')) router.push('/manager/login');
      }
    }
  }, [loggedInUser, pathname, router]);


  useEffect(() => {
    const storedUserJson = typeof window !== 'undefined' ? localStorage.getItem(STORAGE_LOGGED_IN_USER_KEY) : null;
    if (storedUserJson) {
      try {
        const user = JSON.parse(storedUserJson) as LoggedInUser;
        setLoggedInUser(user);
      } catch (e) {
        console.error("Error parsing stored user from localStorage", e);
        localStorage.removeItem(STORAGE_LOGGED_IN_USER_KEY);
      }
    }
  }, []);

  const updateLoggedInUser = (user: LoggedInUser | null) => {
    setLoggedInUser(user);
    if (user) {
      localStorage.setItem(STORAGE_LOGGED_IN_USER_KEY, JSON.stringify(user));
    } else {
      localStorage.removeItem(STORAGE_LOGGED_IN_USER_KEY);
    }
  };
  
  const isAdminLoggedIn = loggedInUser?.role === 'admin';
  const isManagerLoggedIn = loggedInUser?.role === 'manager';
  const isDelegateAdminLoggedIn = loggedInUser?.role === 'delegateAdmin';
  const currentDelegateAdminPermissions = loggedInUser?.role === 'delegateAdmin' ? loggedInUser.permissions || null : null;
  const managerUsername = loggedInUser?.role === 'manager' ? loggedInUser.username : null;

  const canAccessManagerPanel = 
    loggedInUser?.role === 'manager' ||
    (loggedInUser?.role === 'delegateAdmin' && 
      !!loggedInUser.permissions &&
      (loggedInUser.permissions.canViewManagerOverview ||
       loggedInUser.permissions.canViewManagerUserActivity ||
       loggedInUser.permissions.canViewManagerTransactions)
    );


  const loginAdminOrDelegate = useCallback(
    async (usernameAttempt: string, passwordAttempt: string): Promise<boolean> => {
      // Try primary admin first
      const primaryAdminCreds = await getCredentialFlow({ role: 'admin' });
      if (primaryAdminCreds.username && primaryAdminCreds.password_hash) {
        if (primaryAdminCreds.username.toLowerCase() === usernameAttempt.toLowerCase()) {
          const passwordMatch = await bcrypt.compare(passwordAttempt, primaryAdminCreds.password_hash);
          if (passwordMatch) {
            updateLoggedInUser({ 
              username: primaryAdminCreds.username, 
              role: 'admin',
              passwordHashOnLogin: primaryAdminCreds.password_hash // Store hash
            });
            router.push('/admin');
            return true;
          }
        }
      } else if (primaryAdminCreds.error && !primaryAdminCreds.error.includes('not found')) {
          console.warn(`Error fetching primary admin credentials during login attempt: ${primaryAdminCreds.error}`);
      }

      // If primary admin login fails, try delegate admin
      const delegateAdminCreds = await getDelegateAdminCredentialsFlow({ username: usernameAttempt });
      if (delegateAdminCreds.username && delegateAdminCreds.password_hash && delegateAdminCreds.permissions) {
          if (delegateAdminCreds.username.toLowerCase() === usernameAttempt.toLowerCase()) {
            const passwordMatch = await bcrypt.compare(passwordAttempt, delegateAdminCreds.password_hash);
            if (passwordMatch) {
                updateLoggedInUser({
                  username: delegateAdminCreds.username,
                  role: 'delegateAdmin',
                  permissions: delegateAdminCreds.permissions,
                  passwordHashOnLogin: delegateAdminCreds.password_hash // Store hash
                });
                router.push('/admin');
                return true;
            }
        }
      } else if (delegateAdminCreds.error && !delegateAdminCreds.error.includes('not found')) {
           console.warn(`Error fetching delegate admin credentials for admin panel: ${delegateAdminCreds.error}`);
      }
      
      return false; 
    }, [router]
  );

  const logoutAdminOrDelegate = useCallback((options?: { silent?: boolean }) => {
    if (loggedInUser?.role === 'admin' || loggedInUser?.role === 'delegateAdmin') {
      internalLogout(loggedInUser.role, options);
    }
  }, [loggedInUser, internalLogout]);


  const loginManagerOrDelegate = useCallback(
    async (usernameAttempt: string, passwordAttempt: string): Promise<boolean> => {
      // Try primary manager first
      const managerCreds = await getCredentialFlow({ role: 'manager' });
      if (managerCreds.username && managerCreds.password_hash) {
        if (managerCreds.username.toLowerCase() === usernameAttempt.toLowerCase()) {
          const passwordMatch = await bcrypt.compare(passwordAttempt, managerCreds.password_hash);
          if (passwordMatch) {
            updateLoggedInUser({ 
              username: managerCreds.username, 
              role: 'manager',
              passwordHashOnLogin: managerCreds.password_hash // Store hash
            });
            router.push('/manager');
            return true;
          }
        }
      } else if (managerCreds.error && !managerCreds.error.includes('not found')) {
          console.warn(`Error fetching manager credentials during login attempt: ${managerCreds.error}`);
      }

      // If primary manager login fails, try delegate admin
      const delegateAdminCreds = await getDelegateAdminCredentialsFlow({ username: usernameAttempt });
      if (delegateAdminCreds.username && delegateAdminCreds.password_hash && delegateAdminCreds.permissions) {
          if (delegateAdminCreds.username.toLowerCase() === usernameAttempt.toLowerCase()) {
            const passwordMatch = await bcrypt.compare(passwordAttempt, delegateAdminCreds.password_hash);
            if (passwordMatch) {
                const { canViewManagerOverview, canViewManagerUserActivity, canViewManagerTransactions } = delegateAdminCreds.permissions;
                if (canViewManagerOverview || canViewManagerUserActivity || canViewManagerTransactions) {
                    updateLoggedInUser({
                        username: delegateAdminCreds.username,
                        role: 'delegateAdmin',
                        permissions: delegateAdminCreds.permissions,
                        passwordHashOnLogin: delegateAdminCreds.password_hash // Store hash
                    });
                    router.push('/manager');
                    return true;
                } else {
                    return false; 
                }
            }
        }
      } else if (delegateAdminCreds.error && !delegateAdminCreds.error.includes('not found')) {
           console.warn(`Error fetching delegate admin credentials for manager panel: ${delegateAdminCreds.error}`);
      }
      return false;
    }, [router]
  );

  const logoutManager = useCallback((options?: { silent?: boolean }) => {
    if (loggedInUser?.role === 'manager' || (loggedInUser?.role === 'delegateAdmin' && pathname?.startsWith('/manager'))) {
        internalLogout(loggedInUser.role, options);
    }
  }, [loggedInUser, pathname, internalLogout]);

  // Periodic Credential Validation
  useEffect(() => {
    const intervalId = setInterval(async () => {
      if (!loggedInUser || !loggedInUser.passwordHashOnLogin) return;

      if (loggedInUser.role === 'admin' || loggedInUser.role === 'manager') {
        const creds = await getCredentialFlow({ role: loggedInUser.role });
        if (creds.error || !creds.username || creds.username.toLowerCase() !== loggedInUser.username.toLowerCase() || creds.password_hash !== loggedInUser.passwordHashOnLogin) {
          console.log(`[AuthContext] Credentials for ${loggedInUser.role} ${loggedInUser.username} are no longer valid or changed. Logging out.`);
          internalLogout(loggedInUser.role, { silent: true });
        }
      } else if (loggedInUser.role === 'delegateAdmin') {
        const creds = await getDelegateAdminCredentialsFlow({ username: loggedInUser.username });
        if (creds.error || !creds.username || !creds.password_hash || creds.password_hash !== loggedInUser.passwordHashOnLogin) {
          console.log(`[AuthContext] Credentials for delegate admin ${loggedInUser.username} are no longer valid or changed. Logging out.`);
          internalLogout('delegateAdmin', { silent: true });
        } else if (JSON.stringify(creds.permissions) !== JSON.stringify(loggedInUser.permissions)) {
          console.log(`[AuthContext] Permissions updated for delegate admin ${loggedInUser.username}.`);
          updateLoggedInUser({ ...loggedInUser, permissions: creds.permissions });
        }
      }
    }, CREDENTIAL_VALIDATION_INTERVAL);

    return () => clearInterval(intervalId);
  }, [loggedInUser, internalLogout]);

  // 10-Minute Auto Logout
  useEffect(() => {
    let logoutTimer: NodeJS.Timeout;
    if (loggedInUser) {
      logoutTimer = setTimeout(() => {
        console.log(`[AuthContext] 10-minute session timeout for ${loggedInUser.username}. Logging out.`);
        if (loggedInUser.role === 'admin' || loggedInUser.role === 'delegateAdmin') {
            internalLogout(loggedInUser.role, { silent: false }); // Redirect on timeout
        } else if (loggedInUser.role === 'manager') {
            internalLogout(loggedInUser.role, { silent: false }); // Redirect on timeout
        }
      }, AUTO_LOGOUT_INTERVAL);
    }
    return () => clearTimeout(logoutTimer);
  }, [loggedInUser, internalLogout]);


  const checkPasswordAdmin = useCallback(async (passwordAttempt: string): Promise<boolean> => {
    if (loggedInUser?.role !== 'admin' || !loggedInUser.username) return false;
    
    const creds = await getCredentialFlow({ role: 'admin' });
    if (creds.error || !creds.password_hash || creds.username !== loggedInUser.username) {
        console.error(`Error checking primary admin password: ${creds.error || 'Hash missing or username mismatch'}`);
        return false;
    }
    return await bcrypt.compare(passwordAttempt, creds.password_hash);
  }, [loggedInUser]);


  const updatePasswordAdmin = useCallback(async (currentPasswordAdminAttempt: string, newPasswordAdmin: string): Promise<{success: boolean, message: string}> => {
    if (loggedInUser?.role !== 'admin') {
      return { success: false, message: 'Primary admin not logged in.' };
    }
    const isCurrentPasswordCorrect = await checkPasswordAdmin(currentPasswordAdminAttempt);
    if (!isCurrentPasswordCorrect) {
      return { success: false, message: 'Current primary admin password incorrect.' };
    }
    const result = await updateCredentialFlow({ role: 'admin', newUsername: loggedInUser.username, newPassword: newPasswordAdmin });
    if(result.success) {
        // Force re-login by clearing local state, next validation or action will require new password
        // Or update passwordHashOnLogin if new hash is returned, but current flow doesn't return new hash directly
        console.log("Admin password updated. User will be logged out on next validation or needs to re-login.");
        // Consider immediate logout or update of passwordHashOnLogin if flow is modified to return it
    }
    return result;
  }, [loggedInUser, checkPasswordAdmin]);


  const getRoleCredential = useCallback(async (role: Role): Promise<{username?: string, error?: string}> => {
    const result = await getCredentialFlow({ role });
    return { username: result.username, error: result.error }; 
  }, []);


  const updateUserCredentialsByManager = useCallback(async (
    roleToUpdate: Role, 
    newUsername?: string,
    newPassword?: string,
    currentPasswordForSelfChange?: string
  ): Promise<{success: boolean, message: string}> => {
    if (loggedInUser?.role !== 'manager') {
      return { success: false, message: 'Manager not authenticated.' };
    }

    if (roleToUpdate === 'manager' && newPassword && !currentPasswordForSelfChange) {
      return { success: false, message: 'Current password is required to change your own password.'};
    }
    
    if (roleToUpdate === 'manager' && newPassword && currentPasswordForSelfChange) {
      const managerCreds = await getCredentialFlow({ role: 'manager' });
      if (!managerCreds.password_hash || managerCreds.username !== loggedInUser.username) {
        return { success: false, message: 'Could not verify current manager password.' };
      }
      const isCurrentPasswordCorrect = await bcrypt.compare(currentPasswordForSelfChange, managerCreds.password_hash);
      if (!isCurrentPasswordCorrect) {
        return { success: false, message: 'Your current password was incorrect.' };
      }
    }
    
    const result = await updateCredentialFlow({ role: roleToUpdate, newUsername, newPassword });
    
    if (result.success && roleToUpdate === 'manager' && (newUsername || newPassword) && loggedInUser.username) {
        const updatedUsername = newUsername || loggedInUser.username;
        // If password changed, it's best to re-fetch to get the new hash for passwordHashOnLogin
        // For simplicity now, if manager changes their own details, they might get logged out by periodic check and need to re-login
        // which is a safe default.
        console.log("Manager details updated. Session might re-validate or require re-login if password changed.");
    }
    return result;
  }, [loggedInUser]);

  const listDelegateAdminsFromContext = useCallback(async (): Promise<ListDelegateAdminsOutput> => {
    if (loggedInUser?.role !== 'manager') return { admins: [], error: 'Manager not authenticated.' };
    return listDelegateAdminsFlow();
  }, [loggedInUser]);

  const createDelegateAdminInContext = useCallback(async (
    input: Omit<CreateDelegateAdminInput, 'managerUsername'>
  ): Promise<{success: boolean, message: string, username?: string}> => {
    if (loggedInUser?.role !== 'manager' || !loggedInUser.username) {
      return { success: false, message: 'Manager not authenticated or username unavailable.' };
    }
    return createDelegateAdminFlow({ ...input, managerUsername: loggedInUser.username });
  }, [loggedInUser]);

  const updateDelegateAdminInContext = useCallback(async (
    input: UpdateDelegateAdminInput
  ): Promise<{success: boolean, message: string}> => {
    if (loggedInUser?.role !== 'manager') return { success: false, message: 'Manager not authenticated.' };
    return updateDelegateAdminFlow(input);
  }, [loggedInUser]);

  const deleteDelegateAdminInContext = useCallback(async (
    input: DeleteDelegateAdminInput
  ): Promise<{success: boolean, message: string}> => {
    if (loggedInUser?.role !== 'manager') return { success: false, message: 'Manager not authenticated.' };
    return deleteDelegateAdminFlow(input);
  }, [loggedInUser]);

  // Unified redirection logic (already present, keep as is or slightly adjust if needed)
  useEffect(() => {
    const user = loggedInUser; 
    if (pathname?.startsWith('/admin') && pathname !== '/admin/login') {
      if (!user || (user.role !== 'admin' && user.role !== 'delegateAdmin')) {
        router.push('/admin/login');
      }
    } else if (pathname === '/admin/login' && user && (user.role === 'admin' || user.role === 'delegateAdmin')) {
      router.push('/admin');
    }

    if (pathname?.startsWith('/manager') && pathname !== '/manager/login') {
      if (!user || (user.role !== 'manager' && 
          !(user.role === 'delegateAdmin' && canAccessManagerPanel) // Use canAccessManagerPanel for delegate
         )) {
        router.push('/manager/login');
      }
    } else if (pathname === '/manager/login' && user && 
        (user.role === 'manager' || 
          (user.role === 'delegateAdmin' && canAccessManagerPanel) // Use canAccessManagerPanel for delegate
        )
    ) {
      router.push('/manager');
    }
  }, [pathname, router, loggedInUser, canAccessManagerPanel]); // Added canAccessManagerPanel dependency

  return (
    <AuthContext.Provider value={{
      loggedInUser,
      isAdminLoggedIn,
      isManagerLoggedIn,
      isDelegateAdminLoggedIn,
      currentDelegateAdminPermissions,
      canAccessManagerPanel,
      loginAdminOrDelegate,
      logoutAdminOrDelegate,
      loginManagerOrDelegate, 
      logoutManager,
      updatePasswordAdmin,
      checkPasswordAdmin,
      getRoleCredential,
      updateUserCredentialsByManager,
      listDelegateAdmins: listDelegateAdminsFromContext,
      createDelegateAdmin: createDelegateAdminInContext,
      updateDelegateAdmin: updateDelegateAdminInContext,
      deleteDelegateAdmin: deleteDelegateAdminInContext,
      managerUsername,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
