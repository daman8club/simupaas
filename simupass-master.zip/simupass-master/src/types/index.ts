export type RecoveryStage = 
  | 'USERNAME_INPUT'
  | 'PROCESSING'
  | 'PAYMENT_PENDING'
  | 'RECOVERY_SUCCESSFUL';

export interface DecryptionResult {
  decryptionProcess: string;
  generatedPassword: string;
}
