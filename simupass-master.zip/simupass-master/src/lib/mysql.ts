
import mysql from 'mysql2/promise';

// Ensure environment variables are loaded (typically done in a higher-level file like dev.ts or server startup)
// For Next.js, .env.local or .env is automatically loaded.

let pool: mysql.Pool | null = null;

export async function getDbConnection() {
  if (pool) {
    return pool;
  }

  if (!process.env.MYSQL_HOST || !process.env.MYSQL_USER || !process.env.MYSQL_DATABASE) {
    console.error('CRITICAL: MySQL environment variables (MYSQL_HOST, MYSQL_USER, MYSQL_DATABASE) are not fully set.');
    throw new Error('MySQL environment variables are not fully set.');
  }

  try {
    pool = mysql.createPool({
      host: process.env.MYSQL_HOST,
      user: process.env.MYSQL_USER,
      password: process.env.MYSQL_PASSWORD || '', // Default to empty string if not set
      database: process.env.MYSQL_DATABASE,
      port: process.env.MYSQL_PORT ? parseInt(process.env.MYSQL_PORT, 10) : 3306,
      waitForConnections: true,
      connectionLimit: 10, // Adjust as needed
      queueLimit: 0, // Unlimited queue
      connectTimeout: 10000, // 10 seconds
    });

    // Test the connection
    const connection = await pool.getConnection();
    console.log('Successfully connected to MySQL database.');
    connection.release();
    
    return pool;

  } catch (error) {
    console.error('CRITICAL: Failed to connect to MySQL database:', error);
    pool = null; // Reset pool on failure
    throw error; // Re-throw the error to indicate failure
  }
}

// Helper to convert MySQL RowDataPacket[] to a more usable array of objects
export function mapRows<T>(rows: any): T[] {
    if (Array.isArray(rows)) {
        return rows as T[];
    }
    return [];
}
