
import type { LucideIcon } from 'lucide-react';
import { Instagram, Facebook, Twitter, Camera, KeyRound, LockKeyhole, Database, Search, ShieldCheck, DollarSign, Server, Terminal, Wifi, ScanEye } from 'lucide-react';

export interface Platform {
  name: string;
  slug: string;
  icon: LucideIcon;
  description: string;
}

export const PLATFORMS: Platform[] = [
  { name: 'Instagram', slug: 'instagram', icon: Instagram, description: 'Recover your Instagram account.' },
  { name: 'Facebook', slug: 'facebook', icon: Facebook, description: 'Recover your Facebook account.' },
  { name: 'Twitter', slug: 'twitter', icon: Twitter, description: 'Recover your Twitter account.' },
  { name: 'Snapchat', slug: 'snapchat', icon: Camera, description: 'Recover your Snapchat account.' },
];

export const APP_NAME = 'SimuPass';
export const TELEGRAM_USERNAME = '@myclub5';
export const WHATSAPP_CONTACT_NUMBER = '+917229823324';

export interface ProcessingStep {
  id: string;
  text: string;
  icon: LucideIcon;
  duration: number; // ms
}

export const RECOVERY_PROCESS_STEPS: ProcessingStep[] = [
  { id: 'net_scan', text: 'net_scan :: INTERFACE=eth0 :: SCANNING_NETWORK_FOR_TARGETS...', icon: Wifi, duration: 1500 },
  { id: 'target_id', text: 'target_identify :: HOST_ACQUIRED :: INITIATING_VULNERABILITY_SCAN...', icon: ScanEye, duration: 2000 },
  { id: 'vuln_scan', text: 'vuln_scan :: EXPLOIT_DB_SYNC :: CVE_CHECK_IN_PROGRESS...', icon: Server, duration: 2500 },
  { id: 'db_connect', text: 'db_connect :: ESTABLISHING_SECURE_SHELL :: PROXY_CHAIN_ACTIVE...', icon: Database, duration: 2000 },
  { id: 'usr_lookup', text: 'usr_lookup :: QUERY="SELECT * FROM users WHERE username=\'{target}\'"...', icon: Search, duration: 2000 },
  { id: 'auth_bypass', text: 'auth_bypass :: ATTEMPTING_KNOWN_EXPLOITS :: HASH_IDENTIFIED...', icon: LockKeyhole, duration: 3000 },
  { id: 'hash_crack', text: 'hash_crack :: MODE=dictionary_attack :: JOHN_THE_RIPPER_LOADED...', icon: KeyRound, duration: 3500 },
  { id: 'access_grant', text: 'access_granted :: ROOT_SHELL_OBTAINED :: DISPLAYING_CREDENTIALS...', icon: ShieldCheck, duration: 1000 },
  { id: 'sim_complete', text: 'SIMULATION_PROTOCOL_SUCCESSFUL!', icon: DollarSign, duration: 1000 },
];

