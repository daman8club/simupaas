
import admin from 'firebase-admin';

// Declare firestore with its type, allowing it to be undefined if initialization fails.
// Note: Firestore is no longer the primary database for this application's core data.
// This file is kept in case other Firebase services (e.g., Auth, FCM) are used.
let firestore: admin.firestore.Firestore | undefined;

// Attempt to initialize Firebase Admin SDK only if no apps are already initialized.
if (admin.apps.length === 0) {
  const serviceAccountKeyBase64 = process.env.FIREBASE_SERVICE_ACCOUNT_KEY_BASE64;

  if (!serviceAccountKeyBase64) {
    console.warn( // Changed to warn as it might not be critical if Firebase is only for secondary services
      'WARNING: FIREBASE_SERVICE_ACCOUNT_KEY_BASE64 environment variable is not set. Firebase Admin SDK might not initialize or be fully functional.'
    );
  } else {
    try {
      const serviceAccountJson = Buffer.from(
        serviceAccountKeyBase64,
        'base64'
      ).toString('utf-8');
      
      let serviceAccount;
      try {
        serviceAccount = JSON.parse(serviceAccountJson);
      } catch (parseError) {
        console.error(
          'ERROR: Failed to parse FIREBASE_SERVICE_ACCOUNT_KEY_BASE64. The JSON string is likely malformed. Firebase Admin features may be unavailable. Error:',
          parseError
        );
        serviceAccount = null; 
      }

      if (serviceAccount) {
        admin.initializeApp({
          credential: admin.credential.cert(serviceAccount),
        });
        console.log('Firebase Admin SDK initialized successfully (may be for secondary services).');
      } else {
        console.warn('Firebase Admin SDK initialization skipped due to parsing error of service account key.');
      }

    } catch (error) { 
      console.error('ERROR: Firebase Admin SDK initialization failed:', error);
    }
  }
}

// Assign to firestore and try to apply settings if an app was initialized AND Firestore is intended for use.
if (admin.apps.length > 0) {
  // firestore = admin.firestore(); // Uncomment if you still need Firestore for specific features.
  // console.log('Firestore instance could be created if needed. Main DB is MySQL.');
  // if (firestore) {
  //   try {
  //     firestore.settings({
  //         ignoreUndefinedProperties: true, 
  //     });
  //   } catch (e) {
  //     if (String(e).includes("Firestore has already been started")) {
  //       // console.log('Firestore settings were already applied or defaults are in use.');
  //     } else {
  //       console.warn("Could not apply Firestore settings (this might be an issue):", e);
  //     }
  //   }
  // }
} else {
  console.warn( // Changed to warn
    "Firebase Admin SDK is not initialized. Any Firebase-dependent features will be unavailable. " +
    "Main data persistence is now configured for MySQL."
  );
}

// Export firebaseAdmin for potential use with other Firebase services (e.g., Auth, Storage, FCM).
// The direct 'firestore' export is commented out as MySQL is primary.
export { /* firestore, */ admin as firebaseAdmin };
