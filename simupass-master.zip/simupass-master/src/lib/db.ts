'use client';

import type { ReactNode } from 'react';
import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import bcrypt from 'bcryptjs';
import { 
    getCredential as getCredentialFlow, 
    updateCredential as updateCredentialFlow, 
    type Role,
    type GetCredentialOutput
} from '@/ai/flows/credential-actions';


interface AuthContextType {
  isAdminLoggedIn: boolean;
  isManagerLoggedIn: boolean;
  loginAdmin: (usernameAttempt: string, passwordAttempt: string) => Promise<boolean>;
  logoutAdmin: () => void;
  loginManager: (usernameAttempt: string, passwordAttempt: string) => Promise<boolean>;
  logoutManager: () => void;
  updatePasswordAdmin: (currentPasswordAdmin: string, newPasswordAdmin: string) => Promise<{success: boolean, message: string}>;
  checkPasswordAdmin: (passwordAttempt: string) => Promise<boolean>;
  getRoleCredential: (role: Role) => Promise<{username?: string, error?: string}>; // Only expose username and error
  updateUserCredentialsByManager: (
    role: Role,
    newUsername?: string,
    newPassword?: string,
    currentPasswordForSelfChange?: string
  ) => Promise<{success: boolean, message: string}>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const STORAGE_ADMIN_LOGGED_IN_KEY = 'simupass_admin_logged_in_v2_firestore';
const STORAGE_MANAGER_LOGGED_IN_KEY = 'simupass_manager_logged_in_v2_firestore';
const STORAGE_ADMIN_USERNAME_KEY = 'simupass_admin_username_v2_firestore';
const STORAGE_MANAGER_USERNAME_KEY = 'simupass_manager_username_v2_firestore';


export function AuthProvider({ children }: { children: ReactNode }) {
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);
  const [isManagerLoggedIn, setIsManagerLoggedIn] = useState(false);
  const [adminUsername, setAdminUsername] = useState<string | null>(null);
  const [managerUsername, setManagerUsername] = useState<string | null>(null);

  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    const adminLoggedInStatus = typeof window !== 'undefined' ? localStorage.getItem(STORAGE_ADMIN_LOGGED_IN_KEY) : null;
    setIsAdminLoggedIn(adminLoggedInStatus === 'true');
    setAdminUsername(typeof window !== 'undefined' ? localStorage.getItem(STORAGE_ADMIN_USERNAME_KEY) : null);

    const managerLoggedInStatus = typeof window !== 'undefined' ? localStorage.getItem(STORAGE_MANAGER_LOGGED_IN_KEY) : null;
    setIsManagerLoggedIn(managerLoggedInStatus === 'true');
    setManagerUsername(typeof window !== 'undefined' ? localStorage.getItem(STORAGE_MANAGER_USERNAME_KEY) : null);
  }, []);

  const fetchAndVerifyCredentials = async (role: Role, usernameAttempt: string, passwordAttempt: string): Promise<GetCredentialOutput | null> => {
    const result = await getCredentialFlow({ role });
    if (result.error || !result.username || !result.password_hash) {
      console.error(`Error fetching credentials for ${role}: ${result.error || 'Username or hash missing'}`);
      return null;
    }
    if (result.username.toLowerCase() !== usernameAttempt.toLowerCase()) {
      return null; // Username mismatch
    }
    const passwordMatch = await bcrypt.compare(passwordAttempt, result.password_hash);
    return passwordMatch ? result : null;
  };
  

  const attemptLogin = async (role: Role, usernameAttempt: string, passwordAttempt: string): Promise<boolean> => {
    const creds = await fetchAndVerifyCredentials(role, usernameAttempt, passwordAttempt);
    if (creds && creds.username) {
        if (role === 'admin') {
            setIsAdminLoggedIn(true);
            setAdminUsername(creds.username);
            localStorage.setItem(STORAGE_ADMIN_LOGGED_IN_KEY, 'true');
            localStorage.setItem(STORAGE_ADMIN_USERNAME_KEY, creds.username);
            router.push('/admin');
        } else if (role === 'manager') {
            setIsManagerLoggedIn(true);
            setManagerUsername(creds.username);
            localStorage.setItem(STORAGE_MANAGER_LOGGED_IN_KEY, 'true');
            localStorage.setItem(STORAGE_MANAGER_USERNAME_KEY, creds.username);
            router.push('/manager');
        }
        return true;
    }
    return false;
  };

  const loginAdmin = useCallback(
    async (usernameAttempt: string, passwordAttempt: string): Promise<boolean> => {
      return attemptLogin('admin', usernameAttempt, passwordAttempt);
    }, [router]
  );

  const logoutAdmin = useCallback(() => {
    setIsAdminLoggedIn(false);
    setAdminUsername(null);
    localStorage.removeItem(STORAGE_ADMIN_LOGGED_IN_KEY);
    localStorage.removeItem(STORAGE_ADMIN_USERNAME_KEY);
    router.push('/admin/login');
  }, [router]);

  const loginManager = useCallback(
    async (usernameAttempt: string, passwordAttempt: string): Promise<boolean> => {
      return attemptLogin('manager', usernameAttempt, passwordAttempt);
    }, [router]
  );

  const logoutManager = useCallback(() => {
    setIsManagerLoggedIn(false);
    setManagerUsername(null);
    localStorage.removeItem(STORAGE_MANAGER_LOGGED_IN_KEY);
    localStorage.removeItem(STORAGE_MANAGER_USERNAME_KEY);
    router.push('/manager/login');
  }, [router]);

  const checkPassword = async (role: Role, passwordAttempt: string): Promise<boolean> => {
    const currentUsername = role === 'admin' ? adminUsername : managerUsername;
    if (!currentUsername) return false;

    const creds = await getCredentialFlow({ role });
    if (creds.error || !creds.password_hash) {
        console.error(`Error checking ${role} password (fetch failed): ${creds.error}`);
        return false;
    }
    // Ensure the fetched username matches the logged-in username for safety, although role should guarantee this
    if (creds.username !== currentUsername) {
        console.error(`Error checking ${role} password: Username mismatch during check.`);
        return false;
    }
    return await bcrypt.compare(passwordAttempt, creds.password_hash);
  };
  
  const checkPasswordAdmin = useCallback(
    async (passwordAttempt: string): Promise<boolean> => {
      if(!isAdminLoggedIn || !adminUsername) return false;
      return checkPassword('admin', passwordAttempt);
    }, [isAdminLoggedIn, adminUsername]
  );

  const updatePasswordAdmin = useCallback(async (currentPasswordAdminAttempt: string, newPasswordAdmin: string): Promise<{success: boolean, message: string}> => {
    if (!isAdminLoggedIn || !adminUsername) {
      return { success: false, message: 'Admin not logged in.' };
    }
    const isCurrentPasswordCorrect = await checkPassword('admin', currentPasswordAdminAttempt);
    if (!isCurrentPasswordCorrect) {
      return { success: false, message: 'Current admin password incorrect.' };
    }
    return updateCredentialFlow({ role: 'admin', newPassword: newPasswordAdmin });
  }, [isAdminLoggedIn, adminUsername]);


  const getRoleCredential = useCallback(async (role: Role): Promise<{username?: string, error?: string}> => {
    const result = await getCredentialFlow({ role });
    return { username: result.username, error: result.error }; // Only return username and error, not hash
  }, []);

  const updateUserCredentialsByManager = useCallback(async (
    role: Role,
    newUsername?: string,
    newPassword?: string,
    currentPasswordForSelfChange?: string
  ): Promise<{success: boolean, message: string}> => {
    if (!isManagerLoggedIn) {
      return { success: false, message: 'Manager not authenticated.' };
    }

    if (role === 'manager' && newPassword && !currentPasswordForSelfChange) {
      return { success: false, message: 'Current password is required to change your own password.'};
    }
    
    if (role === 'manager' && newPassword && currentPasswordForSelfChange) {
      const isCurrentPasswordCorrect = await checkPassword('manager', currentPasswordForSelfChange);
      if (!isCurrentPasswordCorrect) {
        return { success: false, message: 'Your current password was incorrect.' };
      }
    }
    const result = await updateCredentialFlow({ role, newUsername, newPassword });
    // If manager updated their own username, update it in localStorage and state
    if (result.success && role === 'manager' && newUsername) {
        setManagerUsername(newUsername);
        localStorage.setItem(STORAGE_MANAGER_USERNAME_KEY, newUsername);
    }
     // If manager updated admin username, and admin is currently logged in (unlikely but possible), update admin username state
    if (result.success && role === 'admin' && newUsername && isAdminLoggedIn) {
        setAdminUsername(newUsername);
        localStorage.setItem(STORAGE_ADMIN_USERNAME_KEY, newUsername);
    }
    return result;
  }, [isManagerLoggedIn, managerUsername, isAdminLoggedIn]);


  useEffect(() => {
    const adminLoggedIn = typeof window !== 'undefined' ? localStorage.getItem(STORAGE_ADMIN_LOGGED_IN_KEY) === 'true' : false;
    if (pathname?.startsWith('/admin')) {
      if (!adminLoggedIn && pathname !== '/admin/login') {
        router.push('/admin/login');
      } else if (adminLoggedIn && pathname === '/admin/login') {
        router.push('/admin');
      }
    }
  }, [pathname, router, isAdminLoggedIn]); // Added isAdminLoggedIn to re-run effect if it changes elsewhere

  useEffect(() => {
     const managerLoggedIn = typeof window !== 'undefined' ? localStorage.getItem(STORAGE_MANAGER_LOGGED_IN_KEY) === 'true' : false;
     if (pathname?.startsWith('/manager')) {
       if (!managerLoggedIn && pathname !== '/manager/login') {
         router.push('/manager/login');
       } else if (managerLoggedIn && pathname === '/manager/login') {
         router.push('/manager');
       }
     }
  }, [pathname, router, isManagerLoggedIn]); // Added isManagerLoggedIn here too

  return (
    <AuthContext.Provider value={{
      isAdminLoggedIn,
      isManagerLoggedIn,
      loginAdmin,
      logoutAdmin,
      loginManager,
      logoutManager,
      updatePasswordAdmin,
      checkPasswordAdmin,
      getRoleCredential,
      updateUserCredentialsByManager,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}