
'use client';

import { useState, useEffect, useCallback } from 'react';
import Image from 'next/image';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2, CheckCircle2, Copy, AlertTriangle, Send, Clock, HelpCircle, DollarSign, Type, MessageSquare, QrCode } from 'lucide-react';
import { APP_NAME, WHATSAPP_CONTACT_NUMBER } from '@/lib/constants';
import { useToast } from "@/hooks/use-toast";
import { 
  checkPaymentStatus, 
  type CheckPaymentStatusInput, 
  type CheckPaymentStatusOutput,
  getUpiConfiguration,
  type UpiConfiguration
} from '@/ai/flows/admin-actions';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPaymentVerified: () => void;
  username: string;
  platform: string; 
}

type VerificationStatus = 'idle' | 'verifying' | 'verified' | 'failed' | 'pending_review' | 'rejected' | 'loading_config';

// Helper function to generate a client-side transaction reference for QR code uniqueness
const generateClientTransactionRef = (): string => {
  return `SIMUPASS-${Date.now()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
};

export function PaymentModal({ isOpen, onClose, onPaymentVerified, username, platform }: PaymentModalProps) {
  const [isVerifying, setIsVerifying] = useState(false);
  const [verificationStatus, setVerificationStatus] = useState<VerificationStatus>('loading_config');
  const [utrNumber, setUtrNumber] = useState('');
  const { toast } = useToast();
  const [upiConfig, setUpiConfig] = useState<UpiConfiguration | null>(null);

  const fetchConfigAndSetIdle = useCallback(async () => {
    if (!isOpen) return;
    setVerificationStatus('loading_config');
    try {
      const config = await getUpiConfiguration();
      setUpiConfig(config);
      setVerificationStatus('idle');
    } catch (error) {
      console.error("Failed to load UPI configuration:", error);
      toast({
        title: "Configuration Error",
        description: "Could not load payment settings. Please try again later.",
        variant: "destructive",
      });
      setUpiConfig(null); 
      setVerificationStatus('failed'); 
    }
  }, [isOpen, toast]);

  useEffect(() => {
    if (isOpen) {
      fetchConfigAndSetIdle();
    } else {
      setVerificationStatus('loading_config'); 
      setIsVerifying(false);
      setUpiConfig(null); 
      setUtrNumber(''); 
    }
  }, [isOpen, fetchConfigAndSetIdle]);


  const generateQrCodeUrl = () => {
    if (!upiConfig || !upiConfig.upiId || !upiConfig.paymentAmount) return '';
    const payeeName = APP_NAME;
    const transactionNote = `Payment for ${APP_NAME} - User: ${username} (${platform})`;
    const clientTrRef = generateClientTransactionRef(); // Generate unique ref for QR
    const upiData = `upi://pay?pa=${encodeURIComponent(upiConfig.upiId)}&pn=${encodeURIComponent(payeeName)}&am=${encodeURIComponent(upiConfig.paymentAmount)}&cu=INR&tn=${encodeURIComponent(transactionNote)}&tr=${encodeURIComponent(clientTrRef)}`;
    return `https://api.qrserver.com/v1/create-qr-code/?data=${encodeURIComponent(upiData)}&size=160x160&format=png&margin=10`;
  };
  

  const handleVerifyPayment = async () => {
    if (!username) {
        toast({
            title: "Verification Error",
            description: "Username is missing. Cannot verify payment.",
            variant: "destructive",
        });
        setVerificationStatus('failed');
        return;
    }
    if (!utrNumber.trim()) {
        toast({
            title: "UTR Number Required",
            description: "Please enter the transaction ID / UTR number.",
            variant: "destructive",
        });
        return;
    }
     if (!platform) {
        toast({
            title: "Verification Error",
            description: "Platform information is missing. Cannot verify payment.",
            variant: "destructive",
        });
        setVerificationStatus('failed');
        return;
    }


    setIsVerifying(true);
    setVerificationStatus('verifying');
    
    try {
      const input: CheckPaymentStatusInput = { username, utr: utrNumber.trim(), platform };
      const result: CheckPaymentStatusOutput = await checkPaymentStatus(input);

      if (result.isVerified) {
        setVerificationStatus('verified');
        toast({
            title: "Payment Verified!",
            description: "Your payment has been successfully verified by admin.",
            variant: "default", 
        });
        setTimeout(() => {
            onPaymentVerified();
            onClose();
        }, 1000);
      } else if (result.wasRejected) {
        setVerificationStatus('rejected');
         toast({
            title: "Payment Rejected by Admin",
            description: (result.message || "Your payment was not approved.") + 
                           ` Please ensure UTR is correct and try a new payment if needed, or contact support on WhatsApp: ${WHATSAPP_CONTACT_NUMBER}.`,
            variant: "destructive",
            duration: 12000,
        });
      } else if (result.isNewEnquiry) {
        setVerificationStatus('pending_review');
        toast({
            title: "Verification Request Submitted",
            description: `Your request (UTR: ${utrNumber}) has been sent for admin review. This may take 1-2 minutes. You can click "Retry Verification" periodically. For issues, click to chat on WhatsApp: ${WHATSAPP_CONTACT_NUMBER}.`,
            variant: "default", 
            duration: 15000,
        });
      } else { 
        setVerificationStatus('pending_review'); 
        toast({
            title: "Payment Still Pending Review",
            description: (result.message || "Admin has not approved this payment yet.") + 
                           ` Please wait (1-2 minutes) or click to chat on WhatsApp: ${WHATSAPP_CONTACT_NUMBER} with your username and UTR: ${utrNumber}.`,
            variant: "default",
            duration: 10000,
        });
      }
    } catch (error) {
      console.error("Payment verification error:", error);
      setVerificationStatus('failed');
      toast({
        title: "Verification System Error",
        description: `An error occurred. Click to chat on WhatsApp: ${WHATSAPP_CONTACT_NUMBER} with username ${username} and UTR: ${utrNumber}.`,
        variant: "destructive",
      });
    } finally {
      setIsVerifying(false);
    }
  };

  const copyToClipboard = (textToCopy: string, type: string) => {
    navigator.clipboard.writeText(textToCopy)
      .then(() => {
        toast({ title: `${type} Copied!`, description: `${textToCopy} copied to clipboard.` });
      })
      .catch(err => {
        toast({ title: "Copy Failed", description: `Could not copy ${type}.`, variant: "destructive" });
        console.error('Failed to copy: ', err);
      });
  };
  
  const qrCodeUrl = isOpen && upiConfig ? generateQrCodeUrl() : '';

  const renderFooterContent = () => {
    switch (verificationStatus) {
      case 'loading_config':
        return (
          <div className="flex items-center justify-center w-full text-muted-foreground">
            <Loader2 className="mr-2 h-6 w-6 animate-spin" /> Loading payment settings...
          </div>
        );
      case 'idle':
      case 'pending_review':
      case 'rejected':
        return (
          <Button onClick={handleVerifyPayment} disabled={isVerifying || !utrNumber.trim() || !upiConfig} className="w-full bg-primary text-primary-foreground hover:bg-primary/80">
            {isVerifying ? (
              <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Verifying...</>
            ) : (verificationStatus === 'idle' ? 'Request Verification' : 'Retry Verification')}
          </Button>
        );
      case 'verifying':
        return (
          <div className="flex items-center justify-center w-full text-accent">
            <Loader2 className="mr-2 h-6 w-6 animate-spin" /> Requesting verification from admin...
          </div>
        );
      case 'verified':
        return (
          <div className="flex items-center justify-center w-full text-green-500"> 
            <CheckCircle2 className="mr-2 h-6 w-6" /> Payment Verified! Preparing password...
          </div>
        );
      case 'failed': 
        return (
          <div className="flex flex-col items-center justify-center w-full space-y-3">
              <div className="flex items-center text-destructive text-center">
                  <AlertTriangle className="mr-2 h-5 w-5 shrink-0" /> 
                  <span className="break-words">
                  {upiConfig ? "Verification System Error." : "Failed to load payment settings."}
                  <br /> Contact support via WhatsApp:
                  <a
                    href={`https://wa.me/${WHATSAPP_CONTACT_NUMBER.replace(/\s+/g, '')}?text=${encodeURIComponent(`Hi, I need help with a payment for ${APP_NAME}. Username: ${username}, UTR: ${utrNumber}`)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="underline hover:text-destructive/80 ml-1 flex items-center justify-center"
                  >
                     {WHATSAPP_CONTACT_NUMBER} <Send className="ml-1 h-3 w-3"/>
                  </a>
                  </span>
              </div>
              {upiConfig && ( 
                <Button onClick={handleVerifyPayment} className="w-full bg-primary text-primary-foreground hover:bg-primary/80" disabled={isVerifying || !utrNumber.trim()}>
                 {isVerifying ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Verifying...</> : 'Retry Verification'}
                </Button>
              )}
          </div>
        );
      default:
        return null;
    }
  };


  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-card border-border shadow-lg w-full max-w-lg p-4 sm:p-6">
        <DialogHeader>
          <DialogTitle className="text-xl sm:text-2xl text-primary flex items-center">
            {verificationStatus === 'loading_config' && <Loader2 className="mr-2 h-5 sm:h-6 w-5 sm:w-6 animate-spin" />}
            <DollarSign className="mr-2 h-6 sm:h-7 w-6 sm:h-7"/> 
            {upiConfig ? `Make Payment for Reveal Password (₹${upiConfig.paymentAmount})` : 'Payment Gateway'}
          </DialogTitle>
        </DialogHeader>
        <ScrollArea className="max-h-[70vh] pr-2 sm:pr-3">
          <div className="py-3 space-y-3"> 
            {verificationStatus === 'loading_config' ? (
              <div className="flex flex-col items-center justify-center h-[200px] sm:h-[250px] text-muted-foreground">
                <Loader2 className="h-10 sm:h-12 w-10 sm:h-12 animate-spin text-primary mb-4" />
                <p>Loading secure payment details...</p>
              </div>
            ) : !upiConfig ? (
                <div className="flex flex-col items-center justify-center h-[200px] sm:h-[250px] text-destructive">
                    <AlertTriangle className="h-10 sm:h-12 w-10 sm:h-12 mb-4" />
                    <p className="text-center">Could not load payment configuration. <br />Please close this modal and try again.</p>
                </div>
            ) : (
              <>
                <div className="text-center">
                  <p className="text-xs sm:text-sm text-muted-foreground mb-0.5">Scan QR or use UPI ID: <span className="font-semibold text-accent break-all">{upiConfig.upiId}</span></p>
                  {qrCodeUrl ? (
                      <Image
                          src={qrCodeUrl}
                          alt={`UPI QR Code for ${upiConfig.upiId} amount ₹${upiConfig.paymentAmount}`}
                          width={160} 
                          height={160}
                          className="mx-auto my-1 rounded-sm border-2 border-primary p-1 bg-white"
                          unoptimized 
                      />
                  ) : (
                      <div className="h-[160px] w-[160px] mx-auto my-1 flex items-center justify-center bg-muted rounded-sm">
                          <Loader2 className="h-8 w-8 animate-spin text-primary" />
                      </div>
                  )}
                  <div className="flex items-center justify-center space-x-2 mt-1 mb-2"> 
                      <p className="text-base sm:text-lg font-mono text-accent p-2 border border-dashed border-accent rounded-sm break-all">
                      {upiConfig.upiId}
                      </p>
                      <Button variant="ghost" size="icon" onClick={() => copyToClipboard(upiConfig.upiId, "UPI ID")} aria-label="Copy UPI ID" className="text-foreground hover:text-accent">
                          <Copy className="h-5 w-5" />
                      </Button>
                  </div>
                </div>
                
                <Separator className="my-3 border-border/50" />

                <div className="space-y-1"> 
                  <Label htmlFor="utrNumber" className="text-foreground text-sm sm:text-base">UTR / Transaction ID</Label>
                  <Input
                    id="utrNumber"
                    type="text"
                    value={utrNumber}
                    onChange={(e) => setUtrNumber(e.target.value)}
                    placeholder="Enter 12-digit payment transaction ID here"
                    className="bg-input text-foreground placeholder:text-muted-foreground text-sm sm:text-base py-2 sm:py-2.5"
                    disabled={isVerifying || verificationStatus === 'verified' || verificationStatus === 'loading_config' || !upiConfig}
                  />
                </div>
                
                <Separator className="my-3 border-border/50" />

                <div className="space-y-1 p-2 sm:p-2.5 border-2 border-accent/30 rounded-lg bg-muted/20 shadow-sm">
                  <h4 className="text-sm sm:text-md font-bold text-accent flex items-center">
                    <HelpCircle className="h-4 sm:h-5 w-4 sm:h-5 mr-1.5" />
                    भुगतान कैसे करें (Payment Guide in Hindi)
                  </h4>
                  <ol className="list-none space-y-0.5 text-xs sm:text-sm text-muted-foreground pl-0.5">
                    <li className="flex items-start break-words py-0.5">
                      <QrCode className="h-3.5 w-3.5 mr-1.5 mt-0.5 text-primary shrink-0"/>
                      दिए गए QR कोड को स्कैन करें, या UPI ID (<strong className="text-accent mx-1">{upiConfig.upiId}</strong>) और राशि (<strong className="text-accent mx-1">₹{upiConfig.paymentAmount}</strong>) नोट करें (आप स्क्रीनशॉट ले सकते हैं)।
                    </li>
                     <li className="flex items-start break-words py-0.5">
                      <Send className="h-3.5 w-3.5 mr-1.5 mt-0.5 text-primary shrink-0"/>
                      अपने पसंदीदा UPI ऐप (Google Pay, PhonePe, Paytm, आदि) से भुगतान करें।
                    </li>
                    <li className="flex items-start break-words py-0.5">
                      <Type className="h-3.5 w-3.5 mr-1.5 mt-0.5 text-primary shrink-0"/>
                      भुगतान सफल होने पर, प्राप्त <strong className="text-accent mx-1">UTR/ट्रांजैक्शन ID</strong> को ऊपर दिए गए बॉक्स में दर्ज करें।
                    </li>
                    <li className="flex items-start break-words py-0.5">
                      <Send className="h-3.5 w-3.5 mr-1.5 mt-0.5 text-primary shrink-0"/>
                      <strong className="text-accent mx-1">"Request Verification"</strong> (सत्यापन का अनुरोध करें) बटन पर क्लिक करें।
                    </li>
                    <li className="flex items-start break-words py-0.5">
                      <Clock className="h-3.5 w-3.5 mr-1.5 mt-0.5 text-primary shrink-0"/>
                      कृपया कम से कम <strong className="text-accent mx-1">1 मिनट</strong> प्रतीक्षा करें। सिस्टम एडमिन से जांच करेगा।
                    </li>
                    <li className="flex items-start break-words py-0.5">
                      <MessageSquare className="h-3.5 w-3.5 mr-1.5 mt-0.5 text-primary shrink-0"/>
                      यदि <strong className="text-accent mx-1">2 मिनट</strong> से अधिक "Pending Review" दिखे, तो "Retry Verification" पर क्लिक करें। समस्या बनी रहने पर, अपने Username, Platform और UTR के साथ WhatsApp (<strong className="text-accent mx-1">{WHATSAPP_CONTACT_NUMBER}</strong>) पर संपर्क करें: <a href={`https://wa.me/${WHATSAPP_CONTACT_NUMBER.replace(/\s+/g, '')}?text=${encodeURIComponent(`Namaste, Maine ${APP_NAME} ke liye payment kiya hai. Username: ${username}, Platform: ${platform}, UTR: [Apka_UTR_Yahan]`)}`} target="_blank" rel="noopener noreferrer" className="underline text-primary hover:text-primary/80 font-semibold ml-1 flex items-center">Click to Chat <Send className="inline-block ml-1 h-3 w-3"/></a>
                    </li>
                  </ol>
                </div>
                
                { (verificationStatus === 'pending_review' || verificationStatus === 'rejected' || (verificationStatus === 'failed' && !!upiConfig)) && (
                     <div className="text-center text-xs sm:text-sm text-muted-foreground p-2 border border-dashed border-border/70 rounded-md bg-muted/30 mt-2"> 
                        <div className="flex items-center justify-center mb-0.5">
                            {verificationStatus === 'pending_review' && <Clock className="h-4 w-4 mr-2 text-accent animate-pulse" />}
                            {(verificationStatus === 'rejected' || (verificationStatus === 'failed' && !!upiConfig)) && <AlertTriangle className="h-4 w-4 mr-2 text-destructive" />}
                            Status: <span className={`font-semibold ml-1 ${
                                verificationStatus === 'pending_review' ? 'text-accent' :
                                verificationStatus === 'rejected' ? 'text-destructive' :
                                verificationStatus === 'failed' ? 'text-destructive' : ''
                            }`}>
                                {verificationStatus === 'pending_review' ? 'Awaiting Admin Review' : 
                                 verificationStatus === 'rejected' ? 'Payment Rejected by Admin' :
                                 'Verification System Error'}
                            </span>
                        </div>
                         <p className="text-xs break-words">
                            {verificationStatus === 'pending_review' && "Admin has been notified. You can retry verification shortly (after 1-2 mins)."}
                            {verificationStatus === 'rejected' && "Please check your UTR or try a new payment. "}
                            {(verificationStatus === 'failed' && !!upiConfig) && "A system error occurred. "}
                            For persistent issues, check the guide above or contact support.
                        </p>
                    </div>
                )}
              </>
            )}
          </div>
          <ScrollBar orientation="vertical" />
        </ScrollArea>
        <DialogFooter className="sm:justify-center flex-col sm:flex-row gap-2 pt-4">
          {renderFooterContent()}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

