
'use client';
import type { ReactNode } from 'react';
import { usePathname } from 'next/navigation';
import { Header } from './header';
import { Toaster } from "@/components/ui/toaster";
import { APP_NAME } from '@/lib/constants';

interface MainLayoutProps {
  children: ReactNode;
}

export function MainLayout({ children }: MainLayoutProps) {
  const pathname = usePathname();

  // Don't render MainLayout for admin or manager routes, as they have their own layouts
  if (pathname?.startsWith('/admin') || pathname?.startsWith('/manager')) {
    return <>{children}</>;
  }

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-6 md:py-8">
        {children}
      </main>
      <footer className="py-3 text-center text-xs md:text-sm text-muted-foreground border-t border-border">
        &gt;&gt; System Status: Online | &copy; {new Date().getFullYear()} {APP_NAME}. For simulation purposes only. &lt;&lt;
      </footer>
      <Toaster />
    </div>
  );
}
