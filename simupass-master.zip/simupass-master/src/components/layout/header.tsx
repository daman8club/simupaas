
import { Terminal, LineChart } from 'lucide-react'; // Using Terminal for hacker theme, LineChart for Manager
import Link from 'next/link';
import { APP_NAME } from '@/lib/constants';

export function Header() {
  return (
    <header className="py-3 px-4 md:px-6 border-b border-border shadow-md bg-card">
      <div className="container mx-auto flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 text-xl md:text-2xl font-bold text-primary hover:text-primary/80 transition-colors">
          <Terminal className="h-7 w-7 md:h-8 md:w-8 text-primary" /> {/* Hacker icon */}
          <span>{APP_NAME}</span>
        </Link>
        <nav className="hidden md:flex gap-4 items-center"> {/* Added items-center */}
            <Link href="/" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Home</Link>
            <Link href="/admin" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Admin Panel</Link>
            <Link href="/manager" className="text-sm text-muted-foreground hover:text-foreground transition-colors flex items-center">
              <LineChart className="mr-1 h-4 w-4"/> Manager Panel
            </Link>
        </nav>
        <p className="text-xs md:text-sm text-muted-foreground hidden sm:block">/* Simulated System Access Portal */</p>
      </div>
    </header>
  );
}
