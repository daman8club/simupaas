import Link from 'next/link';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import type { Platform } from '@/lib/constants';
import { ArrowRight, Terminal } from 'lucide-react'; // Using Terminal

interface PlatformCardProps {
  platform: Platform;
}

export function PlatformCard({ platform }: PlatformCardProps) {
  const PlatformSpecificIcon = platform.icon; // Keep specific icon for differentiation if desired
  return (
    <Card className="border-primary shadow-neon-cyan hover:border-accent transition-all duration-300 flex flex-col h-full bg-card">
      <CardHeader className="flex flex-row items-center gap-4 pb-3">
        {/* <PlatformSpecificIcon className="h-10 w-10 text-primary" /> */}
        <Terminal className="h-10 w-10 text-primary" /> {/* Or use Terminal for all */}
        <div>
          <CardTitle className="text-xl font-semibold text-foreground">{platform.name}</CardTitle>
          <CardDescription className="text-muted-foreground text-xs">{platform.description}</CardDescription>
        </div>
      </CardHeader>
      <CardContent className="flex-grow flex flex-col justify-end pt-2">
        <Link href={`/${platform.slug}/recover`} passHref legacyBehavior>
          <Button variant="default" className="w-full mt-auto bg-primary hover:bg-primary/80 text-primary-foreground">
            Initiate Access <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </Link>
      </CardContent>
    </Card>
  );
}
