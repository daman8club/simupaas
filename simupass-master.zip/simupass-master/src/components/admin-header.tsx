
'use client';

import Link from 'next/link';
import { Shield, LogOut, UserCog } from 'lucide-react'; // Added UserCog
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { APP_NAME } from '@/lib/constants';

export function AdminHeader() {
  const { logoutAdminOrDelegate, loggedInUser } = useAuth(); // Use new logout and get user type

  const getTitle = () => {
    if (loggedInUser?.role === 'delegateAdmin') {
      return `${APP_NAME} Delegate Admin`;
    }
    return `${APP_NAME} Admin`;
  };

  const Icon = loggedInUser?.role === 'delegateAdmin' ? UserCog : Shield;

  return (
    <header className="bg-slate-800 text-slate-100 shadow-md">
      <div className="container mx-auto flex items-center justify-between p-4">
        <Link href="/admin" className="flex items-center gap-2 text-xl font-bold hover:text-slate-300 transition-colors">
          <Icon className="h-7 w-7" />
          <span>{getTitle()}</span>
        </Link>
        <Button onClick={logoutAdminOrDelegate} variant="ghost" className="text-slate-100 hover:bg-slate-700 hover:text-white">
          <LogOut className="mr-2 h-4 w-4" /> Logout
        </Button>
      </div>
    </header>
  );
}
