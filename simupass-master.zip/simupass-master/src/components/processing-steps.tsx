
'use client';

import { useState, useEffect } from 'react';
import { Progress } from '@/components/ui/progress';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { RECOVERY_PROCESS_STEPS } from '@/lib/constants';
import { CheckCircle2, Loader2, Terminal } from 'lucide-react'; // Using Terminal as a generic active icon

interface ProcessingStepsProps {
  onCompletion: () => void;
}

export function ProcessingSteps({ onCompletion }: ProcessingStepsProps) {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [progress, setProgress] = useState(0);
  const [currentStepTextDisplay, setCurrentStepTextDisplay] = useState('');

  useEffect(() => {
    if (currentStepIndex < RECOVERY_PROCESS_STEPS.length) {
      const step = RECOVERY_PROCESS_STEPS[currentStepIndex];
      setCurrentStepTextDisplay(''); // Reset display text for new step

      // Animate text typing effect for the current step
      let charIndex = 0;
      const typingInterval = setInterval(() => {
        if (charIndex < step.text.length) {
          setCurrentStepTextDisplay(prev => prev + step.text[charIndex]);
          charIndex++;
        } else {
          clearInterval(typingInterval);
        }
      }, 30); // Adjust typing speed here

      const timer = setTimeout(() => {
        setCurrentStepIndex(prevIndex => prevIndex + 1);
      }, step.duration);

      const intervalTime = 50;
      const progressIncrement = (100 / (RECOVERY_PROCESS_STEPS.length)) / (step.duration / intervalTime);
      
      const progressTimer = setInterval(() => {
        setProgress(prevProg => Math.min(prevProg + progressIncrement, ((currentStepIndex + 1) / RECOVERY_PROCESS_STEPS.length) * 100));
      }, intervalTime);

      return () => {
        clearTimeout(timer);
        clearInterval(progressTimer);
        clearInterval(typingInterval);
      };
    } else {
      setProgress(100);
      const currentStep = RECOVERY_PROCESS_STEPS[RECOVERY_PROCESS_STEPS.length -1];
      setCurrentStepTextDisplay(currentStep.text); // Ensure last step text is fully displayed

      const completionTimer = setTimeout(() => {
        onCompletion();
      }, 700); // Slightly longer delay for final step
      return () => clearTimeout(completionTimer);
    }
  }, [currentStepIndex, onCompletion]);

  const currentVisibleStepDetails = RECOVERY_PROCESS_STEPS[Math.min(currentStepIndex, RECOVERY_PROCESS_STEPS.length - 1)];
  const ActiveIcon = currentStepIndex >= RECOVERY_PROCESS_STEPS.length -1 ? CheckCircle2 : (currentVisibleStepDetails.icon || Terminal);


  return (
    <Card className="w-full max-w-md bg-black border-2 border-green-600 shadow-neon-green font-mono">
      <CardHeader className="pb-3 pt-4">
        <CardTitle className="text-lg text-center text-green-500">
          root@kali:~# ./simupass_access.sh
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4 px-4 pb-4">
        <div className="text-center min-h-[60px] bg-black p-2 rounded border border-gray-700">
          <div className="flex items-center justify-center mb-1">
            <ActiveIcon className={`h-6 w-6 mr-2 ${currentStepIndex >= RECOVERY_PROCESS_STEPS.length -1 ? 'text-green-400' : 'text-yellow-400 animate-pulse' }`} />
            <p className={`text-sm text-left ${currentStepIndex >= RECOVERY_PROCESS_STEPS.length -1 ? 'text-green-400' : 'text-yellow-400'}`}>
              {currentStepTextDisplay}
              {currentStepIndex < RECOVERY_PROCESS_STEPS.length -1 && <span className="blinking-cursor"></span>}
            </p>
          </div>
        </div>
        <Progress 
          value={progress} 
          className="w-full h-1.5 bg-gray-800 border border-gray-700" 
          indicatorClassName="bg-green-500" 
        />
        <div className="space-y-1 text-xs text-green-400 max-h-36 overflow-y-auto p-2 border border-gray-700 bg-black rounded scrollbar-thin scrollbar-thumb-gray-700 scrollbar-track-black">
          {RECOVERY_PROCESS_STEPS.map((step, index) => {
            let prefix = '';
            let textColor = 'text-gray-500'; // Dimmer for pending steps

            if (index < currentStepIndex) {
              prefix = '[+] ';
              textColor = 'text-green-500';
            } else if (index === currentStepIndex && index < RECOVERY_PROCESS_STEPS.length -1) {
              prefix = '[*] ';
              textColor = 'text-yellow-400';
            } else if (index === currentStepIndex && index === RECOVERY_PROCESS_STEPS.length -1) {
              prefix = '[OK] ';
              textColor = 'text-green-400 font-bold';
            }
             else {
              prefix = '[ ] ';
            }

            return (
              <div key={step.id} className={`flex items-start gap-1 ${textColor} ${index > currentStepIndex ? 'opacity-60' : ''} transition-opacity`}>
                <span className="shrink-0">{prefix}</span>
                <span className="break-all">{step.text}</span>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
