
'use client';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, Send, User } from 'lucide-react';

const usernameFormSchema = z.object({
  username: z.string().trim().min(3, 'Username must be at least 3 characters.').max(50, 'Username cannot exceed 50 characters.'),
});

type UsernameFormValues = z.infer<typeof usernameFormSchema>;

interface UsernameFormProps {
  platformName: string;
  onSubmit: (values: UsernameFormValues) => void;
  isLoading: boolean;
}

export function UsernameForm({ platformName, onSubmit, isLoading }: UsernameFormProps) {
  const form = useForm<UsernameFormValues>({
    resolver: zodResolver(usernameFormSchema),
    defaultValues: {
      username: '',
    },
  });

  return (
    <Card className="border-primary shadow-neon-cyan">
      <CardHeader>
        <CardTitle className="text-xl text-primary flex items-center">
          <User className="mr-2 h-5 w-5" /> Target Identifier
        </CardTitle>
        <CardDescription className="text-muted-foreground">
          Enter the username for the {platformName} account simulation.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
            <FormField
              control={form.control}
              name="username"
              render={({ field }) => (
                <FormItem>
                  <FormLabel htmlFor="username" className="text-sm font-medium text-foreground">
                    {platformName} Username:
                  </FormLabel>
                  <FormControl>
                    <Input
                      id="username"
                      placeholder={`target_${platformName.toLowerCase()}_id`}
                      {...field}
                      className="text-base bg-input text-foreground placeholder:text-muted-foreground focus:border-accent"
                      aria-describedby="username-message"
                    />
                  </FormControl>
                  <FormMessage id="username-message" className="text-destructive/80" />
                </FormItem>
              )}
            />
            <Button type="submit" disabled={isLoading} className="w-full text-md py-2.5 bg-primary text-primary-foreground hover:bg-primary/80">
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Initializing...
                </>
              ) : (
                <>
                  Initiate <Send className="ml-2 h-4 w-4" />
                </>
              )}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
