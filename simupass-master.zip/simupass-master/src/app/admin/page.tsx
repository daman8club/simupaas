
'use client';

import { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useToast } from '@/hooks/use-toast';
import { Settings, CreditCard, ListChecks, UserCheck, UserX, RefreshCw, Loader2, KeyRound, ShieldCheck, ShieldAlert, Building, Globe } from 'lucide-react';
import {
  getUpiConfiguration,
  updateUpiConfiguration,
  type UpdateUpiConfigurationInput,
  type UpiConfiguration,
  approvePayment,
  rejectPayment,
  type PaymentActionInput,
  listPendingPayments,
  type ListPendingPaymentsOutput
} from '@/ai/flows/admin-actions';
import { Separator } from '@/components/ui/separator';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { APP_NAME } from '@/lib/constants';
import { formatDistanceToNow } from 'date-fns';
import { useAuth } from '@/contexts/AuthContext';
import { ScrollArea } from '@/components/ui/scroll-area';

const upiConfigFormSchema = z.object({
  newUpiId: z.string().trim().min(5, 'UPI ID must be at least 5 characters long.'),
  newPaymentAmount: z.string().trim().refine(val => !isNaN(parseFloat(val)) && parseFloat(val) > 0, {
    message: "Amount must be a positive number.",
  }),
});
type UpiConfigFormValues = z.infer<typeof upiConfigFormSchema>;

const paymentActionFormSchema = z.object({
  usernameToAction: z.string().trim().min(1, 'Username is required.'),
});
type PaymentActionFormValues = z.infer<typeof paymentActionFormSchema>;

const adminPasswordUpdateFormSchema = z.object({
  currentPasswordAdmin: z.string().min(1, "Current password is required."),
  newPasswordAdmin: z.string().min(6, "New password must be at least 6 characters."),
  confirmNewPasswordAdmin: z.string(),
}).refine(data => data.newPasswordAdmin === data.confirmNewPasswordAdmin, {
  message: "New passwords don't match.",
  path: ["confirmNewPasswordAdmin"],
});
type AdminPasswordUpdateFormValues = z.infer<typeof adminPasswordUpdateFormSchema>;


const POLLING_INTERVAL = 10000; // 10 seconds

export default function AdminDashboardPage() {
  const { toast } = useToast();
  const { 
    updatePasswordAdmin,
    loggedInUser,
    currentDelegateAdminPermissions
  } = useAuth(); 
  
  const [upiConfig, setUpiConfig] = useState<UpiConfiguration | null>(null);
  const [isUpiConfigLoading, setIsUpiConfigLoading] = useState<boolean>(true);
  const [isUpiConfigSubmitting, setIsUpiConfigSubmitting] = useState<boolean>(false);
  
  const [pendingPayments, setPendingPayments] = useState<ListPendingPaymentsOutput['users']>([]);
  const [isLoadingPending, setIsLoadingPending] = useState<boolean>(true);
  const [isProcessingPayment, setIsProcessingPayment] = useState<{username: string, utr: string, action: 'approve' | 'reject'} | null>(null);
  const [isPasswordUpdating, setIsPasswordUpdating] = useState<boolean>(false);

  // Determine access rights based on role and permissions
  const isPrimaryAdmin = loggedInUser?.role === 'admin';
  const canManageUpi = isPrimaryAdmin || (loggedInUser?.role === 'delegateAdmin' && currentDelegateAdminPermissions?.canManageUpiConfig);
  const canVerifyPayments = isPrimaryAdmin || (loggedInUser?.role === 'delegateAdmin' && currentDelegateAdminPermissions?.canHandlePendingVerifications);

  const upiConfigForm = useForm<UpiConfigFormValues>({
    resolver: zodResolver(upiConfigFormSchema),
    defaultValues: { newUpiId: '', newPaymentAmount: '' },
  });
  
  const adminPasswordUpdateForm = useForm<AdminPasswordUpdateFormValues>({
    resolver: zodResolver(adminPasswordUpdateFormSchema),
    defaultValues: { currentPasswordAdmin: '', newPasswordAdmin: '', confirmNewPasswordAdmin: '' },
  });

  const paymentActionForm = useForm<PaymentActionFormValues>({ 
    resolver: zodResolver(paymentActionFormSchema),
    defaultValues: { usernameToAction: '' },
  });


  const fetchUpiConfig = useCallback(async () => {
    if (!canManageUpi) {
      setIsUpiConfigLoading(false);
      setUpiConfig(null);
      return;
    }
    setIsUpiConfigLoading(true);
    try {
      const config = await getUpiConfiguration();
      setUpiConfig(config);
      upiConfigForm.reset({ newUpiId: config.upiId, newPaymentAmount: config.paymentAmount.toString() });
    } catch (error) {
      console.error('Failed to load UPI config:', error);
      toast({ title: 'Error Loading UPI Config', description: 'Could not fetch UPI settings.', variant: 'destructive' });
      setUpiConfig({upiId: 'Error', paymentAmount: 'Error'});
    } finally {
      setIsUpiConfigLoading(false);
    }
  }, [toast, upiConfigForm, canManageUpi]);
  
  const fetchPendingPayments = useCallback(async (showLoadingIndicator = true) => {
    if (!canVerifyPayments) {
      setIsLoadingPending(false);
      setPendingPayments([]);
      return;
    }
    if(showLoadingIndicator) setIsLoadingPending(true);
    try {
      const pendingData = await listPendingPayments();
      setPendingPayments(pendingData.users);
    } catch (error) {
      console.error('Failed to load pending payments:', error);
      toast({ title: 'Error Loading Pending Payments', description: 'Could not fetch pending payments list.', variant: 'destructive' });
      setPendingPayments([]); 
    } finally {
      if(showLoadingIndicator) setIsLoadingPending(false);
    }
  }, [toast, canVerifyPayments]);

  useEffect(() => {
    if (canManageUpi) fetchUpiConfig();
    if (canVerifyPayments) {
      fetchPendingPayments(true);
      const intervalId = setInterval(() => fetchPendingPayments(false), POLLING_INTERVAL);
      return () => clearInterval(intervalId);
    }
  }, [fetchUpiConfig, fetchPendingPayments, canManageUpi, canVerifyPayments]); 

  const handleUpiConfigSubmit = async (values: UpiConfigFormValues) => {
    if (!canManageUpi) return;
    setIsUpiConfigSubmitting(true);
    try {
      const input: UpdateUpiConfigurationInput = { 
        newUpiId: values.newUpiId, 
        newPaymentAmount: values.newPaymentAmount 
      };
      const result = await updateUpiConfiguration(input);
      if (result.success) {
        toast({ title: 'UPI Configuration Updated', description: result.message, variant: 'default' });
        setUpiConfig({ upiId: result.upiId!, paymentAmount: result.paymentAmount! }); 
        upiConfigForm.reset({ newUpiId: result.upiId!, newPaymentAmount: result.paymentAmount! });
      } else {
        toast({ title: 'Update Failed', description: result.message, variant: 'destructive' });
      }
    } catch (error) {
      console.error('Error updating UPI config:', error);
      toast({ title: 'Error', description: 'An unexpected error occurred.', variant: 'destructive' });
    } finally {
      setIsUpiConfigSubmitting(false);
    }
  };

  const processPaymentAction = async (username: string, utr: string, platform: string, action: 'approve' | 'reject') => {
    if (!canVerifyPayments) return;
    setIsProcessingPayment({ username, utr, action });
    try {
      const input: PaymentActionInput = { username, utr, platform }; 
      const result = action === 'approve' ? await approvePayment(input) : await rejectPayment(input);
      
      if (result.success) {
        toast({ title: `Payment ${action === 'approve' ? 'Approved' : 'Rejected'}`, description: result.message, variant: 'default' });
        fetchPendingPayments(false); 
        if (action === 'approve' || action === 'reject') paymentActionForm.reset(); 
      } else {
        toast({ title: `${action === 'approve' ? 'Approval' : 'Rejection'} Failed`, description: result.message, variant: 'destructive' });
      }
    } catch (error) {
      console.error(`Error ${action}ing payment:`, error);
      toast({ title: 'Error', description: `An unexpected error occurred.`, variant: 'destructive' });
    } finally {
      setIsProcessingPayment(null);
    }
  };
  
  const handleManualPaymentAction = async (values: PaymentActionFormValues, action: 'approve' | 'reject') => {
    if (!canVerifyPayments) return;
    await processPaymentAction(values.usernameToAction, 'N/A - Manual', 'admin_panel_manual', action);
  };

  const handleAdminPasswordUpdate = async (values: AdminPasswordUpdateFormValues) => {
    if (!isPrimaryAdmin) return;
    setIsPasswordUpdating(true);
    const result = await updatePasswordAdmin(values.currentPasswordAdmin, values.newPasswordAdmin);
    if (result.success) {
        toast({ title: 'Admin Password Updated', description: result.message, variant: 'default'});
        adminPasswordUpdateForm.reset();
    } else {
        toast({ title: 'Admin Password Update Failed', description: result.message, variant: 'destructive'});
    }
    setIsPasswordUpdating(false);
  };


  return (
    <div className="space-y-8">
      <Card className="shadow-lg border-slate-200 bg-white">
        <CardHeader>
          <CardTitle className="text-3xl text-slate-800 flex items-center">
            <ShieldCheck className="mr-3 h-8 w-8 text-blue-600" /> {APP_NAME} {loggedInUser?.role === 'delegateAdmin' ? 'Delegate Admin' : 'Admin'} Dashboard
          </CardTitle>
          <CardDescription className="text-slate-600">Manage application settings and user payment verifications.</CardDescription>
        </CardHeader>
      </Card>

      <div className="grid lg:grid-cols-3 gap-8 items-start">
        <div className="lg:col-span-2 space-y-8">
          {canManageUpi && (
            <Card className="shadow-md border-slate-200 bg-white">
              <CardHeader>
                <CardTitle className="text-2xl text-slate-700 flex items-center"><Settings className="mr-2 h-6 w-6 text-blue-500" />UPI & Payment Configuration</CardTitle>
                <CardDescription className="text-slate-500">Set the master UPI ID and payment amount for user simulations.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {isUpiConfigLoading ? (
                  <div className="flex items-center justify-center p-4">
                    <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
                    <span className="ml-2 text-slate-500">Loading configuration...</span>
                  </div>
                ) : upiConfig ? (
                  <div>
                    <h3 className="text-lg font-semibold text-slate-700">Current Settings:</h3>
                    <div className="p-3 border border-dashed border-slate-300 rounded bg-slate-50 space-y-1 mt-1">
                      <p><span className="font-medium text-slate-600">UPI ID:</span> <span className="font-mono text-blue-600">{upiConfig.upiId}</span></p>
                      <p><span className="font-medium text-slate-600">Amount (INR):</span> <span className="font-mono text-blue-600">₹{upiConfig.paymentAmount}</span></p>
                    </div>
                  </div>
                ) : (
                   <p className="text-red-600 p-4 bg-red-50 border border-red-200 rounded">Could not load UPI configuration. Please check console and ensure backend is running.</p>
                )}
                <Separator className="my-6 bg-slate-200" />
                <Form {...upiConfigForm}>
                  <form onSubmit={upiConfigForm.handleSubmit(handleUpiConfigSubmit)} className="space-y-4">
                    <FormField
                      control={upiConfigForm.control}
                      name="newUpiId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel htmlFor="newUpiId" className="text-slate-700 font-medium">Update UPI ID</FormLabel>
                          <FormControl>
                            <Input id="newUpiId" placeholder="Enter new UPI ID" {...field} className="bg-white border-slate-300 text-slate-900 placeholder:text-slate-400 focus:ring-blue-500 focus:border-blue-500" />
                          </FormControl>
                          <FormMessage className="text-red-600" />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={upiConfigForm.control}
                      name="newPaymentAmount"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel htmlFor="newPaymentAmount" className="text-slate-700 font-medium">Update Payment Amount (INR)</FormLabel>
                          <FormControl>
                            <Input id="newPaymentAmount" type="number" step="0.01" placeholder="Enter new amount" {...field} className="bg-white border-slate-300 text-slate-900 placeholder:text-slate-400 focus:ring-blue-500 focus:border-blue-500" />
                          </FormControl>
                          <FormMessage className="text-red-600" />
                        </FormItem>
                      )}
                    />
                    <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2.5" disabled={isUpiConfigSubmitting || isUpiConfigLoading}>
                      {isUpiConfigSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <CreditCard className="mr-2 h-4 w-4" />}
                      {isUpiConfigSubmitting ? 'Saving...' : 'Save Configuration'}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          )}

          {isPrimaryAdmin && (
            <Card className="shadow-md border-slate-200 bg-white">
              <CardHeader>
                <CardTitle className="text-2xl text-slate-700 flex items-center"><KeyRound className="mr-2 h-6 w-6 text-blue-500" />Admin Password</CardTitle>
                 <CardDescription className="text-slate-500">Update the password for accessing this admin panel.</CardDescription>
              </CardHeader>
              <CardContent>
                 <Form {...adminPasswordUpdateForm}>
                  <form onSubmit={adminPasswordUpdateForm.handleSubmit(handleAdminPasswordUpdate)} className="space-y-4">
                      <FormField
                          control={adminPasswordUpdateForm.control}
                          name="currentPasswordAdmin"
                          render={({ field }) => (
                          <FormItem>
                              <FormLabel className="text-slate-700 font-medium">Current Admin Password</FormLabel>
                              <FormControl>
                              <Input type="password" {...field} className="bg-white border-slate-300 text-slate-900 focus:ring-blue-500 focus:border-blue-500"/>
                              </FormControl>
                              <FormMessage className="text-red-600" />
                          </FormItem>
                          )}
                      />
                      <FormField
                          control={adminPasswordUpdateForm.control}
                          name="newPasswordAdmin"
                          render={({ field }) => (
                          <FormItem>
                              <FormLabel className="text-slate-700 font-medium">New Admin Password</FormLabel>
                              <FormControl>
                              <Input type="password" {...field} className="bg-white border-slate-300 text-slate-900 focus:ring-blue-500 focus:border-blue-500"/>
                              </FormControl>
                              <FormMessage className="text-red-600" />
                          </FormItem>
                          )}
                      />
                      <FormField
                          control={adminPasswordUpdateForm.control}
                          name="confirmNewPasswordAdmin"
                          render={({ field }) => (
                          <FormItem>
                              <FormLabel className="text-slate-700 font-medium">Confirm New Admin Password</FormLabel>
                              <FormControl>
                              <Input type="password" {...field} className="bg-white border-slate-300 text-slate-900 focus:ring-blue-500 focus:border-blue-500"/>
                              </FormControl>
                              <FormMessage className="text-red-600" />
                          </FormItem>
                          )}
                      />
                      <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2.5" disabled={isPasswordUpdating}>
                          {isPasswordUpdating ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <KeyRound className="mr-2 h-4 w-4" />}
                          {isPasswordUpdating ? 'Updating...' : 'Update Admin Password'}
                      </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          )}
        </div>
        
        <div className="lg:col-span-1">
          {canVerifyPayments && (
            <Card className="shadow-md border-slate-200 bg-white">
            <CardHeader className="flex flex-row items-center justify-between pb-3 border-b">
                <CardTitle className="text-xl text-slate-700 flex items-center"><ListChecks className="mr-2 h-5 w-5 text-blue-500" />Pending Verifications</CardTitle>
                <Button onClick={() => fetchPendingPayments(true)} variant="ghost" size="sm" disabled={isLoadingPending && !pendingPayments.length} className="text-blue-600 hover:bg-blue-50 hover:text-blue-700">
                    <RefreshCw className={`mr-1 h-4 w-4 ${isLoadingPending && !pendingPayments.length ? 'animate-spin': ''}`} /> Refresh
                </Button>
            </CardHeader>
            <CardContent className="pt-4 space-y-3">
                {isLoadingPending && pendingPayments.length === 0 ? (
                <div className="flex flex-col items-center justify-center p-6 min-h-[150px] text-slate-500">
                    <Loader2 className="h-10 w-10 animate-spin text-blue-500 mb-3" />
                    <span>Loading pending payments...</span>
                </div>
                ) : pendingPayments.length > 0 ? (
                <ScrollArea className="h-[350px] border rounded-md">
                    <Table>
                    <TableHeader className="bg-slate-50 sticky top-0">
                        <TableRow>
                        <TableHead className="text-slate-600 font-semibold px-3 py-2">User</TableHead>
                        <TableHead className="text-slate-600 font-semibold px-3 py-2">UTR</TableHead>
                        <TableHead className="text-slate-600 font-semibold px-3 py-2">Platform</TableHead>
                        <TableHead className="text-slate-600 font-semibold px-3 py-2">Pending</TableHead>
                        <TableHead className="text-right text-slate-600 font-semibold px-3 py-2">Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {pendingPayments.map((payment) => (
                        <TableRow key={payment.username + payment.utr} className="hover:bg-slate-50/70">
                            <TableCell className="font-medium text-slate-700 px-3 py-2.5">{payment.username}</TableCell>
                            <TableCell className="font-mono text-xs text-slate-500 break-all max-w-[80px] truncate px-3 py-2.5" title={payment.utr}>{payment.utr}</TableCell>
                            <TableCell className="text-xs text-slate-500 capitalize px-3 py-2.5">
                                {payment.platform.replace(/_/g, ' ') || 'N/A'}
                            </TableCell>
                            <TableCell className="text-xs text-slate-500 whitespace-nowrap px-3 py-2.5">
                            {formatDistanceToNow(new Date(payment.timestamp), { addSuffix: true })}
                            </TableCell>
                            <TableCell className="text-right space-x-1 px-3 py-2.5">
                            <Button
                                variant="ghost"
                                size="sm"
                                className="text-green-600 hover:text-green-700 hover:bg-green-100 px-2 py-1 h-auto text-xs"
                                onClick={() => processPaymentAction(payment.username, payment.utr, payment.platform, 'approve')}
                                disabled={isProcessingPayment?.utr === payment.utr || !canVerifyPayments}
                            >
                                {isProcessingPayment?.utr === payment.utr && isProcessingPayment.action === 'approve' ? (
                                <Loader2 className="mr-1 h-3 w-3 animate-spin" /> 
                                ) : (
                                <UserCheck className="mr-1 h-3 w-3" />
                                )}
                                Approve
                            </Button>
                            <Button
                                variant="ghost"
                                size="sm"
                                className="text-red-600 hover:text-red-700 hover:bg-red-100 px-2 py-1 h-auto text-xs"
                                onClick={() => processPaymentAction(payment.username, payment.utr, payment.platform, 'reject')}
                                disabled={isProcessingPayment?.utr === payment.utr || !canVerifyPayments}
                            >
                                {isProcessingPayment?.utr === payment.utr && isProcessingPayment.action === 'reject' ? (
                                <Loader2 className="mr-1 h-3 w-3 animate-spin" />
                                ) : (
                                <UserX className="mr-1 h-3 w-3" />
                                )}
                                Reject
                            </Button>
                            </TableCell>
                        </TableRow>
                        ))}
                    </TableBody>
                    </Table>
                </ScrollArea>
                ) : (
                <div className="text-slate-500 p-6 text-center min-h-[150px] flex flex-col items-center justify-center border border-dashed rounded-md">
                    <Globe className="h-10 w-10 text-slate-400 mb-3" /> {/* Changed icon to Globe */}
                    No payments currently pending admin approval.
                </div>
                )}
                
                <Separator className="my-4 bg-slate-200" />
                <Form {...paymentActionForm}>
                    <form className="space-y-3">
                        <FormField
                            control={paymentActionForm.control}
                            name="usernameToAction"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel htmlFor="usernameToAction" className="text-slate-700 font-medium">Manual Action by Username</FormLabel>
                                    <FormControl>
                                        <Input id="usernameToAction" placeholder="Enter username" {...field} className="bg-white border-slate-300 text-slate-900 placeholder:text-slate-400 focus:ring-blue-500 focus:border-blue-500"/>
                                    </FormControl>
                                    <FormMessage className="text-red-600"/>
                                </FormItem>
                            )}
                        />
                        <div className="flex gap-2">
                        <Button 
                            type="button" 
                            onClick={paymentActionForm.handleSubmit(values => handleManualPaymentAction(values, 'approve'))} 
                            className="flex-1 bg-green-600 hover:bg-green-700 text-white" 
                            disabled={!!isProcessingPayment || !paymentActionForm.formState.isValid || isProcessingPayment?.utr === 'N/A - Manual' || !canVerifyPayments}
                        >
                            {isProcessingPayment && isProcessingPayment.action === 'approve' && isProcessingPayment.utr === 'N/A - Manual' ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <UserCheck className="mr-2 h-4 w-4" />}
                            {isProcessingPayment && isProcessingPayment.action === 'approve' && isProcessingPayment.utr === 'N/A - Manual' ? 'Processing...' : 'Force Approve'}
                        </Button>
                        <Button 
                            type="button" 
                            onClick={paymentActionForm.handleSubmit(values => handleManualPaymentAction(values, 'reject'))} 
                            variant="destructive" 
                            className="flex-1 bg-red-600 hover:bg-red-700" 
                            disabled={!!isProcessingPayment || !paymentActionForm.formState.isValid || isProcessingPayment?.utr === 'N/A - Manual' || !canVerifyPayments}
                        >
                           {isProcessingPayment && isProcessingPayment.action === 'reject' && isProcessingPayment.utr === 'N/A - Manual' ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <UserX className="mr-2 h-4 w-4" />}
                           {isProcessingPayment && isProcessingPayment.action === 'reject' && isProcessingPayment.utr === 'N/A - Manual' ? 'Processing...' : 'Force Reject'}
                        </Button>
                        </div>
                    </form>
                </Form>
            </CardContent>
            </Card>
          )}
        </div>
      </div>
      
      {!isPrimaryAdmin && !canManageUpi && !canVerifyPayments && loggedInUser?.role === 'delegateAdmin' && (
        <Card className="shadow-md border-slate-200 bg-white mt-8">
            <CardHeader className="flex flex-row items-center space-x-3">
                <ShieldAlert className="h-8 w-8 text-orange-500" />
                <div>
                    <CardTitle className="text-xl text-slate-700">Access Restricted</CardTitle>
                    <CardDescription className="text-slate-500">Your assigned permissions are limited.</CardDescription>
                </div>
            </CardHeader>
            <CardContent>
                <p className="text-slate-600">You do not have permissions to manage UPI configuration or handle payment verifications. If you believe this is an error, please contact the primary manager.</p>
            </CardContent>
        </Card>
      )}
    </div>
  );
}
