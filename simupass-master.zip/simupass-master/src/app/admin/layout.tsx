
'use client';

import type { ReactNode } from 'react';
import { useEffect } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import { useAuth } from '@/contexts/AuthContext';
import { AdminHeader } from '@/components/admin-header';
import { Toaster } from '@/components/ui/toaster'; // Ensure Toaster is available for admin toasts

export default function AdminLayout({ children }: { children: ReactNode }) {
  const { loggedInUser } = useAuth();
  const router = useRouter();
  const pathname = usePathname();

  const canAccessAdminArea = loggedInUser && (loggedInUser.role === 'admin' || loggedInUser.role === 'delegateAdmin');

  useEffect(() => {
    // Redirection logic is handled by the AuthContext's useEffect now
    // This effect can be simplified or removed if AuthContext covers all edge cases,
    // but this acts as a final check.
    if (!canAccessAdminArea && pathname !== '/admin/login') {
      // router.push('/admin/login'); // AuthContext should handle this
    } else if (canAccessAdminArea && pathname === '/admin/login') {
      // router.push('/admin'); // AuthContext should handle this
    }
  }, [canAccessAdminArea, router, pathname]);

  if (!canAccessAdminArea && pathname !== '/admin/login') {
    return (
        <div className="flex items-center justify-center min-h-screen bg-slate-100">
            <p className="text-slate-700">Loading Admin Panel...</p> 
        </div>
    );
  }
  
  if (pathname === '/admin/login') {
      return (
        <div className="admin-theme-wrapper"> 
          {children}
          <Toaster /> 
        </div>
      );
  }

  return (
    <div className="admin-theme-wrapper">
      <AdminHeader />
      <main className="container mx-auto p-4 md:p-8">
        {children}
      </main>
      <Toaster />
      <footer className="py-4 text-center text-xs text-slate-500 border-t border-slate-200">
        &copy; {new Date().getFullYear()} {process.env.NEXT_PUBLIC_APP_NAME || "SimuPass"} Admin Panel.
      </footer>
    </div>
  );
}
