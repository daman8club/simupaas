import { PlatformCard } from '@/components/platform-card';
import { PLATFORMS } from '@/lib/constants';
import { Terminal } from 'lucide-react'; // Changed icon

export default function HomePage() {
  return (
    <div className="flex flex-col items-center p-4">
      <div className="text-center mb-10 md:mb-16">
        <Terminal className="h-16 w-16 md:h-20 md:w-20 text-primary mx-auto mb-4 animate-pulse" />
        <h1 className="text-3xl md:text-4xl font-bold text-primary mb-3">
          Welcome to {process.env.NEXT_PUBLIC_APP_NAME || "SimuPass"} v2.0
        </h1>
        <p className="text-md md:text-lg text-muted-foreground max-w-lg md:max-w-xl mx-auto">
          Select a target system below to initiate simulated access protocol.
          <br className="hidden sm:block" />
          <span className="italic">// For demonstration &amp; educational purposes only.</span>
        </p>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 md:gap-8 w-full max-w-3xl">
        {PLATFORMS.map((platform) => (
          <PlatformCard key={platform.slug} platform={platform} />
        ))}
      </div>
    </div>
  );
}
