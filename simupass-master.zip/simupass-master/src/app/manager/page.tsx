
'use client';

import { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from '@/hooks/use-toast';
import { LineChart, Users, ListFilter, Search, Activity, BarChart3, UserSquare2, Landmark, AlertCircle, Loader2, DatabaseZap, CalendarDays, Download, Coins, TrendingUp, Clock, CheckCircle2, ShieldAlert } from 'lucide-react';
import { format, parseISO, isValid } from 'date-fns';
import { DateRange } from 'react-day-picker';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import {
  getUserSimulationCounts, type UserSimulationCountsOutput,
  getUsernamesByPlatform, type UsernamesByPlatformInput, type UsernamesByPlatformOutput,
  getTransactionHistory, type TransactionHistoryInput, type TransactionHistoryOutput, type TransactionSummary,
  type PaymentTransaction
} from '@/ai/flows/manager-actions';
import { PLATFORMS, APP_NAME } from '@/lib/constants';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import { useAuth } from '@/contexts/AuthContext'; // Corrected import path

const platformOptions = [{ value: 'all', label: 'All Platforms' }, ...PLATFORMS.map(p => ({ value: p.slug, label: p.name }))];
const statusOptions = [
  { value: 'all', label: 'All Statuses' },
  { value: 'pending', label: 'Pending' },
  { value: 'approved', label: 'Approved' },
  { value: 'rejected', label: 'Rejected' },
];

interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ElementType;
  description?: string;
  className?: string;
  iconClassName?: string;
}

const StatCard: React.FC<StatCardProps> = ({ title, value, icon: Icon, description, className, iconClassName }) => {
  return (
    <Card className={cn("shadow-md hover:shadow-lg transition-shadow duration-300", className)}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium ">{title}</CardTitle>
        <Icon className={cn("h-5 w-5 text-slate-400", iconClassName)} />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        {description && <p className="text-xs text-muted-foreground pt-1">{description}</p>}
      </CardContent>
    </Card>
  );
};


export default function ManagerDashboardPage() {
  const { toast } = useToast();
  const { loggedInUser, currentDelegateAdminPermissions } = useAuth(); // Get user and permissions

  // Determine access rights
  const isPrimaryManager = loggedInUser?.role === 'manager';
  const canViewOverview = isPrimaryManager || (currentDelegateAdminPermissions?.canViewManagerOverview ?? false);
  const canViewUserActivity = isPrimaryManager || (currentDelegateAdminPermissions?.canViewManagerUserActivity ?? false);
  const canViewTransactions = isPrimaryManager || (currentDelegateAdminPermissions?.canViewManagerTransactions ?? false);

  const [simulationCounts, setSimulationCounts] = useState<UserSimulationCountsOutput | null>(null);
  const [platformUsers, setPlatformUsers] = useState<UsernamesByPlatformOutput['users']>([]);
  const [transactionData, setTransactionData] = useState<TransactionHistoryOutput | null>(null);

  const [isLoadingSimCounts, setIsLoadingSimCounts] = useState(true);
  const [isLoadingPlatformUsers, setIsLoadingPlatformUsers] = useState(true);
  const [isLoadingTransactions, setIsLoadingTransactions] = useState(true);

  const [selectedPlatformForUsers, setSelectedPlatformForUsers] = useState<string>('all');
  const [transactionFilters, setTransactionFilters] = useState<TransactionHistoryInput>({ status: 'all' });
  const [searchTerm, setSearchTerm] = useState('');
  const [dateRange, setDateRange] = useState<DateRange | undefined>(undefined);

  const fetchSimulationCounts = useCallback(async () => {
    if (!canViewOverview) { setIsLoadingSimCounts(false); return; }
    setIsLoadingSimCounts(true);
    try {
      const data = await getUserSimulationCounts();
      setSimulationCounts(data);
    } catch (error) {
      console.error("Error fetching simulation counts:", error);
      toast({ title: "Error", description: "Could not fetch user simulation counts.", variant: "destructive" });
    } finally {
      setIsLoadingSimCounts(false);
    }
  }, [toast, canViewOverview]);

  const fetchPlatformUsers = useCallback(async (platform?: string) => {
    if (!canViewUserActivity) { setIsLoadingPlatformUsers(false); return; }
    setIsLoadingPlatformUsers(true);
    try {
      const input: UsernamesByPlatformInput = { platform: platform === 'all' ? undefined : platform };
      const data = await getUsernamesByPlatform(input);
      setPlatformUsers(data.users);
    } catch (error) {
      console.error("Error fetching platform users:", error);
      toast({ title: "Error", description: "Could not fetch platform users.", variant: "destructive" });
    } finally {
      setIsLoadingPlatformUsers(false);
    }
  }, [toast, canViewUserActivity]);

  const fetchTransactions = useCallback(async (filters: TransactionHistoryInput) => {
    if (!canViewTransactions) { setIsLoadingTransactions(false); return; }
    setIsLoadingTransactions(true);
    try {
      const data = await getTransactionHistory(filters);
      setTransactionData(data);
    } catch (error) {
      console.error("Error fetching transactions:", error);
      toast({ title: "Error", description: "Could not fetch transaction history.", variant: "destructive" });
    } finally {
      setIsLoadingTransactions(false);
    }
  }, [toast, canViewTransactions]);
  
  useEffect(() => {
    if (canViewOverview) fetchSimulationCounts();
    if (canViewUserActivity) fetchPlatformUsers(selectedPlatformForUsers);
    if (canViewTransactions) fetchTransactions(transactionFilters); 
  }, [fetchSimulationCounts, fetchPlatformUsers, fetchTransactions, canViewOverview, canViewUserActivity, canViewTransactions, selectedPlatformForUsers, transactionFilters]); 

  const handleUserPlatformFilterChange = (platform: string) => {
    setSelectedPlatformForUsers(platform);
    if (canViewUserActivity) fetchPlatformUsers(platform); 
  };

  const handleTransactionFilterChange = (key: keyof TransactionHistoryInput, value: string) => {
    const newFilters = { ...transactionFilters, [key]: value === 'all' ? undefined : value };
    setTransactionFilters(newFilters);
  };
  
  const applyTransactionFilters = () => {
    if (!canViewTransactions) return;
    const filtersToApply: TransactionHistoryInput = { ...transactionFilters };
    if (searchTerm.trim()) {
        filtersToApply.username = searchTerm.trim();
    } else {
        filtersToApply.username = undefined; 
    }
    if (dateRange?.from) {
        filtersToApply.startDate = format(dateRange.from, 'yyyy-MM-dd');
    } else {
        filtersToApply.startDate = undefined;
    }
    if (dateRange?.to) {
        filtersToApply.endDate = format(dateRange.to, 'yyyy-MM-dd');
    } else {
        filtersToApply.endDate = undefined;
    }
    if (filtersToApply.status && !['pending', 'approved', 'rejected'].includes(filtersToApply.status)) {
        filtersToApply.status = 'all';
    }
    fetchTransactions(filtersToApply);
  };

  const todayDate = format(new Date(), 'PPP');

  const exportTransactionsToCSV = () => {
    if (!transactionData || !transactionData.transactions.length) {
      toast({ title: "No Data", description: "No transactions to export.", variant: "default" });
      return;
    }
    const headers = ["Timestamp", "Username", "Platform", "UTR", "Amount", "Status"];
    const rows = transactionData.transactions.map(tx => [
      format(new Date(tx.timestamp), 'yyyy-MM-dd HH:mm:ss'),
      tx.username,
      tx.platform,
      `"${tx.utr}"`, 
      tx.amount,
      tx.status
    ].join(','));

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `simupass_transactions_${format(new Date(), 'yyyyMMddHHmmss')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast({ title: "Export Successful", description: "Transactions exported to CSV.", variant: "default" });
  };

  const renderSimulationCounts = () => {
    if (isLoadingSimCounts || !simulationCounts) return <div className="flex items-center text-slate-500 p-4"><Loader2 className="mr-2 h-5 w-5 animate-spin" />Loading simulation stats...</div>;
    
    return (
      <div className="space-y-4">
        <div className="grid gap-4 md:grid-cols-3">
            <StatCard title="Simulations Today" value={simulationCounts.totalToday} icon={TrendingUp} description={todayDate} className="bg-sky-50 border-sky-200 text-sky-800" iconClassName="text-sky-500"/>
            <StatCard title="Simulations This Week" value={simulationCounts.totalThisWeek} icon={TrendingUp} description="Current week" className="bg-indigo-50 border-indigo-200 text-indigo-800" iconClassName="text-indigo-500"/>
            <StatCard title="Simulations This Month" value={simulationCounts.totalThisMonth} icon={TrendingUp} description="Current month" className="bg-purple-50 border-purple-200 text-purple-800" iconClassName="text-purple-500"/>
        </div>
        {simulationCounts.byDatePlatform.length > 0 && (
           <details className="mt-2">
            <summary className="cursor-pointer text-sm text-primary hover:underline">View Daily Breakdown by Platform</summary>
            <ScrollArea className="h-[200px] md:h-[250px] mt-1 border p-2 rounded-md bg-slate-50">
                {simulationCounts.byDatePlatform.map(item => (
                    <p key={`${item.date}-${item.platform}`} className="text-xs py-0.5 text-slate-700">
                        {format(parseISO(item.date), 'MMM dd, yyyy')} - {item.platform}: {item.count}
                    </p>
                ))}
            </ScrollArea>
          </details>
        )}
      </div>
    );
  };

  const renderEarningsStats = () => {
    if (isLoadingTransactions || !transactionData) return <div className="flex items-center text-slate-500 p-4"><Loader2 className="mr-2 h-5 w-5 animate-spin" />Loading earnings data...</div>;
    
    return (
      <div className="grid gap-4 md:grid-cols-3">
        <StatCard title="Earnings Today" value={`₹${transactionData.dailyEarnings.toFixed(2)}`} icon={Coins} description={todayDate} className="bg-green-100 border-green-300 text-green-800" iconClassName="text-green-600"/>
        <StatCard title="Earnings This Week" value={`₹${transactionData.weeklyEarnings.toFixed(2)}`} icon={Coins} description="Current week" className="bg-emerald-100 border-emerald-300 text-emerald-800" iconClassName="text-emerald-600"/>
        <StatCard title="Earnings This Month" value={`₹${transactionData.monthlyEarnings.toFixed(2)}`} icon={Coins} description="Current month" className="bg-teal-100 border-teal-300 text-teal-800" iconClassName="text-teal-600"/>
      </div>
    );
  }

  const renderPlatformUsers = () => {
    if (isLoadingPlatformUsers) return <div className="flex items-center text-slate-500 p-4"><Loader2 className="mr-2 h-4 w-4 animate-spin" />Loading users...</div>;
    if (!platformUsers.length) return <p className="text-slate-500 p-4">No users found for the selected platform.</p>;
    return (
      <ScrollArea className="h-[300px] md:h-[450px] border rounded-md">
        <Table>
          <TableHeader className="bg-slate-100 sticky top-0">
            <TableRow>
              <TableHead className="text-slate-700 font-semibold">Username</TableHead>
              <TableHead className="text-slate-700 font-semibold">Platform</TableHead>
              <TableHead className="text-slate-700 font-semibold">Last Simulation</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {platformUsers.map((user, idx) => (
              <TableRow key={`${user.username}-${user.platform}-${idx}`} className="hover:bg-slate-50">
                <TableCell className="text-slate-800 font-medium">{user.username}</TableCell>
                <TableCell className="text-slate-700 capitalize">{user.platform.replace('-', ' ')}</TableCell>
                <TableCell className="text-slate-600 text-xs">{format(new Date(user.lastInteraction), 'PPpp')}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </ScrollArea>
    );
  };

  const renderTransactions = () => {
    if (isLoadingTransactions || !transactionData) return <div className="flex items-center text-slate-500 p-4"><Loader2 className="mr-2 h-5 w-5 animate-spin" />Loading transactions...</div>;
    
    const { transactions, summary } = transactionData;

    if (!transactions.length && !isLoadingTransactions) return <p className="text-slate-500 p-4">No transactions found for the current filters.</p>;
    return (
      <div className="space-y-4">
        <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-4">
            <StatCard title="Total Displayed" value={summary.totalTransactions} icon={ListFilter} className="bg-slate-100 border-slate-300 text-slate-800" iconClassName="text-slate-500" />
            <StatCard title="Approved" value={`${summary.approvedCount} (₹${summary.approvedValue.toFixed(2)})`} icon={CheckCircle2} className="bg-green-100 border-green-300 text-green-800" iconClassName="text-green-600"/>
            <StatCard title="Pending" value={summary.pendingCount} icon={Clock} className="bg-amber-100 border-amber-300 text-amber-800" iconClassName="text-amber-600"/>
            <StatCard title="Rejected" value={summary.rejectedCount} icon={AlertCircle} className="bg-red-100 border-red-300 text-red-800" iconClassName="text-red-600"/>
        </div>
        <ScrollArea className="h-[400px] md:h-[500px] border rounded-md">
            <Table>
            <TableHeader className="bg-slate-100 sticky top-0">
                <TableRow>
                <TableHead className="text-slate-700 font-semibold">Timestamp</TableHead>
                <TableHead className="text-slate-700 font-semibold">Username</TableHead>
                <TableHead className="text-slate-700 font-semibold">Platform</TableHead>
                <TableHead className="text-slate-700 font-semibold">UTR</TableHead>
                <TableHead className="text-slate-700 font-semibold">Amount</TableHead>
                <TableHead className="text-slate-700 font-semibold">Status</TableHead>
                </TableRow>
            </TableHeader>
            <TableBody>
                {transactions.map((tx: PaymentTransaction, idx: number) => (
                <TableRow key={`${tx.utr}-${tx.timestamp}-${idx}`} className="hover:bg-slate-50">
                    <TableCell className="text-xs text-slate-600">{format(new Date(tx.timestamp), 'PPpp')}</TableCell>
                    <TableCell className="text-slate-800 font-medium">{tx.username}</TableCell>
                    <TableCell className="text-slate-700 capitalize">{tx.platform.replace('-', ' ')}</TableCell>
                    <TableCell className="font-mono text-xs text-slate-500 break-all max-w-[100px] truncate" title={tx.utr}>{tx.utr}</TableCell>
                    <TableCell className="text-slate-800 font-semibold">₹{tx.amount}</TableCell>
                    <TableCell>
                    <span className={`px-2 py-0.5 text-xs rounded-full font-medium ${
                        tx.status === 'approved' ? 'bg-green-100 text-green-700 border border-green-200' :
                        tx.status === 'rejected' ? 'bg-red-100 text-red-700 border border-red-200' :
                        'bg-amber-100 text-amber-700 border border-amber-200' // Changed yellow to amber for better contrast
                    }`}>
                        {tx.status}
                    </span>
                    </TableCell>
                </TableRow>
                ))}
            </TableBody>
            </Table>
        </ScrollArea>
         <Button onClick={exportTransactionsToCSV} variant="outline" className="border-primary text-primary hover:bg-primary/10" disabled={isLoadingTransactions || !transactions.length}>
            <Download className="mr-2 h-4 w-4" /> Export to CSV
        </Button>
      </div>
    );
  };

  const visibleTabs: { value: string; label: string; icon: React.ElementType; condition: boolean }[] = [
    { value: "overview", label: "Overview", icon: BarChart3, condition: canViewOverview },
    { value: "userActivity", label: "User Activity", icon: UserSquare2, condition: canViewUserActivity },
    { value: "transactions", label: "Transactions", icon: Landmark, condition: canViewTransactions },
  ].filter(tab => tab.condition);

  const defaultTabValue = visibleTabs.length > 0 ? visibleTabs[0].value : "restricted";

  if (!isPrimaryManager && visibleTabs.length === 0) {
    return (
        <Card className="shadow-lg border-slate-200 bg-white">
            <CardHeader className="flex flex-row items-center space-x-3">
                <ShieldAlert className="h-8 w-8 text-orange-500" />
                <div>
                    <CardTitle className="text-xl text-slate-700">Access Restricted</CardTitle>
                    <CardDescription className="text-slate-500">You do not have permissions to view any sections of the Manager Panel.</CardDescription>
                </div>
            </CardHeader>
            <CardContent>
                <p className="text-slate-600">Please contact the primary manager if you believe this is an error.</p>
            </CardContent>
        </Card>
    );
  }


  return (
    <div className="space-y-6">
      <Card className="shadow-lg border-slate-200 bg-white">
        <CardHeader>
          <CardTitle className="text-3xl text-slate-800 flex items-center">
            <LineChart className="mr-3 h-8 w-8 text-primary" /> {APP_NAME} {loggedInUser?.role === 'delegateAdmin' ? 'Manager Dashboard (Delegate View)' : 'Manager Dashboard'}
          </CardTitle>
          <CardDescription className="text-slate-600">Monitor user activity and payment transactions.</CardDescription>
        </CardHeader>
      </Card>

      <Tabs defaultValue={defaultTabValue} className="w-full">
        <TabsList className={cn(
            "grid w-full mb-4 bg-slate-100 p-1 rounded-lg",
            `grid-cols-1 sm:grid-cols-${visibleTabs.length > 0 ? visibleTabs.length : 1}` // Stack on mobile if multiple tabs
          )}>
          {visibleTabs.map(tab => (
            <TabsTrigger 
              key={tab.value} 
              value={tab.value} 
              className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-md rounded-md h-10"
            >
              <tab.icon className="mr-2 h-5 w-5"/>{tab.label}
            </TabsTrigger>
          ))}
        </TabsList>

        {canViewOverview && (
          <TabsContent value="overview">
            <Card className="bg-white shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center text-xl text-slate-700"><Activity className="mr-2 text-primary"/>Successful Simulation Counts</CardTitle>
              </CardHeader>
              <CardContent>
                {renderSimulationCounts()}
              </CardContent>
            </Card>
            <Card className="mt-6 bg-white shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center text-xl text-slate-700"><Coins className="mr-2 text-green-600"/>Earnings Summary (from Approved Transactions)</CardTitle>
              </CardHeader>
              <CardContent>
                {renderEarningsStats()}
              </CardContent>
            </Card>
          </TabsContent>
        )}

        {canViewUserActivity && (
          <TabsContent value="userActivity">
            <Card className="bg-white shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center text-xl text-slate-700"><Users className="mr-2 text-primary"/>Users by Platform</CardTitle>
                <div className="pt-2">
                  <Label htmlFor="platformFilterUsers" className="text-xs text-slate-600">Filter by Platform</Label>
                  <Select onValueChange={handleUserPlatformFilterChange} value={selectedPlatformForUsers}>
                    <SelectTrigger id="platformFilterUsers" className="w-full md:w-[280px] bg-white border-slate-300 text-slate-900">
                      <SelectValue placeholder="Filter by platform..." />
                    </SelectTrigger>
                    <SelectContent>
                      {platformOptions.map(opt => (
                        <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>
              <CardContent>
                {renderPlatformUsers()}
              </CardContent>
            </Card>
          </TabsContent>
        )}

        {canViewTransactions && (
          <TabsContent value="transactions">
            <Card className="bg-white shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center text-xl text-slate-700"><ListFilter className="mr-2 text-primary"/>Payment Transaction Log</CardTitle>
                <CardDescription className="text-slate-500">Filter and view payment transaction history.</CardDescription>
                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-end pt-4 border-t mt-4">
                  <div>
                    <Label htmlFor="searchTerm" className="text-xs text-slate-600 block mb-1">Search Username</Label>
                    <Input 
                      id="searchTerm"
                      placeholder="Username..." 
                      value={searchTerm} 
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="h-10 bg-white border-slate-300 text-slate-900"
                    />
                  </div>
                  <div>
                    <Label htmlFor="filterPlatformTx" className="text-xs text-slate-600 block mb-1">Platform</Label>
                    <Select 
                      value={transactionFilters.platform || 'all'}
                      onValueChange={(val) => handleTransactionFilterChange('platform', val)}
                    >
                      <SelectTrigger id="filterPlatformTx" className="h-10 bg-white border-slate-300 text-slate-900">
                        <SelectValue placeholder="Platform" />
                      </SelectTrigger>
                      <SelectContent>
                        {platformOptions.map(opt => (
                          <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                   <div>
                    <Label htmlFor="filterStatusTx" className="text-xs text-slate-600 block mb-1">Status</Label>
                    <Select
                      value={transactionFilters.status || 'all'}
                      onValueChange={(val) => handleTransactionFilterChange('status', val as TransactionHistoryInput['status'])}
                    >
                      <SelectTrigger id="filterStatusTx" className="h-10 bg-white border-slate-300 text-slate-900">
                        <SelectValue placeholder="Status" />
                      </SelectTrigger>
                      <SelectContent>
                        {statusOptions.map(opt => (
                          <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                   <div>
                      <Label htmlFor="dateRange" className="text-xs text-slate-600 block mb-1">Date Range</Label>
                      <Popover>
                          <PopoverTrigger asChild>
                          <Button
                              id="dateRange"
                              variant={"outline"}
                              className={cn(
                              "h-10 w-full justify-start text-left font-normal bg-white border-slate-300 hover:bg-slate-50 text-slate-900",
                              !dateRange && "text-slate-500"
                              )}
                          >
                              <CalendarDays className="mr-2 h-4 w-4" />
                              {dateRange?.from ? (
                              dateRange.to ? (
                                  <>{format(dateRange.from, "LLL dd, y")} - {format(dateRange.to, "LLL dd, y")}</>
                              ) : (
                                  format(dateRange.from, "LLL dd, y")
                              )
                              ) : (
                              <span>Pick a date range</span>
                              )}
                          </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0 bg-white" align="start">
                          <Calendar
                              initialFocus
                              mode="range"
                              defaultMonth={dateRange?.from}
                              selected={dateRange}
                              onSelect={setDateRange}
                              numberOfMonths={2}
                          />
                          </PopoverContent>
                      </Popover>
                  </div>
                  <Button onClick={applyTransactionFilters} className="h-10 bg-primary hover:bg-primary/90 text-primary-foreground lg:col-span-4" disabled={isLoadingTransactions}>
                      {isLoadingTransactions ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Search className="mr-2 h-4 w-4" />} 
                      Apply Filters
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {renderTransactions()}
              </CardContent>
               <CardFooter className="justify-end">
                  <p className="text-xs text-slate-500">
                      {isLoadingTransactions && (!transactionData || !transactionData.transactions.length) ? "Loading transactions..." : transactionData ? `Showing ${transactionData.transactions.length} of ${transactionData.summary.totalTransactions} matching transactions.` : "No transactions to display."}
                  </p>
              </CardFooter>
            </Card>
          </TabsContent>
        )}
        {visibleTabs.length === 0 && loggedInUser?.role === 'delegateAdmin' && (
           <TabsContent value="restricted">
                <Card className="shadow-lg border-slate-200 bg-white">
                    <CardHeader className="flex flex-row items-center space-x-3">
                        <ShieldAlert className="h-8 w-8 text-orange-500" />
                        <div>
                            <CardTitle className="text-xl text-slate-700">Access Restricted</CardTitle>
                            <CardDescription className="text-slate-500">You do not have permissions to view any sections of the Manager Panel.</CardDescription>
                        </div>
                    </CardHeader>
                    <CardContent>
                        <p className="text-slate-600">Please contact the primary manager if you believe this is an error.</p>
                    </CardContent>
                </Card>
           </TabsContent>
        )}
      </Tabs>
      
      <Card className="mt-6 border-teal-600 bg-teal-50/50 shadow">
        <CardHeader className="flex flex-row items-center gap-3">
            <DatabaseZap className="h-6 w-6 text-teal-700"/>
            <CardTitle className="text-teal-800 text-lg">Data Storage & Functionality Note</CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-teal-700 space-y-1">
            <p>Manager Panel data (user activity and transaction logs) is persistently stored in Firebase Firestore.</p>
            <p>Authentication for this panel supports both primary managers and authorized delegate admins with specific view permissions.</p>
        </CardContent>
      </Card>
    </div>
  );
}

