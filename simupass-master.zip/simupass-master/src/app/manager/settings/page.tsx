
'use client';

import { useState, useEffect, useCallback } from 'react';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { APP_NAME } from '@/lib/constants';
import { KeyRound, UserCog, Loader2, ShieldAlert, Users, Trash2, Edit3, PlusCircle, Settings, XCircle, CheckCircle2, Eye, EyeOff, CreditCard, ListChecks, type LucideIcon } from 'lucide-react';
import type { Role } from '@/ai/flows/credential-actions';
// Import only the TYPE for DelegateAdminPermissions
import { type ManagedAdmin, type DelegateAdminPermissions } from '@/ai/flows/delegate-admin-actions';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog";


// --- Zod Schemas for Forms ---
const baseCredentialFormSchema = {
  username: z.string().trim().min(3, 'Username must be at least 3 characters.').max(50, 'Username cannot exceed 50 characters.'),
  newPassword: z.string().min(6, "New password must be at least 6 characters.").optional().or(z.literal('')),
  confirmNewPassword: z.string().optional().or(z.literal('')),
};

const managerSettingsFormSchema = z.object({
  ...baseCredentialFormSchema,
  currentPassword: z.string().min(1, "Current password is required to make changes."),
}).refine(data => data.newPassword === data.confirmNewPassword, {
  message: "New passwords don't match.",
  path: ["confirmNewPassword"],
}).refine(data => !data.newPassword || data.currentPassword, { 
  message: "Current password is required to set a new password.",
  path: ["currentPassword"]
});
type ManagerSettingsFormValues = z.infer<typeof managerSettingsFormSchema>;

const primaryAdminSettingsFormSchema = z.object({ 
  ...baseCredentialFormSchema,
}).refine(data => data.newPassword === data.confirmNewPassword, {
  message: "New passwords don't match.",
  path: ["confirmNewPassword"],
});
type PrimaryAdminSettingsFormValues = z.infer<typeof primaryAdminSettingsFormSchema>;

// Define the permissions schema on the client-side for form validation
const clientSideDelegateAdminPermissionsSchema = z.object({
  canManageUpiConfig: z.boolean().default(false).describe("Allow managing UPI & Payment Configuration in Admin Panel."),
  canHandlePendingVerifications: z.boolean().default(false).describe("Allow handling pending verifications in Admin Panel."),
  canViewManagerOverview: z.boolean().default(false).describe("Allow viewing Overview Stats in Manager Panel."),
  canViewManagerUserActivity: z.boolean().default(false).describe("Allow viewing User Activity in Manager Panel."),
  canViewManagerTransactions: z.boolean().default(false).describe("Allow viewing Transactions Detail in Manager Panel."),
});


const delegateAdminFormSchema = z.object({
  username: z.string().trim().min(3, "Username must be 3-50 characters.").max(50, "Username too long."),
  password: z.string().min(6, "Password must be at least 6 characters."),
  confirmPassword: z.string(),
  permissions: clientSideDelegateAdminPermissionsSchema,
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords don't match.",
  path: ["confirmPassword"],
});
type DelegateAdminFormValues = z.infer<typeof delegateAdminFormSchema>;

const editDelegateAdminPermissionsFormSchema = z.object({
  permissions: clientSideDelegateAdminPermissionsSchema,
});
type EditDelegateAdminPermissionsFormValues = z.infer<typeof editDelegateAdminPermissionsFormSchema>;

const resetDelegateAdminPasswordFormSchema = z.object({
  newPassword: z.string().min(6, "New password must be at least 6 characters."),
  confirmNewPassword: z.string(),
}).refine(data => data.newPassword === data.confirmNewPassword, {
  message: "Passwords don't match.",
  path: ["confirmNewPassword"],
});
type ResetDelegateAdminPasswordFormValues = z.infer<typeof resetDelegateAdminPasswordFormSchema>;


const permissionLabels: Record<keyof DelegateAdminPermissions, string> = {
  canManageUpiConfig: "Manage UPI Config",
  canHandlePendingVerifications: "Handle Verifications",
  canViewManagerOverview: "View Manager Overview",
  canViewManagerUserActivity: "View Manager User Activity",
  canViewManagerTransactions: "View Manager Transactions",
};
const permissionIcons: Record<keyof DelegateAdminPermissions, LucideIcon> = {
  canManageUpiConfig: CreditCard,
  canHandlePendingVerifications: ListChecks,
  canViewManagerOverview: Eye, 
  canViewManagerUserActivity: Users,
  canViewManagerTransactions: EyeOff, // Changed to EyeOff for variety
};


export default function ManagerSettingsPage() {
  const { toast } = useToast();
  const { 
    getRoleCredential, 
    updateUserCredentialsByManager, 
    isManagerLoggedIn, 
    managerUsername,
    listDelegateAdmins,
    createDelegateAdmin,
    updateDelegateAdmin,
    deleteDelegateAdmin,
  } = useAuth();

  const [isLoadingManagerData, setIsLoadingManagerData] = useState(true);
  const [isLoadingPrimaryAdminData, setIsLoadingPrimaryAdminData] = useState(true);
  const [isSubmittingManager, setIsSubmittingManager] = useState(false);
  const [isSubmittingPrimaryAdmin, setIsSubmittingPrimaryAdmin] = useState(false);

  const [delegateAdmins, setDelegateAdmins] = useState<ManagedAdmin[]>([]);
  const [isLoadingDelegateAdmins, setIsLoadingDelegateAdmins] = useState(true);
  const [isSubmittingDelegateAdmin, setIsSubmittingDelegateAdmin] = useState(false);
  
  const [isAddDelegateAdminDialogOpen, setIsAddDelegateAdminDialogOpen] = useState(false);
  const [editingDelegateAdmin, setEditingDelegateAdmin] = useState<ManagedAdmin | null>(null);
  const [isEditPermissionsDialogOpen, setIsEditPermissionsDialogOpen] = useState(false);
  const [isResetPasswordDialogOpen, setIsResetPasswordDialogOpen] = useState(false);


  const managerForm = useForm<ManagerSettingsFormValues>({
    resolver: zodResolver(managerSettingsFormSchema),
    defaultValues: { username: '', currentPassword: '', newPassword: '', confirmNewPassword: '' },
  });

  const primaryAdminForm = useForm<PrimaryAdminSettingsFormValues>({
    resolver: zodResolver(primaryAdminSettingsFormSchema),
    defaultValues: { username: '', newPassword: '', confirmNewPassword: '' },
  });

  const addDelegateAdminForm = useForm<DelegateAdminFormValues>({
    resolver: zodResolver(delegateAdminFormSchema),
    defaultValues: {
      username: '', password: '', confirmPassword: '',
      permissions: {
        canManageUpiConfig: false,
        canHandlePendingVerifications: false,
        canViewManagerOverview: false,
        canViewManagerUserActivity: false,
        canViewManagerTransactions: false,
      }
    }
  });

  const editPermissionsForm = useForm<EditDelegateAdminPermissionsFormValues>({
    resolver: zodResolver(editDelegateAdminPermissionsFormSchema),
  });
  
  const resetPasswordForm = useForm<ResetDelegateAdminPasswordFormValues>({
      resolver: zodResolver(resetDelegateAdminPasswordFormSchema),
      defaultValues: { newPassword: "", confirmNewPassword: "" },
  });


  const fetchPrimaryCredentials = useCallback(async (role: Role) => {
    if (!isManagerLoggedIn) return;
    if (role === 'manager') setIsLoadingManagerData(true);
    if (role === 'admin') setIsLoadingPrimaryAdminData(true);

    try {
      const result = await getRoleCredential(role);
      if (result.username) {
        if (role === 'manager') {
          managerForm.reset({ ...managerForm.getValues(), username: result.username });
        } else {
          primaryAdminForm.reset({ ...primaryAdminForm.getValues(), username: result.username });
        }
      } else {
        toast({ title: `Error Fetching ${role} Username`, description: result.error || `Could not fetch ${role} username.`, variant: 'destructive' });
      }
    } catch (error) {
      toast({ title: `Error Fetching ${role} Username`, description: `An unexpected error occurred.`, variant: 'destructive' });
    } finally {
      if (role === 'manager') setIsLoadingManagerData(false);
      if (role === 'admin') setIsLoadingPrimaryAdminData(false);
    }
  }, [isManagerLoggedIn, getRoleCredential, managerForm, primaryAdminForm, toast]);

  const fetchDelegateAdminsList = useCallback(async () => {
    if (!isManagerLoggedIn) return;
    setIsLoadingDelegateAdmins(true);
    try {
      const result = await listDelegateAdmins();
      if (result.error) {
        toast({ title: "Error Fetching Delegate Admins", description: result.error, variant: "destructive" });
        setDelegateAdmins([]);
      } else {
        setDelegateAdmins(result.admins);
      }
    } catch (error) {
       toast({ title: "Error", description: "Could not fetch delegate admins list.", variant: "destructive" });
       setDelegateAdmins([]);
    } finally {
      setIsLoadingDelegateAdmins(false);
    }
  }, [isManagerLoggedIn, listDelegateAdmins, toast]);

  useEffect(() => {
    fetchPrimaryCredentials('manager');
    fetchPrimaryCredentials('admin');
    fetchDelegateAdminsList();
  }, [fetchPrimaryCredentials, fetchDelegateAdminsList]);


  const handleManagerSettingsSubmit = async (values: ManagerSettingsFormValues) => {
    setIsSubmittingManager(true);
    const result = await updateUserCredentialsByManager(
      'manager',
      values.username,
      values.newPassword || undefined, 
      values.currentPassword
    );
    if (result.success) {
      toast({ title: 'Manager Settings Updated', description: result.message, variant: 'default' });
      managerForm.reset({ ...values, currentPassword: '', newPassword: '', confirmNewPassword: '' });
      fetchPrimaryCredentials('manager'); 
    } else {
      toast({ title: 'Update Failed', description: result.message, variant: 'destructive' });
    }
    setIsSubmittingManager(false);
  };

  const handlePrimaryAdminSettingsSubmit = async (values: PrimaryAdminSettingsFormValues) => {
    setIsSubmittingPrimaryAdmin(true);
    const result = await updateUserCredentialsByManager(
      'admin', 
      values.username,
      values.newPassword || undefined 
    );
    if (result.success) {
      toast({ title: 'Primary Admin Settings Updated', description: result.message, variant: 'default' });
      primaryAdminForm.reset({ ...values, newPassword: '', confirmNewPassword: ''}); 
      fetchPrimaryCredentials('admin');
    } else {
      toast({ title: 'Update Failed', description: result.message, variant: 'destructive' });
    }
    setIsSubmittingPrimaryAdmin(false);
  };

  const handleAddDelegateAdminSubmit = async (values: DelegateAdminFormValues) => {
    setIsSubmittingDelegateAdmin(true);
    // The managerUsername is added by the AuthContext function
    const result = await createDelegateAdmin(values); 
    if (result.success) {
      toast({ title: "Delegate Admin Created", description: result.message, variant: "default" });
      setIsAddDelegateAdminDialogOpen(false);
      addDelegateAdminForm.reset({
        username: '', password: '', confirmPassword: '',
        permissions: { // Reset permissions to default
          canManageUpiConfig: false,
          canHandlePendingVerifications: false,
          canViewManagerOverview: false,
          canViewManagerUserActivity: false,
          canViewManagerTransactions: false,
        }
      });
      fetchDelegateAdminsList();
    } else {
      toast({ title: "Creation Failed", description: result.message, variant: "destructive" });
    }
    setIsSubmittingDelegateAdmin(false);
  };

  const handleEditPermissionsSubmit = async (values: EditDelegateAdminPermissionsFormValues) => {
    if (!editingDelegateAdmin) return;
    setIsSubmittingDelegateAdmin(true);
    const result = await updateDelegateAdmin({ username: editingDelegateAdmin.username, permissions: values.permissions });
    if (result.success) {
      toast({ title: "Permissions Updated", description: result.message, variant: "default" });
      setIsEditPermissionsDialogOpen(false);
      fetchDelegateAdminsList();
    } else {
      toast({ title: "Update Failed", description: result.message, variant: "destructive" });
    }
    setEditingDelegateAdmin(null);
    setIsSubmittingDelegateAdmin(false);
  };
  
  const handleResetPasswordSubmit = async (values: ResetDelegateAdminPasswordFormValues) => {
      if (!editingDelegateAdmin) return;
      setIsSubmittingDelegateAdmin(true);
      const result = await updateDelegateAdmin({ username: editingDelegateAdmin.username, newPassword: values.newPassword });
      if (result.success) {
          toast({ title: "Password Reset", description: `Password for ${editingDelegateAdmin.username} has been reset.`, variant: "default" });
          setIsResetPasswordDialogOpen(false);
      } else {
          toast({ title: "Password Reset Failed", description: result.message, variant: "destructive" });
      }
      setEditingDelegateAdmin(null);
      setIsSubmittingDelegateAdmin(false);
  };
  
  const handleDeleteDelegateAdmin = async (username: string) => {
      const result = await deleteDelegateAdmin({ username });
      if (result.success) {
          toast({ title: "Delegate Admin Deleted", description: result.message, variant: "default" });
          fetchDelegateAdminsList();
      } else {
          toast({ title: "Deletion Failed", description: result.message, variant: "destructive" });
      }
  };

  const openEditPermissionsDialog = (admin: ManagedAdmin) => {
    setEditingDelegateAdmin(admin);
    editPermissionsForm.reset({ permissions: admin.permissions });
    setIsEditPermissionsDialogOpen(true);
  };

  const openResetPasswordDialog = (admin: ManagedAdmin) => {
    setEditingDelegateAdmin(admin);
    resetPasswordForm.reset();
    setIsResetPasswordDialogOpen(true);
  };


  return (
    <div className="space-y-6">
      <Card className="shadow-lg border-slate-200 bg-white">
        <CardHeader>
          <CardTitle className="text-3xl text-slate-800 flex items-center">
            <Settings className="mr-3 h-8 w-8 text-blue-600" /> Panel Settings
          </CardTitle>
          <CardDescription className="text-slate-600">
            Manage credentials for primary roles and delegate admin users.
          </CardDescription>
        </CardHeader>
      </Card>

      <Tabs defaultValue="managerPrimary" className="w-full">
        <TabsList className="grid w-full grid-cols-1 md:grid-cols-3 bg-slate-100">
          <TabsTrigger value="managerPrimary" className="data-[state=active]:bg-blue-500 data-[state=active]:text-white">
            <UserCog className="mr-2" />My Manager Credentials
          </TabsTrigger>
          <TabsTrigger value="adminPrimary" className="data-[state=active]:bg-blue-500 data-[state=active]:text-white">
            <ShieldAlert className="mr-2" />Primary Admin Credentials
          </TabsTrigger>
          <TabsTrigger value="delegateAdmins" className="data-[state=active]:bg-blue-500 data-[state=active]:text-white">
            <Users className="mr-2" />Delegate Admins
          </TabsTrigger>
        </TabsList>

        {/* My Manager Credentials Tab */}
        <TabsContent value="managerPrimary">
          <Card className="bg-white">
            <CardHeader>
              <CardTitle>Manage Your Credentials</CardTitle>
              <CardDescription>Update your username or password. Current password is required for any changes.</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingManagerData ? (
                <div className="flex items-center justify-center p-4"><Loader2 className="h-6 w-6 animate-spin text-blue-500" /> <span className="ml-2">Loading manager data...</span></div>
              ) : (
                <Form {...managerForm}>
                  <form onSubmit={managerForm.handleSubmit(handleManagerSettingsSubmit)} className="space-y-6">
                    <FormField control={managerForm.control} name="username" render={({ field }) => (<FormItem><FormLabel className="text-slate-700">Manager Username</FormLabel><FormControl><Input {...field} className="bg-white border-slate-300" /></FormControl><FormMessage /></FormItem>)} />
                    <FormField control={managerForm.control} name="currentPassword" render={({ field }) => (<FormItem><FormLabel className="text-slate-700">Current Password (Required)</FormLabel><FormControl><Input type="password" {...field} className="bg-white border-slate-300" /></FormControl><FormMessage /></FormItem>)} />
                    <FormField control={managerForm.control} name="newPassword" render={({ field }) => (<FormItem><FormLabel className="text-slate-700">New Password (Optional)</FormLabel><FormControl><Input type="password" placeholder="Leave blank to keep current" {...field} className="bg-white border-slate-300" /></FormControl><FormMessage /></FormItem>)} />
                    <FormField control={managerForm.control} name="confirmNewPassword" render={({ field }) => (<FormItem><FormLabel className="text-slate-700">Confirm New Password</FormLabel><FormControl><Input type="password" placeholder="Confirm if changing" {...field} className="bg-white border-slate-300" /></FormControl><FormMessage /></FormItem>)} />
                    <Button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white" disabled={isSubmittingManager || isLoadingManagerData}>
                      {isSubmittingManager ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <KeyRound className="mr-2 h-4 w-4" />}
                      {isSubmittingManager ? 'Saving...' : 'Save Manager Settings'}
                    </Button>
                  </form>
                </Form>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Primary Admin Credentials Tab */}
        <TabsContent value="adminPrimary">
          <Card className="bg-white">
            <CardHeader>
              <CardTitle>Manage Primary Admin Credentials</CardTitle>
              <CardDescription>As a manager, you can update the primary admin's username or reset their password.</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingPrimaryAdminData ? (
                 <div className="flex items-center justify-center p-4"><Loader2 className="h-6 w-6 animate-spin text-blue-500" /> <span className="ml-2">Loading primary admin data...</span></div>
              ) : (
                <Form {...primaryAdminForm}>
                  <form onSubmit={primaryAdminForm.handleSubmit(handlePrimaryAdminSettingsSubmit)} className="space-y-6">
                    <FormField control={primaryAdminForm.control} name="username" render={({ field }) => (<FormItem><FormLabel className="text-slate-700">Primary Admin Username</FormLabel><FormControl><Input {...field} className="bg-white border-slate-300" /></FormControl><FormMessage /></FormItem>)} />
                    <FormField control={primaryAdminForm.control} name="newPassword" render={({ field }) => (<FormItem><FormLabel className="text-slate-700">New Admin Password (Optional)</FormLabel><FormControl><Input type="password" placeholder="Leave blank to keep current" {...field} className="bg-white border-slate-300" /></FormControl><FormMessage /></FormItem>)} />
                    <FormField control={primaryAdminForm.control} name="confirmNewPassword" render={({ field }) => (<FormItem><FormLabel className="text-slate-700">Confirm New Admin Password</FormLabel><FormControl><Input type="password" placeholder="Confirm if changing" {...field} className="bg-white border-slate-300" /></FormControl><FormMessage /></FormItem>)} />
                    <Button type="submit" className="bg-orange-600 hover:bg-orange-700 text-white" disabled={isSubmittingPrimaryAdmin || isLoadingPrimaryAdminData}>
                      {isSubmittingPrimaryAdmin ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <KeyRound className="mr-2 h-4 w-4" />}
                      {isSubmittingPrimaryAdmin ? 'Saving...' : 'Save Primary Admin Settings'}
                    </Button>
                  </form>
                </Form>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Delegate Admins Tab */}
        <TabsContent value="delegateAdmins">
          <Card className="bg-white">
            <CardHeader className="flex flex-row justify-between items-center">
              <div>
                <CardTitle>Manage Delegate Admins</CardTitle>
                <CardDescription>Create, edit, and remove delegate admin accounts and their permissions.</CardDescription>
              </div>
              <Dialog open={isAddDelegateAdminDialogOpen} onOpenChange={setIsAddDelegateAdminDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-green-600 hover:bg-green-700 text-white">
                    <PlusCircle className="mr-2 h-4 w-4" /> Add Delegate Admin
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[525px] bg-slate-50">
                  <DialogHeader><DialogTitle>Add New Delegate Admin</DialogTitle></DialogHeader>
                  <Form {...addDelegateAdminForm}>
                    <form onSubmit={addDelegateAdminForm.handleSubmit(handleAddDelegateAdminSubmit)} className="space-y-4 py-2">
                      <FormField control={addDelegateAdminForm.control} name="username" render={({ field }) => (<FormItem><FormLabel>Username</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>)} />
                      <FormField control={addDelegateAdminForm.control} name="password" render={({ field }) => (<FormItem><FormLabel>Password</FormLabel><FormControl><Input type="password" {...field} /></FormControl><FormMessage /></FormItem>)} />
                      <FormField control={addDelegateAdminForm.control} name="confirmPassword" render={({ field }) => (<FormItem><FormLabel>Confirm Password</FormLabel><FormControl><Input type="password" {...field} /></FormControl><FormMessage /></FormItem>)} />
                      <FormItem><FormLabel>Permissions</FormLabel></FormItem>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-2 p-2 border rounded-md bg-white">
                        {(Object.keys(permissionLabels) as Array<keyof DelegateAdminPermissions>).map((key) => (
                          <FormField key={key} control={addDelegateAdminForm.control} name={`permissions.${key}`}
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-center space-x-2 space-y-0">
                                <FormControl><Checkbox checked={field.value} onCheckedChange={field.onChange} /></FormControl>
                                <FormLabel className="font-normal text-sm">{permissionLabels[key]}</FormLabel>
                              </FormItem>
                            )} />
                        ))}
                      </div>
                      <DialogFooter>
                        <DialogClose asChild><Button type="button" variant="outline">Cancel</Button></DialogClose>
                        <Button type="submit" disabled={isSubmittingDelegateAdmin} className="bg-green-600 hover:bg-green-700 text-white">
                          {isSubmittingDelegateAdmin && <Loader2 className="mr-2 h-4 w-4 animate-spin" />} Create Admin
                        </Button>
                      </DialogFooter>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              {isLoadingDelegateAdmins ? (
                 <div className="flex items-center justify-center p-4"><Loader2 className="h-6 w-6 animate-spin text-blue-500" /> <span className="ml-2">Loading delegate admins...</span></div>
              ): delegateAdmins.length === 0 ? (
                <p className="text-slate-500 text-center py-4">No delegate admins created yet.</p>
              ) : (
                <ScrollArea className="h-[400px] border rounded-md">
                  <Table>
                    <TableHeader className="bg-slate-50 sticky top-0">
                      <TableRow>
                        <TableHead>Username</TableHead>
                        <TableHead>Permissions</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {delegateAdmins.map((admin) => (
                        <TableRow key={admin.username}>
                          <TableCell className="font-medium">{admin.username}</TableCell>
                          <TableCell>
                            <div className="flex flex-wrap gap-1">
                              {(Object.keys(admin.permissions) as Array<keyof DelegateAdminPermissions>)
                                .filter(key => admin.permissions[key])
                                .map(key => {
                                  const Icon = permissionIcons[key] || Settings;
                                  return (
                                    <span key={key} title={permissionLabels[key]} className="p-1 bg-slate-100 border border-slate-200 rounded text-xs flex items-center">
                                      <Icon className="h-3 w-3 mr-1 text-slate-600"/> {permissionLabels[key]}
                                    </span>
                                  );
                                })}
                                {Object.values(admin.permissions).every(p => !p) && <span className="text-xs text-slate-400 italic">No permissions</span>}
                            </div>
                          </TableCell>
                          <TableCell className="text-right space-x-1">
                             <Dialog open={isEditPermissionsDialogOpen && editingDelegateAdmin?.username === admin.username} onOpenChange={(isOpen) => { if(!isOpen) setEditingDelegateAdmin(null); setIsEditPermissionsDialogOpen(isOpen);}}>
                                <DialogTrigger asChild><Button variant="ghost" size="sm" onClick={() => openEditPermissionsDialog(admin)} className="text-blue-600 hover:bg-blue-50 px-2 py-1 h-auto"><Edit3 className="h-4 w-4"/></Button></DialogTrigger>
                                <DialogContent className="sm:max-w-md bg-slate-50">
                                    <DialogHeader><DialogTitle>Edit Permissions for {admin.username}</DialogTitle></DialogHeader>
                                    <Form {...editPermissionsForm}>
                                        <form onSubmit={editPermissionsForm.handleSubmit(handleEditPermissionsSubmit)} className="space-y-4 py-2">
                                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-2 p-2 border rounded-md bg-white">
                                                {(Object.keys(permissionLabels) as Array<keyof DelegateAdminPermissions>).map((key) => (
                                                  <FormField key={key} control={editPermissionsForm.control} name={`permissions.${key}`}
                                                    render={({ field }) => (
                                                      <FormItem className="flex flex-row items-center space-x-2 space-y-0">
                                                        <FormControl><Checkbox checked={field.value} onCheckedChange={field.onChange} /></FormControl>
                                                        <FormLabel className="font-normal text-sm">{permissionLabels[key]}</FormLabel>
                                                      </FormItem>
                                                    )} />
                                                ))}
                                            </div>
                                            <DialogFooter>
                                                <DialogClose asChild><Button type="button" variant="outline" onClick={() => setEditingDelegateAdmin(null)}>Cancel</Button></DialogClose>
                                                <Button type="submit" disabled={isSubmittingDelegateAdmin} className="bg-blue-600 hover:bg-blue-700 text-white">Save Permissions</Button>
                                            </DialogFooter>
                                        </form>
                                    </Form>
                                </DialogContent>
                             </Dialog>
                             <Dialog open={isResetPasswordDialogOpen && editingDelegateAdmin?.username === admin.username} onOpenChange={(isOpen) => { if(!isOpen) setEditingDelegateAdmin(null); setIsResetPasswordDialogOpen(isOpen);}}>
                                <DialogTrigger asChild><Button variant="ghost" size="sm" onClick={() => openResetPasswordDialog(admin)} className="text-orange-600 hover:bg-orange-50 px-2 py-1 h-auto"><KeyRound className="h-4 w-4"/></Button></DialogTrigger>
                                 <DialogContent className="sm:max-w-md bg-slate-50">
                                    <DialogHeader><DialogTitle>Reset Password for {admin.username}</DialogTitle></DialogHeader>
                                    <Form {...resetPasswordForm}>
                                        <form onSubmit={resetPasswordForm.handleSubmit(handleResetPasswordSubmit)} className="space-y-4 py-2">
                                            <FormField control={resetPasswordForm.control} name="newPassword" render={({ field }) => (<FormItem><FormLabel>New Password</FormLabel><FormControl><Input type="password" {...field} /></FormControl><FormMessage /></FormItem>)} />
                                            <FormField control={resetPasswordForm.control} name="confirmNewPassword" render={({ field }) => (<FormItem><FormLabel>Confirm New Password</FormLabel><FormControl><Input type="password" {...field} /></FormControl><FormMessage /></FormItem>)} />
                                            <DialogFooter>
                                                <DialogClose asChild><Button type="button" variant="outline" onClick={() => setEditingDelegateAdmin(null)}>Cancel</Button></DialogClose>
                                                <Button type="submit" disabled={isSubmittingDelegateAdmin} className="bg-orange-600 hover:bg-orange-700 text-white">Reset Password</Button>
                                            </DialogFooter>
                                        </form>
                                    </Form>
                                </DialogContent>
                             </Dialog>
                            <AlertDialog>
                              <AlertDialogTrigger asChild><Button variant="ghost" size="sm" className="text-red-600 hover:bg-red-50 px-2 py-1 h-auto"><Trash2 className="h-4 w-4"/></Button></AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader><AlertDialogTitle>Are you sure?</AlertDialogTitle><AlertDialogDescription>This will permanently delete the delegate admin '{admin.username}'. This action cannot be undone.</AlertDialogDescription></AlertDialogHeader>
                                <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={() => handleDeleteDelegateAdmin(admin.username)} className="bg-red-600 hover:bg-red-700 text-white">Delete Admin</AlertDialogAction></AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </ScrollArea>
              )}
            </CardContent>
          </Card>
        </TabsContent>

      </Tabs>
      <Card className="mt-6 border-yellow-500 bg-yellow-50/70">
        <CardHeader className="flex flex-row items-center gap-2">
            <ShieldAlert className="h-5 w-5 text-yellow-700"/>
            <CardTitle className="text-yellow-800 text-base">Security & Functionality Note</CardTitle>
        </CardHeader>
        <CardContent className="text-xs text-yellow-700 space-y-1">
           <p>Delegate admin accounts are now managed here. Passwords are securely hashed.</p>
           <p><strong>Important:</strong> The permissions set for delegate admins are currently only stored. The main Admin Panel and Manager Panel do not yet enforce these permissions. Logging in as a delegate admin to these panels is not yet implemented. This setup lays the groundwork for future permission-based access control.</p>
        </CardContent>
      </Card>
    </div>
  );
}

    