
'use client';

import type { ReactNode } from 'react';
import { useEffect } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import Link from 'next/link';
import { LineChart, Users, Shield, Settings, LogOut, Home, UserCog, LogIn } from 'lucide-react';
import { Toaster } from '@/components/ui/toaster';
import { APP_NAME } from '@/lib/constants';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';


export function ManagerHeader() {
  const { logoutManager, loggedInUser } = useAuth(); // Use loggedInUser to check role

  const getTitle = () => {
    if (loggedInUser?.role === 'delegateAdmin') {
      return `${APP_NAME} Manager Panel (Delegate)`;
    }
    return `${APP_NAME} Manager Panel`;
  };
  
  const Icon = loggedInUser?.role === 'delegateAdmin' ? Users : UserCog;

  return (
    <header className="bg-primary text-primary-foreground shadow-md"> {/* Changed to primary color */}
      <div className="container mx-auto flex items-center justify-between p-4">
        <Link href="/manager" className="flex items-center gap-2 text-xl font-bold hover:text-slate-100/80 transition-colors"> {/* Adjusted hover color */}
          <Icon className="h-7 w-7" />
          <span>{getTitle()}</span>
        </Link>
        <nav className="flex items-center gap-2 md:gap-4">
          <Link href="/" className="text-sm hover:text-slate-100/80 transition-colors flex items-center"> {/* Adjusted hover color */}
            <Home className="mr-1 h-4 w-4" /> Main App
          </Link>
          <Link href="/admin" className="text-sm hover:text-slate-100/80 transition-colors flex items-center"> {/* Adjusted hover color */}
            <Shield className="mr-1 h-4 w-4" /> Admin
          </Link>
           {loggedInUser?.role === 'manager' && ( // Only primary manager sees settings
             <Link href="/manager/settings" className="text-sm hover:text-slate-100/80 transition-colors flex items-center"> {/* Adjusted hover color */}
               <Settings className="mr-1 h-4 w-4" /> Settings
             </Link>
           )}
          {loggedInUser ? ( // Check if any user is logged in for this panel
             <Button onClick={logoutManager} variant="ghost" className="text-primary-foreground hover:bg-primary/80 hover:text-white px-3 py-1 h-auto text-sm"> {/* Adjusted hover */}
              <LogOut className="mr-1 h-4 w-4" /> Logout
            </Button>
          ) : (
            <Link href="/manager/login" className="text-sm hover:text-slate-100/80 transition-colors flex items-center"> {/* Adjusted hover color */}
              <LogIn className="mr-1 h-4 w-4" /> Login
            </Link>
          )}
        </nav>
      </div>
    </header>
  );
}


export default function ManagerLayout({ children }: { children: ReactNode }) {
  const { canAccessManagerPanel, loggedInUser } = useAuth(); // Use canAccessManagerPanel
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    if (!canAccessManagerPanel && pathname !== '/manager/login') {
       router.push('/manager/login');
    } else if (canAccessManagerPanel && pathname === '/manager/login') {
       router.push('/manager');
    }
  }, [canAccessManagerPanel, router, pathname]);

  if (!canAccessManagerPanel && pathname !== '/manager/login') {
    return (
        <div className="flex items-center justify-center min-h-screen bg-slate-50">
            <p className="text-slate-700">Loading Manager Panel...</p>
        </div>
    );
  }
  
  if (pathname === '/manager/login') {
      return (
        <div className="admin-theme-wrapper">
            {children}
            <Toaster />
        </div>
      );
  }

  return (
    <div className="admin-theme-wrapper"> 
      <ManagerHeader />
      <main className="container mx-auto p-4 md:p-8">
        {children}
      </main>
      <Toaster />
      <footer className="py-4 text-center text-xs text-slate-500 border-t border-slate-200">
        &copy; {new Date().getFullYear()} {APP_NAME} Manager Dashboard.
      </footer>
    </div>
  );
}
