
'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useAuth } from '@/contexts/AuthContext';
import { APP_NAME } from '@/lib/constants';
import { LogIn, UserCog, ShieldCheck } from 'lucide-react'; // Added ShieldCheck for broader access
import { useToast } from '@/hooks/use-toast';

const loginFormSchema = z.object({
  username: z.string().min(1, 'Username is required.'),
  password: z.string().min(1, 'Password is required.'),
});

type LoginFormValues = z.infer<typeof loginFormSchema>;

export default function ManagerLoginPage() {
  const { loginManagerOrDelegate } = useAuth(); // Use the new combined login function
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const form = useForm<LoginFormValues>({
    resolver: zodResolver(loginFormSchema),
    defaultValues: { username: '', password: '' },
  });

  const onSubmit = async (values: LoginFormValues) => {
    setIsLoading(true);
    const success = await loginManagerOrDelegate(values.username, values.password);
    if (!success) {
      toast({
        title: 'Login Failed',
        description: 'Invalid username or password, or insufficient permissions for manager panel access.',
        variant: 'destructive',
      });
    }
    // AuthContext handles redirection on success
    setIsLoading(false);
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-slate-100 p-4">
      <Card className="w-full max-w-md shadow-xl border-slate-300">
        <CardHeader className="text-center">
          <ShieldCheck className="mx-auto h-12 w-12 text-teal-600 mb-2" /> 
          <CardTitle className="text-2xl font-bold text-slate-800">{APP_NAME} Manager Panel Access</CardTitle>
          <CardDescription className="text-slate-600">Login as Manager or authorized Delegate Admin.</CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="username"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-slate-700">Username</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter username" {...field} className="bg-white border-slate-300 focus:ring-teal-500 focus:border-teal-500 text-slate-900" />
                    </FormControl>
                    <FormMessage className="text-red-500" />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-slate-700">Password</FormLabel>
                    <FormControl>
                      <Input type="password" placeholder="••••••••" {...field} className="bg-white border-slate-300 focus:ring-teal-500 focus:border-teal-500 text-slate-900" />
                    </FormControl>
                    <FormMessage className="text-red-500" />
                  </FormItem>
                )}
              />
              <Button type="submit" className="w-full bg-teal-600 hover:bg-teal-700 text-white" disabled={isLoading}>
                {isLoading ? 'Logging in...' : <><LogIn className="mr-2 h-4 w-4" /> Login</>}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
