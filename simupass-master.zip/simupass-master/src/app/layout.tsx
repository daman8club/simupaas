
import type { Metadata } from 'next';
import { GeistSans } from 'geist/font/sans';
import { GeistMono } from 'geist/font/mono';
import './globals.css';
import { MainLayout } from '@/components/layout/main-layout';
import { APP_NAME } from '@/lib/constants';
import { AuthProvider } from '@/contexts/AuthContext'; // Import AuthProvider

// Correctly assign font variables
const geistSansVar = GeistSans;
const geistMonoVar = GeistMono;

export const metadata: Metadata = {
  title: `${APP_NAME} - Simulated Password Recovery`,
  description: 'A simulated password recovery tool for educational and entertainment purposes.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={`${geistSansVar.variable} ${geistMonoVar.variable}`}>
      <body className="antialiased">
        <AuthProvider> {/* Wrap with AuthProvider */}
          {children}
        </AuthProvider>
      </body>
    </html>
  );
}
