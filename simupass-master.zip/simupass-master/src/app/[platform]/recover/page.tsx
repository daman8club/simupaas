
'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Image from 'next/image'; // Keep if platform icons use it, or remove if Lucide only
import { PLATFORMS } from '@/lib/constants';
import type { RecoveryStage, DecryptionResult } from '@/types';
import { UsernameForm } from '@/components/username-form';
import { ProcessingSteps } from '@/components/processing-steps';
import { PaymentModal } from '@/components/payment-modal';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { simulatePasswordDecryption, type SimulatePasswordDecryptionInput } from '@/ai/flows/simulate-password-decryption';
import { logSuccessfulSimulation } from '@/ai/flows/manager-actions';
import { useToast } from '@/hooks/use-toast';
import { AlertTriangle, CheckCircle2, Copy, Eye, EyeOff, Home, LockKeyhole, RefreshCw, Terminal } from 'lucide-react'; // Added Terminal

export default function RecoverPage() {
  const router = useRouter();
  const params = useParams();
  const { toast } = useToast();
  const platformSlug = params.platform as string;

  const [stage, setStage] = useState<RecoveryStage>('USERNAME_INPUT');
  const [username, setUsername] = useState('');
  const [decryptionResult, setDecryptionResult] = useState<DecryptionResult | null>(null);
  const [isSubmittingUsername, setIsSubmittingUsername] = useState(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const platform = PLATFORMS.find(p => p.slug === platformSlug);

  useEffect(() => {
    if (!platform) {
      router.push('/'); // Redirect if platform is invalid
    }
  }, [platform, router]);

  const handleUsernameSubmit = async (values: { username: string }) => {
    setIsSubmittingUsername(true);
    setUsername(values.username);
    setStage('PROCESSING');
    
    try {
      const input: SimulatePasswordDecryptionInput = { username: values.username };
      const result = await simulatePasswordDecryption(input);
      setDecryptionResult(result);
    } catch (error) {
      console.error('AI simulation error:', error);
      toast({
        title: 'Simulation Error',
        description: 'An error occurred during the password recovery simulation.',
        variant: 'destructive',
      });
      setStage('USERNAME_INPUT');
    } finally {
      setIsSubmittingUsername(false);
    }
  };
  
  const onProcessingComplete = () => {
    if (decryptionResult) {
      setStage('PAYMENT_PENDING');
      setIsPaymentModalOpen(true);
    } else {
      toast({
        title: 'Error',
        description: 'Processing complete but no result found. Please try again.',
        variant: 'destructive',
      });
      setStage('USERNAME_INPUT');
    }
  };

  const handlePaymentVerified = async () => {
    setIsPaymentModalOpen(false);
    setStage('RECOVERY_SUCCESSFUL');
    toast({
      title: 'Password Revealed!',
      description: 'The simulated password is now available.',
      variant: 'default' // Will pick up hacker theme
    });

    // Log successful simulation for manager panel
    if (username && platformSlug) {
      try {
        await logSuccessfulSimulation({
          username,
          platform: platformSlug,
          timestamp: Date.now(),
          type: 'successful_simulation',
        });
      } catch (error) {
        console.error("Failed to log successful simulation:", error);
        // Non-critical error, so we don't block the user
      }
    }
  };

  const copyPasswordToClipboard = () => {
    if (decryptionResult?.generatedPassword) {
      navigator.clipboard.writeText(decryptionResult.generatedPassword)
        .then(() => toast({ title: 'Password Copied!', description: 'Simulated password copied to clipboard.' }))
        .catch(() => toast({ title: 'Copy Failed', description: 'Could not copy password.', variant: 'destructive' }));
    }
  };

  if (!platform) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center p-4">
        <AlertTriangle className="h-16 w-16 text-destructive mb-4" />
        <h1 className="text-2xl font-bold mb-2 text-foreground">Platform Not Found</h1>
        <p className="text-muted-foreground mb-4">The selected platform is invalid.</p>
        <Button onClick={() => router.push('/')} className="bg-primary text-primary-foreground hover:bg-primary/80">
          <Home className="mr-2 h-4 w-4" /> Go to Homepage
        </Button>
      </div>
    );
  }

  // const PlatformIcon = platform.icon; // Icon not used directly here for hacker theme

  return (
    <div className="flex flex-col items-center justify-center w-full p-2">
      <div className="w-full max-w-md">
        <div className="flex items-center justify-center mb-6 space-x-3">
          {/* Using Terminal for a generic "hacking" feel, or keep platform icon */}
          <Terminal className="h-12 w-12 text-primary" /> 
          {/* <PlatformIcon className="h-12 w-12 text-primary" /> */}
          <h1 className="text-3xl font-bold text-primary">
            {platform.name} Account Access Simulation
          </h1>
        </div>

        {stage === 'USERNAME_INPUT' && (
          <UsernameForm
            platformName={platform.name}
            onSubmit={handleUsernameSubmit}
            isLoading={isSubmittingUsername}
          />
        )}

        {stage === 'PROCESSING' && (
          <ProcessingSteps onCompletion={onProcessingComplete} />
        )}
        
        {stage === 'PAYMENT_PENDING' && decryptionResult && (
           <PaymentModal
            isOpen={isPaymentModalOpen}
            onClose={() => {
              setIsPaymentModalOpen(false);
              // setStage('USERNAME_INPUT'); // Optionally reset
            }}
            onPaymentVerified={handlePaymentVerified}
            username={username}
            platform={platformSlug} // Pass platformSlug to modal
          />
        )}

        {stage === 'RECOVERY_SUCCESSFUL' && decryptionResult && (
          <Card className="w-full border-primary shadow-neon-cyan animate-in fade-in-50 zoom-in-90">
            <CardHeader className="items-center text-center">
              <CheckCircle2 className="h-16 w-16 text-green-500 mb-3" /> {/* Keep green for success */}
              <CardTitle className="text-2xl text-green-500">Access Granted!</CardTitle>
              <CardDescription className="text-muted-foreground">
                Simulated credentials for <span className="font-semibold text-accent">{username}</span> on {platform.name}:
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 border border-dashed border-border rounded-sm bg-muted/30">
                <p className="text-sm text-muted-foreground mb-1">Retrieved Password:</p>
                <div className="flex items-center justify-between">
                  <span className={`text-xl font-mono font-semibold ${showPassword ? 'text-foreground' : 'blur-sm select-none animate-pulse'}`}>
                    {decryptionResult.generatedPassword}
                  </span>
                  <div className="flex items-center space-x-1">
                    <Button variant="ghost" size="icon" onClick={() => setShowPassword(!showPassword)} aria-label={showPassword ? "Hide password" : "Show password"} className="text-foreground hover:text-accent">
                      {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                    </Button>
                    <Button variant="ghost" size="icon" onClick={copyPasswordToClipboard} aria-label="Copy password" className="text-foreground hover:text-accent">
                      <Copy className="h-5 w-5" />
                    </Button>
                  </div>
                </div>
              </div>
              <div className="p-3 border border-border rounded-sm bg-background">
                 <h4 className="font-semibold text-sm mb-1 text-primary flex items-center"><LockKeyhole className="h-4 w-4 mr-2"/>Simulated Decryption Log:</h4>
                 <p className="text-xs text-muted-foreground whitespace-pre-wrap leading-relaxed max-h-32 overflow-y-auto p-1 border border-border/50 rounded-sm">
                   {decryptionResult.decryptionProcess}
                 </p>
              </div>
               <p className="text-xs text-center text-muted-foreground pt-2 italic">
                Remember: This is a simulation. No real accounts were accessed.
              </p>
            </CardContent>
            <CardFooter className="flex flex-col sm:flex-row gap-2 justify-center pt-4">
              <Button onClick={() => router.push('/')} variant="outline" className="border-primary text-primary hover:bg-primary hover:text-primary-foreground">
                <Home className="mr-2 h-4 w-4" /> Go to Homepage
              </Button>
              <Button onClick={() => { setStage('USERNAME_INPUT'); setDecryptionResult(null); setUsername('');}} className="bg-accent text-accent-foreground hover:bg-accent/80">
                 <RefreshCw className="mr-2 h-4 w-4" /> New Simulation
              </Button>
            </CardFooter>
          </Card>
        )}
      </div>
    </div>
  );
}
