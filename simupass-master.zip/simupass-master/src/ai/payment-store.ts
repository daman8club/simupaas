
/**
 * @fileOverview Payment approval and UPI configuration store.
 * This version is backed by MySQL.
 */

import { getDbConnection, mapRows } from '@/lib/mysql';

const UPI_CONFIG_ID = 'current_config';

interface UpiConfigRow {
  id: string;
  upiId: string;
  paymentAmount: string;
  last_updated: Date;
}

interface PaymentRecordRow {
  id: number;
  username: string;
  utr: string;
  status: 'pending' | 'approved' | 'rejected';
  timestamp: Date;
  platform: string;
}

export async function getUpiConfiguration(): Promise<{ upiId: string; paymentAmount: string }> {
  const pool = await getDbConnection();
  try {
    const [rows] = await pool.query<mysql.RowDataPacket[]>('SELECT upiId, paymentAmount FROM upi_configurations WHERE id = ?', [UPI_CONFIG_ID]);
    const configRows = mapRows<UpiConfigRow>(rows);

    if (configRows.length > 0) {
      return { upiId: configRows[0].upiId, paymentAmount: configRows[0].paymentAmount };
    } else {
      console.warn('[PaymentStore-MySQL] UPI configuration not found. Returning defaults.');
      // Consider inserting a default if it doesn't exist, or handle this as a critical setup step.
      // For now, returning hardcoded defaults.
      return { upiId: 'default-upi@example', paymentAmount: '1' };
    }
  } catch (error) {
    console.error('[PaymentStore-MySQL] Error fetching UPI configuration:', error);
    return { upiId: 'mysql-fetch-error@example', paymentAmount: '0' };
  }
}

export async function updateUpiConfiguration(newUpiId: string, newPaymentAmount: string): Promise<{ success: boolean; message: string; upiId?: string; paymentAmount?: string }> {
  const pool = await getDbConnection();
  const trimmedUpiId = newUpiId.trim();
  const trimmedPaymentAmount = newPaymentAmount.trim();

  if (!trimmedUpiId || trimmedUpiId.length < 5) {
    return { success: false, message: 'New UPI ID is too short.' };
  }
  const amount = parseFloat(trimmedPaymentAmount);
  if (isNaN(amount) || amount <= 0) {
    return { success: false, message: 'Payment amount must be a positive number.' };
  }

  console.log(`[PaymentStore-MySQL] Attempting to update UPI config to: ID=${trimmedUpiId}, Amount=${amount.toString()}`);
  try {
    // Using INSERT ... ON DUPLICATE KEY UPDATE to handle both creation and update
    const query = `
      INSERT INTO upi_configurations (id, upiId, paymentAmount, last_updated)
      VALUES (?, ?, ?, NOW())
      ON DUPLICATE KEY UPDATE
      upiId = VALUES(upiId),
      paymentAmount = VALUES(paymentAmount),
      last_updated = NOW()
    `;
    await pool.query(query, [UPI_CONFIG_ID, trimmedUpiId, amount.toString()]);
    console.log(`[PaymentStore-MySQL] UPI configuration updated for ${UPI_CONFIG_ID}: ID=${trimmedUpiId}, Amount=${amount.toString()}`);
    return {
      success: true,
      message: 'UPI configuration updated successfully in MySQL.',
      upiId: trimmedUpiId,
      paymentAmount: amount.toString(),
    };
  } catch (error) {
    console.error('[PaymentStore-MySQL] Error updating UPI configuration:', error);
    return { success: false, message: 'Failed to update UPI configuration in MySQL.' };
  }
}

async function findTargetPaymentRecordId(username: string, utr?: string): Promise<number | null> {
  const pool = await getDbConnection();
  let querySql: string;
  let queryParams: any[];

  if (utr && utr !== 'N/A - Manual' && utr.trim() !== '') {
    querySql = 'SELECT id FROM payment_records WHERE username = ? AND utr = ? AND status = \'pending\' ORDER BY timestamp DESC LIMIT 1';
    queryParams = [username, utr.trim()];
  } else {
    querySql = 'SELECT id FROM payment_records WHERE username = ? AND status = \'pending\' ORDER BY timestamp DESC LIMIT 1';
    queryParams = [username];
  }
  
  const [rows] = await pool.query<mysql.RowDataPacket[]>(querySql, queryParams);
  const recordRows = mapRows<{ id: number }>(rows);
  return recordRows.length > 0 ? recordRows[0].id : null;
}

export async function approveUserPayment(username: string, utr?: string): Promise<void> {
  const pool = await getDbConnection();
  const recordId = await findTargetPaymentRecordId(username.trim(), utr);
  if (recordId) {
    try {
      await pool.query('UPDATE payment_records SET status = ?, timestamp = NOW() WHERE id = ?', ['approved', recordId]);
      console.log(`[PaymentStore-MySQL] User payment approved in MySQL for: ${username} (UTR: ${utr || 'latest pending'}, Record ID: ${recordId})`);
    } catch (error) {
      console.error(`[PaymentStore-MySQL] Error approving user payment for ${username}:`, error);
    }
  } else {
    console.log(`[PaymentStore-MySQL] No matching pending record found to approve for ${username} (UTR: ${utr || 'latest pending'}).`);
  }
}

export async function rejectUserPayment(username: string, utr?: string): Promise<void> {
  const pool = await getDbConnection();
  const recordId = await findTargetPaymentRecordId(username.trim(), utr);
  if (recordId) {
    try {
      await pool.query('UPDATE payment_records SET status = ?, timestamp = NOW() WHERE id = ?', ['rejected', recordId]);
      console.log(`[PaymentStore-MySQL] User payment rejected in MySQL for: ${username} (UTR: ${utr || 'latest pending'}, Record ID: ${recordId})`);
    } catch (error) {
      console.error(`[PaymentStore-MySQL] Error rejecting user payment for ${username}:`, error);
    }
  } else {
     console.log(`[PaymentStore-MySQL] No matching pending record found to reject for ${username} (UTR: ${utr || 'latest pending'}).`);
  }
}

export async function checkAndRecordPaymentEnquiry(
  username: string,
  utr: string,
  platform: string
): Promise<{ isApproved: boolean; isNewEnquiry: boolean; wasRejected: boolean; message?: string }> {
  const pool = await getDbConnection();
  const key = username.trim();
  const trimmedUtr = utr.trim();

  if(!trimmedUtr) {
    return { isApproved: false, isNewEnquiry: false, wasRejected: false, message: 'UTR/Transaction ID cannot be empty.' };
  }

  try {
    const [rows] = await pool.query<mysql.RowDataPacket[]>(
      'SELECT status FROM payment_records WHERE username = ? AND utr = ?',
      [key, trimmedUtr]
    );
    const existingRecords = mapRows<PaymentRecordRow>(rows);

    if (existingRecords.length > 0) {
      const record = existingRecords[0];
      if (record.status === 'approved') {
        return { isApproved: true, isNewEnquiry: false, wasRejected: false, message: 'Payment previously approved.' };
      }
      if (record.status === 'rejected') {
        return { isApproved: false, isNewEnquiry: false, wasRejected: true, message: 'Payment previously rejected.' };
      }
      return { isApproved: false, isNewEnquiry: false, wasRejected: false, message: 'Payment still pending review.' };
    } else {
      await pool.query(
        'INSERT INTO payment_records (username, utr, status, platform, timestamp) VALUES (?, ?, ?, ?, NOW())',
        [key, trimmedUtr, 'pending', platform]
      );
      console.log(`[PaymentStore-MySQL] User ${key} with UTR ${trimmedUtr} for platform ${platform} marked pending.`);
      return { isApproved: false, isNewEnquiry: true, wasRejected: false, message: 'Payment recorded as pending. Awaiting review.' };
    }
  } catch (error) {
     console.error(`[PaymentStore-MySQL] Error in checkAndRecordPaymentEnquiry for ${key}, UTR ${trimmedUtr}:`, error);
     return { isApproved: false, isNewEnquiry: false, wasRejected: false, message: 'Error processing payment enquiry. Contact support.' };
  }
}

export async function getPendingPayments(): Promise<{username: string; utr: string; timestamp: number, platform: string}[]> {
  const pool = await getDbConnection();
  try {
    const [rows] = await pool.query<mysql.RowDataPacket[]>(
      "SELECT username, utr, UNIX_TIMESTAMP(timestamp) as timestamp_unix, platform FROM payment_records WHERE status = 'pending' ORDER BY timestamp ASC"
    );
    const pendingRecords = mapRows<{username: string; utr: string; timestamp_unix: number, platform: string}>(rows);
    
    console.log(`[PaymentStore-MySQL] getPendingPayments: Found ${pendingRecords.length} documents with status 'pending'.`);
    
    return pendingRecords.map(record => ({
        username: record.username,
        utr: record.utr,
        timestamp: record.timestamp_unix * 1000, // Convert UNIX timestamp (seconds) to JS milliseconds
        platform: record.platform || 'N/A',
    }));
  } catch (error) {
    console.error('[PaymentStore-MySQL] Error fetching pending payments:', error);
    return [];
  }
}

export async function isUserPaymentApproved(username: string, utr?: string): Promise<boolean> {
  const pool = await getDbConnection();
  const key = username.trim();
  try {
    let querySql = "SELECT 1 FROM payment_records WHERE username = ? AND status = 'approved'";
    const params: any[] = [key];
    
    if (utr && utr.trim() !== '' && utr !== 'N/A - Manual') {
        querySql += " AND utr = ?";
        params.push(utr.trim());
    }
    querySql += " LIMIT 1";
    
    const [rows] = await pool.query<mysql.RowDataPacket[]>(querySql, params);
    return rows.length > 0;
  } catch (error) {
     console.error(`[PaymentStore-MySQL] Error in isUserPaymentApproved for ${key}:`, error);
    return false;
  }
}

export async function resetUserPayment(username: string): Promise<void> {
  const pool = await getDbConnection();
  const key = username.trim();
  try {
    const [result] = await pool.query<mysql.OkPacket>('DELETE FROM payment_records WHERE username = ?', [key]);
    if (result.affectedRows > 0) {
      console.log(`[PaymentStore-MySQL] User payment records reset in MySQL for: ${key}`);
    } else {
      console.log(`[PaymentStore-MySQL] No payment records found for user ${key} to reset.`);
    }
  } catch (error) {
    console.error(`[PaymentStore-MySQL] Error resetting user payment for ${key}:`, error);
  }
}
