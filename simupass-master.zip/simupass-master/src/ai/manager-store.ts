
/**
 * @fileOverview Manager panel data store, backed by MySQL.
 */

import { getDbConnection, mapRows } from '@/lib/mysql';
import type { InteractionLog as StoredInteractionLog, PaymentTransaction as StoredPaymentTransaction } from './flows/manager-actions';

export async function logSuccessfulSimulation(log: StoredInteractionLog): Promise<void> {
  const pool = await getDbConnection();
  console.log('[ManagerStore-MySQL] Logging successful simulation:', JSON.stringify(log));
  try {
    await pool.query(
      'INSERT INTO interaction_logs (username, platform, timestamp, type) VALUES (?, ?, ?, ?)',
      [log.username, log.platform, log.timestamp, log.type]
    );
    console.log('[ManagerStore-MySQL] Successfully logged simulation.');
  } catch (error) {
    console.error('[ManagerStore-MySQL] Error logging successful simulation:', error);
  }
}

export async function logPaymentTransaction(transaction: StoredPaymentTransaction): Promise<void> {
  const pool = await getDbConnection();
  console.log('[ManagerStore-MySQL] Logging payment transaction:', JSON.stringify(transaction));
  try {
    await pool.query(
      'INSERT INTO payment_transaction_history (username, utr, platform, status, timestamp, amount) VALUES (?, ?, ?, ?, ?, ?)',
      [transaction.username, transaction.utr, transaction.platform, transaction.status, transaction.timestamp, transaction.amount]
    );
    console.log('[ManagerStore-MySQL] Successfully logged payment transaction.');
  } catch (error) {
    console.error('[ManagerStore-MySQL] Error logging payment transaction:', error);
  }
}

export async function getInteractionLogs(): Promise<StoredInteractionLog[]> {
  const pool = await getDbConnection();
  console.log('[ManagerStore-MySQL] Fetching interaction logs.');
  try {
    const [rows] = await pool.query<mysql.RowDataPacket[]>('SELECT username, platform, timestamp, type FROM interaction_logs ORDER BY timestamp DESC');
    const logs = mapRows<StoredInteractionLog>(rows);
    if (logs.length === 0) {
      console.log('[ManagerStore-MySQL] No interaction logs found.');
    }
    return logs;
  } catch (error) {
    console.error('[ManagerStore-MySQL] Error fetching interaction logs:', error);
    return [];
  }
}

export async function getPaymentTransactionHistory(): Promise<StoredPaymentTransaction[]> {
  const pool = await getDbConnection();
  console.log('[ManagerStore-MySQL] Fetching payment transaction history.');
  try {
    const [rows] = await pool.query<mysql.RowDataPacket[]>(
      'SELECT username, utr, platform, status, timestamp, amount FROM payment_transaction_history ORDER BY timestamp DESC'
    );
    const transactions = mapRows<StoredPaymentTransaction>(rows);
    if (transactions.length === 0) {
      console.log('[ManagerStore-MySQL] No payment transactions found.');
    }
    return transactions;
  } catch (error) {
    console.error('[ManagerStore-MySQL] Error fetching payment transaction history:', error);
    return [];
  }
}
