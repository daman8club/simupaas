
'use server';
/**
 * @fileOverview Admin actions for UPI configuration and payment management.
 *
 * - getUpiConfiguration - Retrieves the current UPI ID and payment amount.
 * - updateUpiConfiguration - Updates the UPI ID and payment amount.
 * - approvePayment - Approves a simulated payment for a user.
 * - rejectPayment - Rejects a simulated payment for a user.
 * - checkPaymentStatus - Checks if a user's simulated payment is approved.
 * - listPendingPayments - Lists users with pending payments and their UTRs.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';
// Import specific async functions from payment-store
import {
  getUpiConfiguration as getUpiConfigFromStore,
  updateUpiConfiguration as updateUpiConfigInStore,
  approveUserPayment as approveUserPaymentInStore,
  rejectUserPayment as rejectUserPaymentInStore,
  getPendingPayments as fetchPendingPaymentsFromStore,
  checkAndRecordPaymentEnquiry
} from '@/ai/payment-store';
import { logPaymentTransaction } from '@/ai/manager-store'; // For manager panel logging

// --- UPI Configuration Management ---
const UpiConfigurationSchema = z.object({
  upiId: z.string().describe('The current UPI ID.'),
  paymentAmount: z.string().describe('The current payment amount as a string.'),
});
export type UpiConfiguration = z.infer<typeof UpiConfigurationSchema>;

export async function getUpiConfiguration(): Promise<UpiConfiguration> {
  return getUpiConfigurationFlow({});
}

const getUpiConfigurationFlow = ai.defineFlow(
  {
    name: 'getUpiConfigurationFlow',
    inputSchema: z.object({}), // No input needed
    outputSchema: UpiConfigurationSchema,
  },
  async () => {
    return getUpiConfigFromStore();
  }
);

const UpdateUpiConfigurationInputSchema = z.object({
  newUpiId: z.string().min(5, 'UPI ID seems too short.').describe('The new UPI ID to set.'),
  newPaymentAmount: z.string().refine(val => !isNaN(parseFloat(val)) && parseFloat(val) > 0, {
    message: "Payment amount must be a positive number.",
  }).describe('The new payment amount to set.'),
});
export type UpdateUpiConfigurationInput = z.infer<typeof UpdateUpiConfigurationInputSchema>;

const UpdateUpiConfigurationOutputSchema = z.object({
  success: z.boolean(),
  message: z.string(),
  upiId: z.string().optional(),
  paymentAmount: z.string().optional(),
});
export type UpdateUpiConfigurationOutput = z.infer<typeof UpdateUpiConfigurationOutputSchema>;

export async function updateUpiConfiguration(input: UpdateUpiConfigurationInput): Promise<UpdateUpiConfigurationOutput> {
  return updateUpiConfigurationFlow(input);
}

const updateUpiConfigurationFlow = ai.defineFlow(
  {
    name: 'updateUpiConfigurationFlow',
    inputSchema: UpdateUpiConfigurationInputSchema,
    outputSchema: UpdateUpiConfigurationOutputSchema,
  },
  async ({ newUpiId, newPaymentAmount }) => {
    console.log(`ADMIN ACTION: Attempt to update UPI config to: ID=${newUpiId}, Amount=${newPaymentAmount}`);
    const result = await updateUpiConfigInStore(newUpiId, newPaymentAmount);
    return result;
  }
);


// --- Payment Verification ---
const PaymentActionInputSchema = z.object({
  username: z.string().trim().min(1, 'Username is required.'),
  platform: z.string().optional().describe("Platform slug, if available from context of approval/rejection."),
  utr: z.string().optional().describe("UTR, if available from context of approval/rejection.")
});
export type PaymentActionInput = z.infer<typeof PaymentActionInputSchema>;

const PaymentActionOutputSchema = z.object({
  success: z.boolean(),
  message: z.string(),
});
export type PaymentActionOutput = z.infer<typeof PaymentActionOutputSchema>;

export async function approvePayment(input: PaymentActionInput): Promise<PaymentActionOutput> {
  return approvePaymentFlow(input);
}

const approvePaymentFlow = ai.defineFlow(
  {
    name: 'approvePaymentFlow',
    inputSchema: PaymentActionInputSchema,
    outputSchema: PaymentActionOutputSchema,
  },
  async ({ username, platform, utr }) => {
    try {
      // Pass UTR to the store function
      await approveUserPaymentInStore(username, utr);
      console.log(`ADMIN ACTION: Payment approved for user: ${username}, UTR: ${utr || 'N/A'}`);
      
      const config = await getUpiConfigFromStore();
      await logPaymentTransaction({
        username,
        utr: utr || 'N/A - Admin Action',
        platform: platform || 'N/A - Admin Action',
        status: 'approved',
        timestamp: Date.now(),
        amount: config.paymentAmount,
      });

      return {
        success: true,
        message: `Payment approved for ${username}.`,
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred';
      console.error('Error approving payment:', error);
      return {
        success: false,
        message: `Failed to approve payment: ${errorMessage}`,
      };
    }
  }
);

export async function rejectPayment(input: PaymentActionInput): Promise<PaymentActionOutput> {
  return rejectPaymentFlow(input);
}

const rejectPaymentFlow = ai.defineFlow(
  {
    name: 'rejectPaymentFlow',
    inputSchema: PaymentActionInputSchema,
    outputSchema: PaymentActionOutputSchema,
  },
  async ({ username, platform, utr }) => {
    try {
      // Pass UTR to the store function
      await rejectUserPaymentInStore(username, utr);
      console.log(`ADMIN ACTION: Payment rejected for user: ${username}, UTR: ${utr || 'N/A'}`);

      const config = await getUpiConfigFromStore();
      await logPaymentTransaction({
        username,
        utr: utr || 'N/A - Admin Action',
        platform: platform || 'N/A - Admin Action',
        status: 'rejected',
        timestamp: Date.now(),
        amount: config.paymentAmount,
      });

      return {
        success: true,
        message: `Payment rejected for ${username}.`,
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred';
      console.error('Error rejecting payment:', error);
      return {
        success: false,
        message: `Failed to reject payment: ${errorMessage}`,
      };
    }
  }
);


const CheckPaymentStatusInputSchema = z.object({
  username: z.string().trim().min(1, 'Username is required.'),
  utr: z.string().trim().min(1, 'UTR/Transaction ID is required.'),
  platform: z.string().describe('The platform slug for logging purposes (e.g., instagram).'),
});
export type CheckPaymentStatusInput = z.infer<typeof CheckPaymentStatusInputSchema>;

const CheckPaymentStatusOutputSchema = z.object({
  isVerified: z.boolean(),
  isNewEnquiry: z.boolean().optional().describe('True if this was the first time this user payment status was checked and recorded as pending.'),
  wasRejected: z.boolean().optional().describe('True if the payment was explicitly rejected by an admin.'),
  message: z.string().optional(),
});
export type CheckPaymentStatusOutput = z.infer<typeof CheckPaymentStatusOutputSchema>;


export async function checkPaymentStatus(input: CheckPaymentStatusInput): Promise<CheckPaymentStatusOutput> {
  return checkPaymentStatusFlow(input);
}

const checkPaymentStatusFlow = ai.defineFlow(
  {
    name: 'checkPaymentStatusFlow',
    inputSchema: CheckPaymentStatusInputSchema,
    outputSchema: CheckPaymentStatusOutputSchema,
  },
  async ({ username, utr, platform }) => {
    try {
      // Add a small delay to simulate network/processing time
      await new Promise(resolve => setTimeout(resolve, 500)); // Reduced delay
      // Pass platform to checkAndRecordPaymentEnquiry
      const { isApproved, isNewEnquiry, wasRejected, message } = await checkAndRecordPaymentEnquiry(username, utr, platform);
      const config = await getUpiConfigFromStore();

      // Log to manager transaction history ONLY if it's a new enquiry and still pending.
      // Approved/Rejected states are logged by their respective admin action flows (approvePaymentFlow, rejectPaymentFlow).
      if (isNewEnquiry && !isApproved && !wasRejected) {
        await logPaymentTransaction({
          username, utr, platform, status: 'pending', timestamp: Date.now(), amount: config.paymentAmount,
        });
      }

      return {
        isVerified: isApproved,
        isNewEnquiry: isNewEnquiry,
        wasRejected: wasRejected,
        message: message || (isApproved ? 'Payment verified.' : (wasRejected ? 'Payment was rejected.' : 'Payment not yet verified by admin.')),
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred';
      console.error('Error checking payment status:', error);
      return {
        isVerified: false,
        isNewEnquiry: false,
        wasRejected: false,
        message: `Error checking payment status: ${errorMessage}`,
      };
    }
  }
);

const PendingPaymentUserSchema = z.object({
  username: z.string(),
  utr: z.string(),
  timestamp: z.number(),
  platform: z.string(), // Added platform
});
const ListPendingPaymentsOutputSchema = z.object({
  users: z.array(PendingPaymentUserSchema),
});
export type ListPendingPaymentsOutput = z.infer<typeof ListPendingPaymentsOutputSchema>;

export async function listPendingPayments(): Promise<ListPendingPaymentsOutput> {
  return listPendingPaymentsFlow({});
}

const listPendingPaymentsFlow = ai.defineFlow(
  {
    name: 'listPendingPaymentsFlow',
    inputSchema: z.object({}), // No input needed
    outputSchema: ListPendingPaymentsOutputSchema,
  },
  async () => {
    const pendingUsers = await fetchPendingPaymentsFromStore();
    return { users: pendingUsers };
  }
);

