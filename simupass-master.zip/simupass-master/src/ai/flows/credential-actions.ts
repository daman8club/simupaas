
'use server';
/**
 * @fileOverview Genkit flows for managing application credentials (admin, manager) using MySQL.
 *
 * - getCredential - Fetches current username for a role.
 * - updateCredential - Updates username and/or password for a role.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';
import { getDbConnection, mapRows } from '@/lib/mysql'; // Using MySQL
import bcrypt from 'bcryptjs';

const SALT_ROUNDS = 10;

// --- Schemas ---
const RoleEnum = z.enum(['admin', 'manager']);
export type Role = z.infer<typeof RoleEnum>;

const GetCredentialInputSchema = z.object({
  role: RoleEnum,
});
export type GetCredentialInput = z.infer<typeof GetCredentialInputSchema>;

const GetCredentialOutputSchema = z.object({
  username: z.string().optional(),
  password_hash: z.string().optional(),
  error: z.string().optional(),
});
export type GetCredentialOutput = z.infer<typeof GetCredentialOutputSchema>;

const UpdateCredentialInputSchema = z.object({
  role: RoleEnum.describe("The role whose credentials are to be updated."),
  newUsername: z.string().trim().min(3, "Username must be at least 3 characters.").optional().describe("The new username. If not provided, username won't be changed."),
  newPassword: z.string().min(6, "New password must be at least 6 characters.").optional().describe("The new password. If not provided, password won't be changed."),
});
export type UpdateCredentialInput = z.infer<typeof UpdateCredentialInputSchema>;

const UpdateCredentialOutputSchema = z.object({
  success: z.boolean(),
  message: z.string(),
});
export type UpdateCredentialOutput = z.infer<typeof UpdateCredentialOutputSchema>;


// --- Flows ---

export async function getCredential(input: GetCredentialInput): Promise<GetCredentialOutput> {
  return getCredentialFlow(input);
}

const getCredentialFlow = ai.defineFlow(
  {
    name: 'getCredentialFlow',
    inputSchema: GetCredentialInputSchema,
    outputSchema: GetCredentialOutputSchema,
  },
  async ({ role }) => {
    const pool = await getDbConnection();
    try {
      const [rows] = await pool.query<mysql.RowDataPacket[]>('SELECT username, password_hash FROM app_credentials WHERE role = ?', [role]);
      const credRows = mapRows<{ username: string; password_hash: string }>(rows);

      if (credRows.length > 0) {
        return { username: credRows[0].username, password_hash: credRows[0].password_hash };
      }
      return { error: `${role} credentials not found.` };
    } catch (error) {
      console.error(`Error fetching ${role} credential from MySQL:`, error);
      return { error: `Failed to fetch ${role} credential.` };
    }
  }
);

export async function updateCredential(input: UpdateCredentialInput): Promise<UpdateCredentialOutput> {
  return updateCredentialFlow(input);
}

const updateCredentialFlow = ai.defineFlow(
  {
    name: 'updateCredentialFlow',
    inputSchema: UpdateCredentialInputSchema,
    outputSchema: UpdateCredentialOutputSchema,
  },
  async ({ role, newUsername, newPassword }) => {
    const pool = await getDbConnection();
    if (!newUsername && !newPassword) {
      return { success: false, message: 'No changes requested. Provide new username or password.' };
    }

    const updates: { username?: string; password_hash?: string; last_updated: Date } = {
        last_updated: new Date(),
    };
    const setClauses = ['last_updated = NOW()'];
    const queryParams = [];

    if (newUsername) {
      // Check if new username already exists for a different role
      const [rows] = await pool.query<mysql.RowDataPacket[]>('SELECT role FROM app_credentials WHERE username = ? AND role != ?', [newUsername.trim(), role]);
      const existingUsers = mapRows<{role: string}>(rows);
      
      if (existingUsers.length > 0) {
        return { success: false, message: `Username '${newUsername}' is already taken by role '${existingUsers[0].role}'.` };
      }
      updates.username = newUsername.trim();
      setClauses.push('username = ?');
      queryParams.push(updates.username);
    }

    if (newPassword) {
      try {
        const hashedPassword = await bcrypt.hash(newPassword, SALT_ROUNDS);
        updates.password_hash = hashedPassword;
        setClauses.push('password_hash = ?');
        queryParams.push(updates.password_hash);
      } catch (hashError) {
        console.error('Error hashing new password:', hashError);
        return { success: false, message: 'Failed to process new password.' };
      }
    }
    
    queryParams.push(role); // For the WHERE clause

    try {
      // Using INSERT ... ON DUPLICATE KEY UPDATE to handle initial creation or update
      // This requires the 'role' column to be a PRIMARY KEY or UNIQUE KEY.
      const currentCreds = await getCredential({ role });
      
      let querySql;
      let finalParams = [];

      if (currentCreds.username || currentCreds.password_hash) { // Entry exists, so UPDATE
        if(setClauses.length === 1 && queryParams.length === 1) { // Only role in queryParams if nothing to update (should not happen due to initial check)
             return { success: false, message: "No actual data to update."};
        }
        querySql = `UPDATE app_credentials SET ${setClauses.join(', ')} WHERE role = ?`;
        finalParams = queryParams;
      } else { // Entry does not exist, so INSERT
        const insertData: {role: Role, username?: string, password_hash?: string} = { role };
        if (updates.username) insertData.username = updates.username;
        else return { success: false, message: "Username is required for new credential entry."}; // Cannot create new entry without username
        if (updates.password_hash) insertData.password_hash = updates.password_hash;
        else return { success: false, message: "Password is required for new credential entry."}; // Cannot create new entry without password

        querySql = 'INSERT INTO app_credentials (role, username, password_hash, last_updated) VALUES (?, ?, ?, NOW())';
        finalParams = [insertData.role, insertData.username, insertData.password_hash];
      }
      
      const [result] = await pool.query<mysql.OkPacket>(querySql, finalParams);
      
      if (result.affectedRows > 0 || result.insertId > 0) {
           return { success: true, message: `${role} credentials updated successfully.` };
      } else {
          return { success: false, message: `Failed to update ${role} credentials. No rows affected or no new entry created.` };
      }

    } catch (error) {
      console.error(`Error updating ${role} credential in MySQL:`, error);
      return { success: false, message: `Database error while updating ${role} credentials.` };
    }
  }
);
