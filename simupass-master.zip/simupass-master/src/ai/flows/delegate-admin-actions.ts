
'use server';
/**
 * @fileOverview Genkit flows for managing delegate admin users and their permissions using MySQL.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';
import { getDbConnection, mapRows } from '@/lib/mysql';
import bcrypt from 'bcryptjs';

const SALT_ROUNDS = 10;

// --- Schemas ---
const DelegateAdminPermissionsSchemaInternal = z.object({
  canManageUpiConfig: z.boolean().default(false).describe("Allow managing UPI & Payment Configuration in Admin Panel."),
  canHandlePendingVerifications: z.boolean().default(false).describe("Allow handling pending verifications in Admin Panel."),
  canViewManagerOverview: z.boolean().default(false).describe("Allow viewing Overview Stats in Manager Panel."),
  canViewManagerUserActivity: z.boolean().default(false).describe("Allow viewing User Activity in Manager Panel."),
  canViewManagerTransactions: z.boolean().default(false).describe("Allow viewing Transactions Detail in Manager Panel."),
});
export type DelegateAdminPermissions = z.infer<typeof DelegateAdminPermissionsSchemaInternal>;

const ManagedAdminSchema = z.object({
  username: z.string().describe("Username of the delegate admin."),
  permissions: DelegateAdminPermissionsSchemaInternal.describe("Permissions assigned to this delegate admin."),
  createdBy: z.string().describe("Username of the manager who created this delegate admin."),
  createdAt: z.number().describe("Timestamp of creation (milliseconds)."),
  lastUpdated: z.number().describe("Timestamp of last update (milliseconds)."),
});
export type ManagedAdmin = z.infer<typeof ManagedAdminSchema>;


// --- Create Delegate Admin ---
const CreateDelegateAdminInputSchema = z.object({
  username: z.string().trim().min(3, "Username must be at least 3 characters.").max(50, "Username too long."),
  password: z.string().min(6, "Password must be at least 6 characters."),
  permissions: DelegateAdminPermissionsSchemaInternal,
  managerUsername: z.string().describe("Username of the manager creating this delegate admin."),
});
export type CreateDelegateAdminInput = z.infer<typeof CreateDelegateAdminInputSchema>;

const CreateDelegateAdminOutputSchema = z.object({
  success: z.boolean(),
  message: z.string(),
  username: z.string().optional(),
});
export type CreateDelegateAdminOutput = z.infer<typeof CreateDelegateAdminOutputSchema>;

export async function createDelegateAdmin(input: CreateDelegateAdminInput): Promise<CreateDelegateAdminOutput> {
  return createDelegateAdminFlow(input);
}

const createDelegateAdminFlow = ai.defineFlow(
  {
    name: 'createDelegateAdminFlow',
    inputSchema: CreateDelegateAdminInputSchema,
    outputSchema: CreateDelegateAdminOutputSchema,
  },
  async ({ username, password, permissions, managerUsername }) => {
    const pool = await getDbConnection();
    try {
      const [existingRows] = await pool.query<mysql.RowDataPacket[]>('SELECT username FROM delegate_admins WHERE username = ?', [username.trim()]);
      if (existingRows.length > 0) {
        return { success: false, message: `Delegate admin username '${username}' already exists.` };
      }

      const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);
      
      await pool.query(
        'INSERT INTO delegate_admins (username, password_hash, permissions, createdBy, createdAt, lastUpdated) VALUES (?, ?, ?, ?, NOW(), NOW())',
        [username.trim(), hashedPassword, JSON.stringify(permissions), managerUsername]
      );

      return { success: true, message: `Delegate admin '${username}' created successfully.`, username: username.trim() };
    } catch (error) {
      console.error('Error creating delegate admin in MySQL:', error);
      const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred.';
      return { success: false, message: `Failed to create delegate admin: ${errorMessage}` };
    }
  }
);

// --- List Delegate Admins ---
const ListDelegateAdminsOutputSchema = z.object({
  admins: z.array(ManagedAdminSchema),
  error: z.string().optional(),
});
export type ListDelegateAdminsOutput = z.infer<typeof ListDelegateAdminsOutputSchema>;

export async function listDelegateAdmins(): Promise<ListDelegateAdminsOutput> {
  return listDelegateAdminsFlow({});
}

const listDelegateAdminsFlow = ai.defineFlow(
  {
    name: 'listDelegateAdminsFlow',
    inputSchema: z.object({}),
    outputSchema: ListDelegateAdminsOutputSchema,
  },
  async () => {
    const pool = await getDbConnection();
    try {
      const [rows] = await pool.query<mysql.RowDataPacket[]>(
        'SELECT username, permissions, createdBy, UNIX_TIMESTAMP(createdAt) as createdAt_unix, UNIX_TIMESTAMP(lastUpdated) as lastUpdated_unix FROM delegate_admins ORDER BY username ASC'
      );
      const adminRows = mapRows<{ username: string; permissions: string; createdBy: string; createdAt_unix: number; lastUpdated_unix: number }>(rows);
      
      const admins: ManagedAdmin[] = adminRows.map(row => ({
        username: row.username,
        permissions: JSON.parse(row.permissions) as DelegateAdminPermissions,
        createdBy: row.createdBy,
        createdAt: row.createdAt_unix * 1000, // Convert to milliseconds
        lastUpdated: row.lastUpdated_unix * 1000, // Convert to milliseconds
      }));
      return { admins };
    } catch (error) {
      console.error('Error listing delegate admins from MySQL:', error);
      const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred.';
      return { admins: [], error: `Failed to list delegate admins: ${errorMessage}` };
    }
  }
);

// --- Update Delegate Admin ---
const UpdateDelegateAdminInputSchema = z.object({
  username: z.string().describe("The username of the delegate admin to update."),
  newPassword: z.string().min(6, "New password must be at least 6 characters.").optional(),
  permissions: DelegateAdminPermissionsSchemaInternal.optional(),
});
export type UpdateDelegateAdminInput = z.infer<typeof UpdateDelegateAdminInputSchema>;

const UpdateDelegateAdminOutputSchema = z.object({
  success: z.boolean(),
  message: z.string(),
});
export type UpdateDelegateAdminOutput = z.infer<typeof UpdateDelegateAdminOutputSchema>;

export async function updateDelegateAdmin(input: UpdateDelegateAdminInput): Promise<UpdateDelegateAdminOutput> {
  return updateDelegateAdminFlow(input);
}

const updateDelegateAdminFlow = ai.defineFlow(
  {
    name: 'updateDelegateAdminFlow',
    inputSchema: UpdateDelegateAdminInputSchema,
    outputSchema: UpdateDelegateAdminOutputSchema,
  },
  async ({ username, newPassword, permissions }) => {
    const pool = await getDbConnection();
    if (!newPassword && !permissions) {
        return { success: false, message: 'No changes requested. Provide new password or permissions.' };
    }
    try {
      const [existingRows] = await pool.query<mysql.RowDataPacket[]>('SELECT username FROM delegate_admins WHERE username = ?', [username]);
      if (existingRows.length === 0) {
        return { success: false, message: `Delegate admin '${username}' not found.` };
      }

      const setClauses: string[] = ['lastUpdated = NOW()'];
      const queryParams: any[] = [];

      if (newPassword) {
        const hashedPassword = await bcrypt.hash(newPassword, SALT_ROUNDS);
        setClauses.push('password_hash = ?');
        queryParams.push(hashedPassword);
      }
      if (permissions) {
        setClauses.push('permissions = ?');
        queryParams.push(JSON.stringify(permissions));
      }
      queryParams.push(username); // For WHERE clause

      const querySql = `UPDATE delegate_admins SET ${setClauses.join(', ')} WHERE username = ?`;
      const [result] = await pool.query<mysql.OkPacket>(querySql, queryParams);

      if (result.affectedRows > 0) {
        return { success: true, message: `Delegate admin '${username}' updated successfully.` };
      }
      return { success: false, message: `Failed to update delegate admin '${username}'. No rows affected.` };
    } catch (error) {
      console.error(`Error updating delegate admin ${username} in MySQL:`, error);
      const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred.';
      return { success: false, message: `Failed to update delegate admin: ${errorMessage}` };
    }
  }
);

// --- Delete Delegate Admin ---
const DeleteDelegateAdminInputSchema = z.object({
  username: z.string().describe("The username of the delegate admin to delete."),
});
export type DeleteDelegateAdminInput = z.infer<typeof DeleteDelegateAdminInputSchema>;

const DeleteDelegateAdminOutputSchema = z.object({
  success: z.boolean(),
  message: z.string(),
});
export type DeleteDelegateAdminOutput = z.infer<typeof DeleteDelegateAdminOutputSchema>;

export async function deleteDelegateAdmin(input: DeleteDelegateAdminInput): Promise<DeleteDelegateAdminOutput> {
  return deleteDelegateAdminFlow(input);
}

const deleteDelegateAdminFlow = ai.defineFlow(
  {
    name: 'deleteDelegateAdminFlow',
    inputSchema: DeleteDelegateAdminInputSchema,
    outputSchema: DeleteDelegateAdminOutputSchema,
  },
  async ({ username }) => {
    const pool = await getDbConnection();
    try {
      const [result] = await pool.query<mysql.OkPacket>('DELETE FROM delegate_admins WHERE username = ?', [username]);
      if (result.affectedRows > 0) {
        return { success: true, message: `Delegate admin '${username}' deleted successfully.` };
      }
      return { success: false, message: `Delegate admin '${username}' not found or already deleted.` };
    } catch (error) {
      console.error(`Error deleting delegate admin ${username} from MySQL:`, error);
      const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred.';
      return { success: false, message: `Failed to delete delegate admin: ${errorMessage}` };
    }
  }
);

// --- Get Delegate Admin Credentials (for login) ---
const GetDelegateAdminCredentialsInputSchema = z.object({
  username: z.string().describe("Username of the delegate admin."),
});
export type GetDelegateAdminCredentialsInput = z.infer<typeof GetDelegateAdminCredentialsInputSchema>;

const GetDelegateAdminCredentialsOutputSchema = z.object({
  username: z.string().optional(),
  password_hash: z.string().optional(),
  permissions: DelegateAdminPermissionsSchemaInternal.optional(),
  error: z.string().optional(),
});
export type GetDelegateAdminCredentialsOutput = z.infer<typeof GetDelegateAdminCredentialsOutputSchema>;

export async function getDelegateAdminCredentials(input: GetDelegateAdminCredentialsInput): Promise<GetDelegateAdminCredentialsOutput> {
    return getDelegateAdminCredentialsFlow(input);
}

const getDelegateAdminCredentialsFlow = ai.defineFlow(
  {
    name: 'getDelegateAdminCredentialsFlow',
    inputSchema: GetDelegateAdminCredentialsInputSchema,
    outputSchema: GetDelegateAdminCredentialsOutputSchema,
  },
  async ({ username }) => {
    const pool = await getDbConnection();
    try {
      const [rows] = await pool.query<mysql.RowDataPacket[]>('SELECT username, password_hash, permissions FROM delegate_admins WHERE username = ?', [username]);
      const credRows = mapRows<{ username: string; password_hash: string; permissions: string }>(rows);

      if (credRows.length > 0) {
        const data = credRows[0];
        try {
            const parsedPermissions = JSON.parse(data.permissions) as DelegateAdminPermissions;
            return {
                username: data.username,
                password_hash: data.password_hash,
                permissions: parsedPermissions,
            };
        } catch (jsonError) {
            console.error(`Error parsing permissions JSON for delegate admin ${username}:`, jsonError);
            return { error: `Delegate admin '${username}' permissions data is malformed.` };
        }
      }
      return { error: `Delegate admin '${username}' not found.` };
    } catch (error) {
      console.error(`Error fetching delegate admin credentials for ${username} from MySQL:`, error);
      const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred.';
      return { error: `Failed to fetch delegate admin credentials: ${errorMessage}` };
    }
  }
);
