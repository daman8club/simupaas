
'use server';
/**
 * @fileOverview Genkit flows for the Manager Panel.
 * Provides data for user activity tracking, platform usage, and transaction history.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';
import {
  getInteractionLogs as getInteractionLogsFromStore,
  getPaymentTransactionHistory as getPaymentTransactionHistoryFromStore,
  logSuccessfulSimulation as logSuccessfulSimulationToStore,
} from '@/ai/manager-store';
import { format, startOfWeek, endOfWeek, startOfMonth, endOfMonth, isWithinInterval, parseISO } from 'date-fns';

// --- Schemas (Internal to this file, not exported directly) ---
const InteractionLogSchema = z.object({
  username: z.string().describe('The username of the user who interacted.'),
  platform: z.string().describe('The platform the user interacted with (e.g., instagram, facebook).'),
  timestamp: z.number().describe('The UNIX timestamp of the interaction.'),
  type: z.literal('successful_simulation').describe('The type of interaction logged.'),
});
export type InteractionLog = z.infer<typeof InteractionLogSchema>;

const PaymentTransactionSchema = z.object({
  username: z.string().describe('The username associated with the payment.'),
  utr: z.string().describe('The UTR/Transaction ID of the payment.'),
  platform: z.string().describe('The platform for which the payment was made.'),
  status: z.enum(['pending', 'approved', 'rejected']).describe('The status of the payment.'),
  timestamp: z.number().describe('The UNIX timestamp of the transaction event (request or resolution).'),
  amount: z.string().describe('The amount of the payment.'),
});
export type PaymentTransaction = z.infer<typeof PaymentTransactionSchema>;


// --- Flow to log a successful simulation ---
export type LogSuccessfulSimulationInput = InteractionLog;

export async function logSuccessfulSimulation(input: LogSuccessfulSimulationInput): Promise<void> {
  return logSuccessfulSimulationFlow(input);
}

const logSuccessfulSimulationFlow = ai.defineFlow(
  {
    name: 'logSuccessfulSimulationFlow',
    inputSchema: InteractionLogSchema,
    outputSchema: z.void(),
  },
  async (log) => {
    await logSuccessfulSimulationToStore(log);
  }
);


// --- Flows for Manager Data Retrieval ---

// Output type for User Simulation Counts
const UserSimulationCountsOutputSchema = z.object({
  byDatePlatform: z.array(z.object({
    date: z.string().describe('Date in YYYY-MM-DD format.'),
    platform: z.string(),
    count: z.number(),
  })),
  totalToday: z.number(),
  totalThisWeek: z.number(),
  totalThisMonth: z.number(),
});
export type UserSimulationCountsOutput = z.infer<typeof UserSimulationCountsOutputSchema>;

export async function getUserSimulationCounts(): Promise<UserSimulationCountsOutput> {
  return getUserSimulationCountsFlow({});
}

const getUserSimulationCountsFlow = ai.defineFlow(
  {
    name: 'getUserSimulationCountsFlow',
    inputSchema: z.object({}),
    outputSchema: UserSimulationCountsOutputSchema,
  },
  async () => {
    const logs = await getInteractionLogsFromStore();
    const countsByDatePlatform: Record<string, Record<string, number>> = {};
    
    const now = new Date();
    const todayStr = format(now, 'yyyy-MM-dd');
    const weekStart = startOfWeek(now);
    const weekEnd = endOfWeek(now);
    const monthStart = startOfMonth(now);
    const monthEnd = endOfMonth(now);

    let totalToday = 0;
    let totalThisWeek = 0;
    let totalThisMonth = 0;

    logs.forEach(log => {
      const logDate = new Date(log.timestamp);
      const dateStr = format(logDate, 'yyyy-MM-dd');
      
      countsByDatePlatform[dateStr] = countsByDatePlatform[dateStr] || {};
      countsByDatePlatform[dateStr][log.platform] = (countsByDatePlatform[dateStr][log.platform] || 0) + 1;
      
      if (dateStr === todayStr) {
        totalToday++;
      }
      if (isWithinInterval(logDate, { start: weekStart, end: weekEnd })) {
        totalThisWeek++;
      }
      if (isWithinInterval(logDate, { start: monthStart, end: monthEnd })) {
        totalThisMonth++;
      }
    });

    const finalCountsByDatePlatform = [];
    for (const date in countsByDatePlatform) {
      for (const platform in countsByDatePlatform[date]) {
        finalCountsByDatePlatform.push({ date, platform, count: countsByDatePlatform[date][platform] });
      }
    }
    finalCountsByDatePlatform.sort((a,b) => b.date.localeCompare(a.date) || a.platform.localeCompare(b.platform));

    return { 
        byDatePlatform: finalCountsByDatePlatform, 
        totalToday,
        totalThisWeek,
        totalThisMonth
    };
  }
);

// Input and Output types for Usernames by Platform
const UsernamesByPlatformInputSchema = z.object({
  platform: z.string().optional().describe('The platform slug (e.g., instagram). If omitted, returns for all platforms.'),
});
export type UsernamesByPlatformInput = z.infer<typeof UsernamesByPlatformInputSchema>;

const UsernamesByPlatformOutputSchema = z.object({
  users: z.array(z.object({
    username: z.string(),
    platform: z.string(),
    lastInteraction: z.number().describe('Timestamp of last interaction for this platform.'),
  })),
});
export type UsernamesByPlatformOutput = z.infer<typeof UsernamesByPlatformOutputSchema>;

export async function getUsernamesByPlatform(input: UsernamesByPlatformInput): Promise<UsernamesByPlatformOutput> {
  return getUsernamesByPlatformFlow(input);
}

const getUsernamesByPlatformFlow = ai.defineFlow(
  {
    name: 'getUsernamesByPlatformFlow',
    inputSchema: UsernamesByPlatformInputSchema,
    outputSchema: UsernamesByPlatformOutputSchema,
  },
  async ({ platform }) => {
    const logs = await getInteractionLogsFromStore();
    const platformUsers: Record<string, { username: string; platform: string; lastInteraction: number }> = {};

    logs.forEach(log => {
      if (platform && log.platform !== platform) {
        return;
      }
      const key = `${log.username}-${log.platform}`;
      if (!platformUsers[key] || log.timestamp > platformUsers[key].lastInteraction) {
        platformUsers[key] = {
          username: log.username,
          platform: log.platform,
          lastInteraction: log.timestamp,
        };
      }
    });
    return { users: Object.values(platformUsers).sort((a,b) => b.lastInteraction - a.lastInteraction) };
  }
);


// Input and Output types for Transaction History
const TransactionHistoryInputSchema = z.object({
  username: z.string().optional().describe('Filter by username.'),
  platform: z.string().optional().describe('Filter by platform slug.'),
  status: z.enum(['pending', 'approved', 'rejected', 'all']).default('all').optional().describe('Filter by payment status.'),
  startDate: z.string().optional().describe('Start date for filtering transactions (YYYY-MM-DD).'),
  endDate: z.string().optional().describe('End date for filtering transactions (YYYY-MM-DD).'),
});
export type TransactionHistoryInput = z.infer<typeof TransactionHistoryInputSchema>;

const TransactionSummarySchema = z.object({
    totalTransactions: z.number(),
    approvedCount: z.number(),
    approvedValue: z.number(),
    pendingCount: z.number(),
    rejectedCount: z.number(),
});
export type TransactionSummary = z.infer<typeof TransactionSummarySchema>;

const TransactionHistoryOutputSchema = z.object({
  transactions: z.array(PaymentTransactionSchema),
  summary: TransactionSummarySchema,
  dailyEarnings: z.number(),
  weeklyEarnings: z.number(),
  monthlyEarnings: z.number(),
});
export type TransactionHistoryOutput = z.infer<typeof TransactionHistoryOutputSchema>;


export async function getTransactionHistory(input: TransactionHistoryInput): Promise<TransactionHistoryOutput> {
  return getTransactionHistoryFlow(input);
}

const getTransactionHistoryFlow = ai.defineFlow(
  {
    name: 'getTransactionHistoryFlow',
    inputSchema: TransactionHistoryInputSchema,
    outputSchema: TransactionHistoryOutputSchema,
  },
  async (filters) => {
    const allRawTransactions = await getPaymentTransactionHistoryFromStore(); // Get all raw logs first

    // Calculate earnings based on ALL approved transactions from the raw logs
    const now = new Date();
    const todayStr = format(now, 'yyyy-MM-dd');
    const weekStart = startOfWeek(now);
    const weekEnd = endOfWeek(now);
    const monthStart = startOfMonth(now);
    const monthEnd = endOfMonth(now);
    
    let dailyEarnings = 0;
    let weeklyEarnings = 0;
    let monthlyEarnings = 0;

    allRawTransactions.forEach(tx => {
        if (tx.status === 'approved') {
            const txAmount = parseFloat(tx.amount) || 0;
            const txDate = new Date(tx.timestamp);
            if (format(txDate, 'yyyy-MM-dd') === todayStr) {
                dailyEarnings += txAmount;
            }
            if (isWithinInterval(txDate, { start: weekStart, end: weekEnd })) {
                weeklyEarnings += txAmount;
            }
            if (isWithinInterval(txDate, { start: monthStart, end: monthEnd })) {
                monthlyEarnings += txAmount;
            }
        }
    });

    // Deduplicate transactions to get the latest status per UTR for display
    const latestTransactionsMap = new Map<string, PaymentTransaction>();
    allRawTransactions.forEach(tx => {
      const existing = latestTransactionsMap.get(tx.utr);
      if (!existing || tx.timestamp > existing.timestamp) {
        latestTransactionsMap.set(tx.utr, tx);
      }
    });
    let transactionsForDisplay = Array.from(latestTransactionsMap.values());
    
    // Apply filters to this deduplicated list
    let filteredTransactions = transactionsForDisplay;

    if (filters.username) {
      filteredTransactions = filteredTransactions.filter(t => t.username.toLowerCase().includes(filters.username!.toLowerCase()));
    }
    if (filters.platform) {
      filteredTransactions = filteredTransactions.filter(t => t.platform === filters.platform);
    }
    if (filters.status && filters.status !== 'all') {
      filteredTransactions = filteredTransactions.filter(t => t.status === filters.status);
    }
    if (filters.startDate) {
        const startDate = parseISO(filters.startDate);
        filteredTransactions = filteredTransactions.filter(t => new Date(t.timestamp) >= startDate);
    }
    if (filters.endDate) {
        const endDate = parseISO(filters.endDate);
        const inclusiveEndDate = new Date(endDate.setDate(endDate.getDate() + 1));
        filteredTransactions = filteredTransactions.filter(t => new Date(t.timestamp) < inclusiveEndDate);
    }
    // Sort the final list by newest first
    filteredTransactions.sort((a, b) => b.timestamp - a.timestamp);


    // Calculate summary based on the `filteredTransactions` (deduplicated and filtered)
    let approvedCount = 0;
    let approvedValue = 0;
    let pendingCount = 0;
    let rejectedCount = 0;

    filteredTransactions.forEach(tx => {
        if (tx.status === 'approved') {
            approvedCount++;
            approvedValue += parseFloat(tx.amount) || 0;
        } else if (tx.status === 'pending') {
            pendingCount++;
        } else if (tx.status === 'rejected') {
            rejectedCount++;
        }
    });
    
    const summary: TransactionSummary = {
        totalTransactions: filteredTransactions.length,
        approvedCount,
        approvedValue,
        pendingCount,
        rejectedCount,
    };

    return { 
        transactions: filteredTransactions, 
        summary,
        dailyEarnings,
        weeklyEarnings,
        monthlyEarnings,
    };
  }
);
