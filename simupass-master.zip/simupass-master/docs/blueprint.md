# **App Name**: SimuPass

## Core Features:

- Platform Selection: Home screen displaying social media platform options: Instagram, Facebook, Twitter, Snapchat.
- Simulated Redirection: Fake redirection to a simulated password recovery page upon selecting a platform.
- Username Input: Prompt user to enter the username associated with the selected social media platform.
- Fake Account Processing: Simulate account recovery processing: database access, username matching, password decryption using a tool. Show fake progress animations while claiming to access data.
- Simulated Password Recovery and Payment: Display a simulated payment screen before revealing a randomly generated password after showing password recovery success. Use UPI ID: 9024892525-5@ybl
- Payment Verification: Verify payment with fake server

## Style Guidelines:

- Primary color: Deep blue (#3F51B5) to inspire trust and security.
- Background color: Light blue (#E8EAF6), a very desaturated version of the primary.
- Accent color: Violet (#7E57C2) to draw the eye and convey authority.
- Use a clear, readable, sans-serif font for usernames and process descriptions.
- Use icons associated with security, like keys and locks.
- Ensure prominent placement of the payment/UPI information.
- Include loading animations during the fake password recovery process.